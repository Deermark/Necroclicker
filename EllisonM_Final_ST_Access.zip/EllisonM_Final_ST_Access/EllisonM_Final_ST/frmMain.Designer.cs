﻿namespace EllisonM_Final_ST
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.pnlTitle = new System.Windows.Forms.Panel();
            this.btnAdminButton = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnHighScores = new System.Windows.Forms.Button();
            this.pbxProfilePic = new System.Windows.Forms.PictureBox();
            this.fpnlUpgrades = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlDragonUpgradeArmor = new System.Windows.Forms.Panel();
            this.btnDragonUpgradeArmor = new System.Windows.Forms.Button();
            this.lblDragonUpgradeArmorDesc = new System.Windows.Forms.Label();
            this.lblDragonUpgradeArmorSPS = new System.Windows.Forms.Label();
            this.lblDragonUpgradeArmorCost = new System.Windows.Forms.Label();
            this.pbxDragonUpgradeArmor = new System.Windows.Forms.PictureBox();
            this.pnlDragonUpgradeFrostBreath = new System.Windows.Forms.Panel();
            this.btnDragonUpgradeFrostBreath = new System.Windows.Forms.Button();
            this.lblDragonUpgradeFrostBreathDesc = new System.Windows.Forms.Label();
            this.lblDragonUpgradeFrostBreathSPS = new System.Windows.Forms.Label();
            this.lblDragonUpgradeFrostBreathCost = new System.Windows.Forms.Label();
            this.pbxDragonUpgradeFrostBreath = new System.Windows.Forms.PictureBox();
            this.pnlDragonUpgradeRider = new System.Windows.Forms.Panel();
            this.btnDragonUpgradeRider = new System.Windows.Forms.Button();
            this.lblDragonUpgradeRiderDesc = new System.Windows.Forms.Label();
            this.lblDragonUpgradeRiderSPS = new System.Windows.Forms.Label();
            this.lblDragonUpgradeRiderCost = new System.Windows.Forms.Label();
            this.pbxDragonUpgradeRider = new System.Windows.Forms.PictureBox();
            this.pnlDeathKnightUpgradeHorses = new System.Windows.Forms.Panel();
            this.btnDeathKnightUpgradeHorses = new System.Windows.Forms.Button();
            this.lblDeathKnightUpgradeHorsesDesc = new System.Windows.Forms.Label();
            this.lblDeathKnightUpgradeHorsesSPS = new System.Windows.Forms.Label();
            this.lblDeathKnightUpgradeHorsesCost = new System.Windows.Forms.Label();
            this.pbxDeathKnightUpgradeHorses = new System.Windows.Forms.PictureBox();
            this.pnlDeathKnightUpgradeRunedArmor = new System.Windows.Forms.Panel();
            this.btnDeathKnightUpgradeRunedArmor = new System.Windows.Forms.Button();
            this.lblDeathKnightUpgradeRunedArmorDesc = new System.Windows.Forms.Label();
            this.lblDeathKnightUpgradeRunedArmorSPS = new System.Windows.Forms.Label();
            this.lblDeathKnightUpgradeRunedArmorCost = new System.Windows.Forms.Label();
            this.pbxDeathKnightUpgradeRunedArmor = new System.Windows.Forms.PictureBox();
            this.pnlDeathKnightUpgradeSteel = new System.Windows.Forms.Panel();
            this.btnDeathKnightUpgradeSteel = new System.Windows.Forms.Button();
            this.lblDeathKnightUpgradeSteelDesc = new System.Windows.Forms.Label();
            this.lblDeathKnightUpgradeSteelSPS = new System.Windows.Forms.Label();
            this.lblDeathKnightUpgradeSteelCost = new System.Windows.Forms.Label();
            this.pbxDeathKnightUpgradeSteel = new System.Windows.Forms.PictureBox();
            this.pnlLichUpgradeScrolls = new System.Windows.Forms.Panel();
            this.btnLichUpgradeScrolls = new System.Windows.Forms.Button();
            this.lblLichUpgradeScrollsDesc = new System.Windows.Forms.Label();
            this.lblLichUpgradeScrollsSPS = new System.Windows.Forms.Label();
            this.lblLichUpgradeScrollsCost = new System.Windows.Forms.Label();
            this.pbxLichUpgradeScrolls = new System.Windows.Forms.PictureBox();
            this.pnlLichUpgradeSummon = new System.Windows.Forms.Panel();
            this.btnLichUpgradeSummon = new System.Windows.Forms.Button();
            this.lblLichUpgradeSummonDesc = new System.Windows.Forms.Label();
            this.lblLichUpgradeSummonSPS = new System.Windows.Forms.Label();
            this.lblLichUpgradeSummonCost = new System.Windows.Forms.Label();
            this.pbxLichUpgradeSummon = new System.Windows.Forms.PictureBox();
            this.pnlLichUpgradeMagic = new System.Windows.Forms.Panel();
            this.btnLichUpgradeMagic = new System.Windows.Forms.Button();
            this.lblLichUpgradeMagicDesc = new System.Windows.Forms.Label();
            this.lblLichUpgradeMagicSPS = new System.Windows.Forms.Label();
            this.lblLichUpgradeMagicCost = new System.Windows.Forms.Label();
            this.pbxLichUpgradeMagic = new System.Windows.Forms.PictureBox();
            this.pnlWraithUpgradeWyvern = new System.Windows.Forms.Panel();
            this.btnWraithUpgradeWyvern = new System.Windows.Forms.Button();
            this.lblWraithUpgradeWyvernDesc = new System.Windows.Forms.Label();
            this.lblWraithUpgradeWyvernSPS = new System.Windows.Forms.Label();
            this.lblWraithUpgradeWyvernCost = new System.Windows.Forms.Label();
            this.pbxWraithUpgradeWyvern = new System.Windows.Forms.PictureBox();
            this.pnlWraithUpgradeInfernalWeaponry = new System.Windows.Forms.Panel();
            this.btnWraithUpgradeInfernalWeapons = new System.Windows.Forms.Button();
            this.lblWraithUpgradeInfernalWeaponryDesc = new System.Windows.Forms.Label();
            this.lblWraithUpgradeInfernalWeaponrySPS = new System.Windows.Forms.Label();
            this.lblWraithUpgradeInfernalWeaponryCost = new System.Windows.Forms.Label();
            this.pbxWraithUpgradeInfernalWeaponry = new System.Windows.Forms.PictureBox();
            this.pnlWraithUpgradeHorse = new System.Windows.Forms.Panel();
            this.btnWraithUpgradeHorse = new System.Windows.Forms.Button();
            this.lblWraithUpgradeHorseDesc = new System.Windows.Forms.Label();
            this.lblWraithUpgradeHorseSPS = new System.Windows.Forms.Label();
            this.lblWraithUpgradeHorseCost = new System.Windows.Forms.Label();
            this.pbxWraithUpgradeHorse = new System.Windows.Forms.PictureBox();
            this.pnlVampireUpgradeEnchantedWeaponry = new System.Windows.Forms.Panel();
            this.btnVampireUpgradeEnchantedWeaponry = new System.Windows.Forms.Button();
            this.lblVampireUpgradeEnchantedWeaponryDesc = new System.Windows.Forms.Label();
            this.lblVampireUpgradeEnchantedWeaponrySPS = new System.Windows.Forms.Label();
            this.lblVampireUpgradeEnchantedWeaponryCost = new System.Windows.Forms.Label();
            this.pbxVampireUpgradeEnchantedWeaponry = new System.Windows.Forms.PictureBox();
            this.pnlVampireUpgradeBatForm = new System.Windows.Forms.Panel();
            this.btnVampireUpgradeBatForm = new System.Windows.Forms.Button();
            this.lblVampireUpgradeBatFormDesc = new System.Windows.Forms.Label();
            this.lblVampireUpgradeBatFormSPS = new System.Windows.Forms.Label();
            this.lblVampireUpgradeBatFormCost = new System.Windows.Forms.Label();
            this.pbxVampireUpgradeBatForm = new System.Windows.Forms.PictureBox();
            this.pnlVampireUpgradeHealing = new System.Windows.Forms.Panel();
            this.btnVampireUpgradeHealing = new System.Windows.Forms.Button();
            this.lblVampireUpgradeHealingDesc = new System.Windows.Forms.Label();
            this.lblVampireUpgradeHealingSPS = new System.Windows.Forms.Label();
            this.lblVampireUpgradeHealingCost = new System.Windows.Forms.Label();
            this.pbxVampireUpgradeHealing = new System.Windows.Forms.PictureBox();
            this.pnlSkeletonUpgradeDarksteel = new System.Windows.Forms.Panel();
            this.btnSkeletonUpgradeDarksteel = new System.Windows.Forms.Button();
            this.lblSkeletonUpgradeDarksteelDesc = new System.Windows.Forms.Label();
            this.lblSkeletonUpgradeDarksteelSPS = new System.Windows.Forms.Label();
            this.lblSkeletonUpgradeDarksteelCost = new System.Windows.Forms.Label();
            this.pbxSkeletonUpgradeDarksteel = new System.Windows.Forms.PictureBox();
            this.pnlSkeletonUpgradeArmor = new System.Windows.Forms.Panel();
            this.btnSkeletonUpgradeArmor = new System.Windows.Forms.Button();
            this.lblSkeletonUpgradeArmorDesc = new System.Windows.Forms.Label();
            this.lblSkeletonUpgradeArmorSPS = new System.Windows.Forms.Label();
            this.lblSkeletonUpgradeArmorCost = new System.Windows.Forms.Label();
            this.pbxSkeletonUpgradeArmor = new System.Windows.Forms.PictureBox();
            this.pnlSkeletonUpgradeWeapons = new System.Windows.Forms.Panel();
            this.btnSkeletonUpgradeWeapons = new System.Windows.Forms.Button();
            this.lblSkeletonUpgradeWeaponsDesc = new System.Windows.Forms.Label();
            this.lblSkeletonUpgradeWeaponsSPS = new System.Windows.Forms.Label();
            this.lblSkeletonUpgradeWeaponsCost = new System.Windows.Forms.Label();
            this.pbxSkeletonUpgradeWeapons = new System.Windows.Forms.PictureBox();
            this.pnlGhoulUpgradeArmor = new System.Windows.Forms.Panel();
            this.btnGhoulUpgradeArmor = new System.Windows.Forms.Button();
            this.lblGhoulUpgradeArmorDesc = new System.Windows.Forms.Label();
            this.lblGhoulUpgradeArmorSPS = new System.Windows.Forms.Label();
            this.lblGhoulUpgradeArmorCost = new System.Windows.Forms.Label();
            this.pbxGhoulUpgradeArmor = new System.Windows.Forms.PictureBox();
            this.pnlGhoulUpgradeParalysis = new System.Windows.Forms.Panel();
            this.btnGhoulUpgradeParalysis = new System.Windows.Forms.Button();
            this.lblGhoulUpgradeParalysisDesc = new System.Windows.Forms.Label();
            this.lblGhoulUpgradeParalysisSPS = new System.Windows.Forms.Label();
            this.lblGhoulUpgradeParalysisCost = new System.Windows.Forms.Label();
            this.pbxGhoulUpgradeParalysis = new System.Windows.Forms.PictureBox();
            this.pnlGhoulFangsUpgrade = new System.Windows.Forms.Panel();
            this.btnGhoulFangsUpgrade = new System.Windows.Forms.Button();
            this.lblGhoulFangsUpgradeDesc = new System.Windows.Forms.Label();
            this.lblGhoulFangsUpgradeSPS = new System.Windows.Forms.Label();
            this.lblGhoulFangsUpgradeCost = new System.Windows.Forms.Label();
            this.pbxGhoulFangsUpgrade = new System.Windows.Forms.PictureBox();
            this.pnlZombieMutantUpgrade = new System.Windows.Forms.Panel();
            this.btnZombieMutantUpgrade = new System.Windows.Forms.Button();
            this.lblZombieMutantUpgradeDesc = new System.Windows.Forms.Label();
            this.lblZombieMutantUpgradeSPS = new System.Windows.Forms.Label();
            this.lblZombieMutantUpgradeCost = new System.Windows.Forms.Label();
            this.pbxZombieMutantUpgrade = new System.Windows.Forms.PictureBox();
            this.pnlZombieDiseasedUpgrade = new System.Windows.Forms.Panel();
            this.btnZombieDiseasedUpgrade = new System.Windows.Forms.Button();
            this.lblZombieDiseasedUpgradeDesc = new System.Windows.Forms.Label();
            this.lblZombieDiseasedUpgradeSPS = new System.Windows.Forms.Label();
            this.lblZombieDiseasedUpgradeCost = new System.Windows.Forms.Label();
            this.pbxZombieDiseasedUpgrade = new System.Windows.Forms.PictureBox();
            this.pnlZombieFastUpgrade = new System.Windows.Forms.Panel();
            this.btnZombieFastUpgrade = new System.Windows.Forms.Button();
            this.lblZombieFastUpgradeDesc = new System.Windows.Forms.Label();
            this.lblZombieFastUpgradeSPS = new System.Windows.Forms.Label();
            this.lblZombieFastUpgradeCost = new System.Windows.Forms.Label();
            this.pbxZombieFastUpgrade = new System.Windows.Forms.PictureBox();
            this.pnlDemonHelperUpgrade = new System.Windows.Forms.Panel();
            this.btnDemonHelperUpgrade = new System.Windows.Forms.Button();
            this.lblDemonHelperUpgradeDesc = new System.Windows.Forms.Label();
            this.lblDemonHelperUpgradeSPC = new System.Windows.Forms.Label();
            this.lblDemonHelperUpgradeCost = new System.Windows.Forms.Label();
            this.pbxDemonHelperUpgrade = new System.Windows.Forms.PictureBox();
            this.pnlAltarUpgrade = new System.Windows.Forms.Panel();
            this.btnAltarUpgrade = new System.Windows.Forms.Button();
            this.lblAltarUpgradeDesc = new System.Windows.Forms.Label();
            this.lblAltarUpgradeSPC = new System.Windows.Forms.Label();
            this.lblAltarUpgradeCost = new System.Windows.Forms.Label();
            this.pbxAltarUpgrade = new System.Windows.Forms.PictureBox();
            this.pnlImpUpgrade = new System.Windows.Forms.Panel();
            this.btnImpUpgrade = new System.Windows.Forms.Button();
            this.lblImpUpgradeDesc = new System.Windows.Forms.Label();
            this.lblImpUpgradeSPC = new System.Windows.Forms.Label();
            this.lblImpUpgradeCost = new System.Windows.Forms.Label();
            this.pbxImpUpgrade = new System.Windows.Forms.PictureBox();
            this.pnlCouldronUpgrade = new System.Windows.Forms.Panel();
            this.btnCouldronupgrade = new System.Windows.Forms.Button();
            this.lblCouldronUpgradeDesc = new System.Windows.Forms.Label();
            this.lblCouldronUpgradeSPC = new System.Windows.Forms.Label();
            this.lblCouldronUpgradeCost = new System.Windows.Forms.Label();
            this.pbxlCouldronUpgrade = new System.Windows.Forms.PictureBox();
            this.pnlBookUpgrade = new System.Windows.Forms.Panel();
            this.btnBookUpgrade = new System.Windows.Forms.Button();
            this.lblBookUpgradeDesc = new System.Windows.Forms.Label();
            this.lblBookUpgradeSPS = new System.Windows.Forms.Label();
            this.lblBookUpgradeCost = new System.Windows.Forms.Label();
            this.pbxBookUpgrade = new System.Windows.Forms.PictureBox();
            this.fpnlAutoClickers = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlZombie = new System.Windows.Forms.Panel();
            this.btnZombie = new System.Windows.Forms.Button();
            this.lblZombieDesc = new System.Windows.Forms.Label();
            this.lblZombieAmount = new System.Windows.Forms.Label();
            this.lblZombieCost = new System.Windows.Forms.Label();
            this.pbxZombie = new System.Windows.Forms.PictureBox();
            this.pnlGhoul = new System.Windows.Forms.Panel();
            this.btnGhoul = new System.Windows.Forms.Button();
            this.lblGhoulDesc = new System.Windows.Forms.Label();
            this.lblGhoulAmount = new System.Windows.Forms.Label();
            this.lblGhoulCost = new System.Windows.Forms.Label();
            this.pbxGhoul = new System.Windows.Forms.PictureBox();
            this.pnlSkeleton = new System.Windows.Forms.Panel();
            this.btnSkeleton = new System.Windows.Forms.Button();
            this.lblSkeletonDesc = new System.Windows.Forms.Label();
            this.lblSkeletonAmount = new System.Windows.Forms.Label();
            this.lblSkeletonCost = new System.Windows.Forms.Label();
            this.pbxSkeleton = new System.Windows.Forms.PictureBox();
            this.pnlVampire = new System.Windows.Forms.Panel();
            this.btnVampire = new System.Windows.Forms.Button();
            this.lblVampireDescription = new System.Windows.Forms.Label();
            this.lblVampireAmount = new System.Windows.Forms.Label();
            this.lblVampireCost = new System.Windows.Forms.Label();
            this.pbxVampire = new System.Windows.Forms.PictureBox();
            this.pnlWraith = new System.Windows.Forms.Panel();
            this.btnWraith = new System.Windows.Forms.Button();
            this.lblWraithDesc = new System.Windows.Forms.Label();
            this.lblWraithAmount = new System.Windows.Forms.Label();
            this.lblWraithCost = new System.Windows.Forms.Label();
            this.pbxWraith = new System.Windows.Forms.PictureBox();
            this.pnlLich = new System.Windows.Forms.Panel();
            this.btnLich = new System.Windows.Forms.Button();
            this.lblLichDesc = new System.Windows.Forms.Label();
            this.lblLichAmount = new System.Windows.Forms.Label();
            this.lblLichCost = new System.Windows.Forms.Label();
            this.pbxLich = new System.Windows.Forms.PictureBox();
            this.pnlDeathKnight = new System.Windows.Forms.Panel();
            this.btnDeathKnight = new System.Windows.Forms.Button();
            this.lblDeathKnightDesc = new System.Windows.Forms.Label();
            this.lblDeathKnightAmount = new System.Windows.Forms.Label();
            this.lblDeathKnightCost = new System.Windows.Forms.Label();
            this.pbxDeathKnight = new System.Windows.Forms.PictureBox();
            this.pnlDragon = new System.Windows.Forms.Panel();
            this.btnDragon = new System.Windows.Forms.Button();
            this.lblDragonDesc = new System.Windows.Forms.Label();
            this.lblDragonAmount = new System.Windows.Forms.Label();
            this.lblDragonCost = new System.Windows.Forms.Label();
            this.pbxDragon = new System.Windows.Forms.PictureBox();
            this.pnlInformation = new System.Windows.Forms.Panel();
            this.lblReportsRefresh = new System.Windows.Forms.Label();
            this.lblStatsPlayTime = new System.Windows.Forms.Label();
            this.lblStatsDispPlayTime = new System.Windows.Forms.Label();
            this.lblStatsUpgradesPurchased = new System.Windows.Forms.Label();
            this.lblStatsDispUpgradesPurchased = new System.Windows.Forms.Label();
            this.lblStatsUpgradesUnlocked = new System.Windows.Forms.Label();
            this.lblStatsDispUpgradesUnlocked = new System.Windows.Forms.Label();
            this.lblStatsTotalSoulsGained = new System.Windows.Forms.Label();
            this.lblStatsDispSoulsTotal = new System.Windows.Forms.Label();
            this.lblStatsSoulsSpent = new System.Windows.Forms.Label();
            this.lblStatsDispSoulsSpent = new System.Windows.Forms.Label();
            this.lblStatsClickCount = new System.Windows.Forms.Label();
            this.lblStatsDispClickCount = new System.Windows.Forms.Label();
            this.lblStatsSPC = new System.Windows.Forms.Label();
            this.lblStatsSPS = new System.Windows.Forms.Label();
            this.lblStatsSouls = new System.Windows.Forms.Label();
            this.lblStatsDispSPC = new System.Windows.Forms.Label();
            this.lblStatsDispSPS = new System.Windows.Forms.Label();
            this.lblStatsDispSouls = new System.Windows.Forms.Label();
            this.lblStatistics = new System.Windows.Forms.Label();
            this.btnSPSOverTimeGraph = new System.Windows.Forms.Button();
            this.btnClicksOverTimeGraph = new System.Windows.Forms.Button();
            this.btnStatistics = new System.Windows.Forms.Button();
            this.pbxClickThis = new System.Windows.Forms.PictureBox();
            this.lblSouls = new System.Windows.Forms.Label();
            this.lblSPS = new System.Windows.Forms.Label();
            this.pbxBackground = new System.Windows.Forms.PictureBox();
            this.timerStats = new System.Windows.Forms.Timer(this.components);
            this.timerSave = new System.Windows.Forms.Timer(this.components);
            this.timerSPS = new System.Windows.Forms.Timer(this.components);
            this.timerCheckAffordability = new System.Windows.Forms.Timer(this.components);
            this.timerSoulieMan = new System.Windows.Forms.Timer(this.components);
            this.pbxSoulieMan = new System.Windows.Forms.PictureBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.pnlTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProfilePic)).BeginInit();
            this.fpnlUpgrades.SuspendLayout();
            this.pnlDragonUpgradeArmor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDragonUpgradeArmor)).BeginInit();
            this.pnlDragonUpgradeFrostBreath.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDragonUpgradeFrostBreath)).BeginInit();
            this.pnlDragonUpgradeRider.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDragonUpgradeRider)).BeginInit();
            this.pnlDeathKnightUpgradeHorses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeathKnightUpgradeHorses)).BeginInit();
            this.pnlDeathKnightUpgradeRunedArmor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeathKnightUpgradeRunedArmor)).BeginInit();
            this.pnlDeathKnightUpgradeSteel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeathKnightUpgradeSteel)).BeginInit();
            this.pnlLichUpgradeScrolls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLichUpgradeScrolls)).BeginInit();
            this.pnlLichUpgradeSummon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLichUpgradeSummon)).BeginInit();
            this.pnlLichUpgradeMagic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLichUpgradeMagic)).BeginInit();
            this.pnlWraithUpgradeWyvern.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWraithUpgradeWyvern)).BeginInit();
            this.pnlWraithUpgradeInfernalWeaponry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWraithUpgradeInfernalWeaponry)).BeginInit();
            this.pnlWraithUpgradeHorse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWraithUpgradeHorse)).BeginInit();
            this.pnlVampireUpgradeEnchantedWeaponry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVampireUpgradeEnchantedWeaponry)).BeginInit();
            this.pnlVampireUpgradeBatForm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVampireUpgradeBatForm)).BeginInit();
            this.pnlVampireUpgradeHealing.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVampireUpgradeHealing)).BeginInit();
            this.pnlSkeletonUpgradeDarksteel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSkeletonUpgradeDarksteel)).BeginInit();
            this.pnlSkeletonUpgradeArmor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSkeletonUpgradeArmor)).BeginInit();
            this.pnlSkeletonUpgradeWeapons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSkeletonUpgradeWeapons)).BeginInit();
            this.pnlGhoulUpgradeArmor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGhoulUpgradeArmor)).BeginInit();
            this.pnlGhoulUpgradeParalysis.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGhoulUpgradeParalysis)).BeginInit();
            this.pnlGhoulFangsUpgrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGhoulFangsUpgrade)).BeginInit();
            this.pnlZombieMutantUpgrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxZombieMutantUpgrade)).BeginInit();
            this.pnlZombieDiseasedUpgrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxZombieDiseasedUpgrade)).BeginInit();
            this.pnlZombieFastUpgrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxZombieFastUpgrade)).BeginInit();
            this.pnlDemonHelperUpgrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDemonHelperUpgrade)).BeginInit();
            this.pnlAltarUpgrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxAltarUpgrade)).BeginInit();
            this.pnlImpUpgrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxImpUpgrade)).BeginInit();
            this.pnlCouldronUpgrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxlCouldronUpgrade)).BeginInit();
            this.pnlBookUpgrade.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBookUpgrade)).BeginInit();
            this.fpnlAutoClickers.SuspendLayout();
            this.pnlZombie.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxZombie)).BeginInit();
            this.pnlGhoul.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGhoul)).BeginInit();
            this.pnlSkeleton.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSkeleton)).BeginInit();
            this.pnlVampire.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxVampire)).BeginInit();
            this.pnlWraith.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWraith)).BeginInit();
            this.pnlLich.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLich)).BeginInit();
            this.pnlDeathKnight.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeathKnight)).BeginInit();
            this.pnlDragon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxDragon)).BeginInit();
            this.pnlInformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClickThis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBackground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSoulieMan)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTitle
            // 
            this.pnlTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(97)))), ((int)(((byte)(94)))), ((int)(((byte)(164)))));
            this.pnlTitle.Controls.Add(this.btnAdminButton);
            this.pnlTitle.Controls.Add(this.btnHelp);
            this.pnlTitle.Controls.Add(this.btnExit);
            this.pnlTitle.Controls.Add(this.lblTitle);
            this.pnlTitle.Controls.Add(this.btnHighScores);
            this.pnlTitle.Location = new System.Drawing.Point(0, 0);
            this.pnlTitle.Name = "pnlTitle";
            this.pnlTitle.Size = new System.Drawing.Size(907, 59);
            this.pnlTitle.TabIndex = 0;
            // 
            // btnAdminButton
            // 
            this.btnAdminButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.btnAdminButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdminButton.Location = new System.Drawing.Point(1, 1);
            this.btnAdminButton.Name = "btnAdminButton";
            this.btnAdminButton.Size = new System.Drawing.Size(96, 56);
            this.btnAdminButton.TabIndex = 5;
            this.btnAdminButton.Text = "Admin Button gives 1mil souls";
            this.btnAdminButton.UseVisualStyleBackColor = false;
            this.btnAdminButton.Click += new System.EventHandler(this.btnAdminButton_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.btnHelp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHelp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnHelp.Location = new System.Drawing.Point(748, 3);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(75, 53);
            this.btnHelp.TabIndex = 4;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = false;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnExit.Location = new System.Drawing.Point(667, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 53);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit Game";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.lblTitle.Location = new System.Drawing.Point(3, 3);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(658, 56);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Necroclicker";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnHighScores
            // 
            this.btnHighScores.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.btnHighScores.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHighScores.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnHighScores.Location = new System.Drawing.Point(829, 3);
            this.btnHighScores.Name = "btnHighScores";
            this.btnHighScores.Size = new System.Drawing.Size(75, 53);
            this.btnHighScores.TabIndex = 1;
            this.btnHighScores.Text = "High Scores";
            this.btnHighScores.UseVisualStyleBackColor = false;
            this.btnHighScores.Click += new System.EventHandler(this.btnHighScores_Click);
            // 
            // pbxProfilePic
            // 
            this.pbxProfilePic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pbxProfilePic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxProfilePic.Image = ((System.Drawing.Image)(resources.GetObject("pbxProfilePic.Image")));
            this.pbxProfilePic.Location = new System.Drawing.Point(913, 0);
            this.pbxProfilePic.Name = "pbxProfilePic";
            this.pbxProfilePic.Size = new System.Drawing.Size(83, 59);
            this.pbxProfilePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxProfilePic.TabIndex = 4;
            this.pbxProfilePic.TabStop = false;
            this.pbxProfilePic.Click += new System.EventHandler(this.pbxProfilePic_Click);
            // 
            // fpnlUpgrades
            // 
            this.fpnlUpgrades.AutoScroll = true;
            this.fpnlUpgrades.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(97)))), ((int)(((byte)(94)))), ((int)(((byte)(164)))));
            this.fpnlUpgrades.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.fpnlUpgrades.Controls.Add(this.pnlDragonUpgradeArmor);
            this.fpnlUpgrades.Controls.Add(this.pnlDragonUpgradeFrostBreath);
            this.fpnlUpgrades.Controls.Add(this.pnlDragonUpgradeRider);
            this.fpnlUpgrades.Controls.Add(this.pnlDeathKnightUpgradeHorses);
            this.fpnlUpgrades.Controls.Add(this.pnlDeathKnightUpgradeRunedArmor);
            this.fpnlUpgrades.Controls.Add(this.pnlDeathKnightUpgradeSteel);
            this.fpnlUpgrades.Controls.Add(this.pnlLichUpgradeScrolls);
            this.fpnlUpgrades.Controls.Add(this.pnlLichUpgradeSummon);
            this.fpnlUpgrades.Controls.Add(this.pnlLichUpgradeMagic);
            this.fpnlUpgrades.Controls.Add(this.pnlWraithUpgradeWyvern);
            this.fpnlUpgrades.Controls.Add(this.pnlWraithUpgradeInfernalWeaponry);
            this.fpnlUpgrades.Controls.Add(this.pnlWraithUpgradeHorse);
            this.fpnlUpgrades.Controls.Add(this.pnlVampireUpgradeEnchantedWeaponry);
            this.fpnlUpgrades.Controls.Add(this.pnlVampireUpgradeBatForm);
            this.fpnlUpgrades.Controls.Add(this.pnlVampireUpgradeHealing);
            this.fpnlUpgrades.Controls.Add(this.pnlSkeletonUpgradeDarksteel);
            this.fpnlUpgrades.Controls.Add(this.pnlSkeletonUpgradeArmor);
            this.fpnlUpgrades.Controls.Add(this.pnlSkeletonUpgradeWeapons);
            this.fpnlUpgrades.Controls.Add(this.pnlGhoulUpgradeArmor);
            this.fpnlUpgrades.Controls.Add(this.pnlGhoulUpgradeParalysis);
            this.fpnlUpgrades.Controls.Add(this.pnlGhoulFangsUpgrade);
            this.fpnlUpgrades.Controls.Add(this.pnlZombieMutantUpgrade);
            this.fpnlUpgrades.Controls.Add(this.pnlZombieDiseasedUpgrade);
            this.fpnlUpgrades.Controls.Add(this.pnlZombieFastUpgrade);
            this.fpnlUpgrades.Controls.Add(this.pnlDemonHelperUpgrade);
            this.fpnlUpgrades.Controls.Add(this.pnlAltarUpgrade);
            this.fpnlUpgrades.Controls.Add(this.pnlImpUpgrade);
            this.fpnlUpgrades.Controls.Add(this.pnlCouldronUpgrade);
            this.fpnlUpgrades.Controls.Add(this.pnlBookUpgrade);
            this.fpnlUpgrades.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.fpnlUpgrades.Location = new System.Drawing.Point(678, 65);
            this.fpnlUpgrades.Name = "fpnlUpgrades";
            this.fpnlUpgrades.Size = new System.Drawing.Size(318, 165);
            this.fpnlUpgrades.TabIndex = 1;
            this.fpnlUpgrades.WrapContents = false;
            // 
            // pnlDragonUpgradeArmor
            // 
            this.pnlDragonUpgradeArmor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlDragonUpgradeArmor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDragonUpgradeArmor.Controls.Add(this.btnDragonUpgradeArmor);
            this.pnlDragonUpgradeArmor.Controls.Add(this.lblDragonUpgradeArmorDesc);
            this.pnlDragonUpgradeArmor.Controls.Add(this.lblDragonUpgradeArmorSPS);
            this.pnlDragonUpgradeArmor.Controls.Add(this.lblDragonUpgradeArmorCost);
            this.pnlDragonUpgradeArmor.Controls.Add(this.pbxDragonUpgradeArmor);
            this.pnlDragonUpgradeArmor.Enabled = false;
            this.pnlDragonUpgradeArmor.Location = new System.Drawing.Point(3, 3);
            this.pnlDragonUpgradeArmor.Name = "pnlDragonUpgradeArmor";
            this.pnlDragonUpgradeArmor.Size = new System.Drawing.Size(290, 70);
            this.pnlDragonUpgradeArmor.TabIndex = 29;
            this.pnlDragonUpgradeArmor.Visible = false;
            // 
            // btnDragonUpgradeArmor
            // 
            this.btnDragonUpgradeArmor.BackColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeArmor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeArmor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeArmor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDragonUpgradeArmor.ForeColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeArmor.Location = new System.Drawing.Point(-1, -1);
            this.btnDragonUpgradeArmor.Name = "btnDragonUpgradeArmor";
            this.btnDragonUpgradeArmor.Size = new System.Drawing.Size(290, 70);
            this.btnDragonUpgradeArmor.TabIndex = 31;
            this.btnDragonUpgradeArmor.UseVisualStyleBackColor = false;
            this.btnDragonUpgradeArmor.Click += new System.EventHandler(this.btnDragonUpgradeArmor_Click);
            // 
            // lblDragonUpgradeArmorDesc
            // 
            this.lblDragonUpgradeArmorDesc.Enabled = false;
            this.lblDragonUpgradeArmorDesc.ForeColor = System.Drawing.Color.White;
            this.lblDragonUpgradeArmorDesc.Location = new System.Drawing.Point(72, 39);
            this.lblDragonUpgradeArmorDesc.Name = "lblDragonUpgradeArmorDesc";
            this.lblDragonUpgradeArmorDesc.Size = new System.Drawing.Size(217, 28);
            this.lblDragonUpgradeArmorDesc.TabIndex = 3;
            this.lblDragonUpgradeArmorDesc.Text = "Draconic Armor. I thought draconic armor was meant for drakes not dragons.";
            this.lblDragonUpgradeArmorDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDragonUpgradeArmorSPS
            // 
            this.lblDragonUpgradeArmorSPS.Enabled = false;
            this.lblDragonUpgradeArmorSPS.ForeColor = System.Drawing.Color.White;
            this.lblDragonUpgradeArmorSPS.Location = new System.Drawing.Point(72, 21);
            this.lblDragonUpgradeArmorSPS.Name = "lblDragonUpgradeArmorSPS";
            this.lblDragonUpgradeArmorSPS.Size = new System.Drawing.Size(217, 18);
            this.lblDragonUpgradeArmorSPS.TabIndex = 2;
            this.lblDragonUpgradeArmorSPS.Text = "Dragon Upgrade. 10x more efficient";
            this.lblDragonUpgradeArmorSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDragonUpgradeArmorCost
            // 
            this.lblDragonUpgradeArmorCost.Enabled = false;
            this.lblDragonUpgradeArmorCost.ForeColor = System.Drawing.Color.White;
            this.lblDragonUpgradeArmorCost.Location = new System.Drawing.Point(72, 3);
            this.lblDragonUpgradeArmorCost.Name = "lblDragonUpgradeArmorCost";
            this.lblDragonUpgradeArmorCost.Size = new System.Drawing.Size(217, 18);
            this.lblDragonUpgradeArmorCost.TabIndex = 1;
            this.lblDragonUpgradeArmorCost.Text = "165,000,000,000 Souls";
            this.lblDragonUpgradeArmorCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxDragonUpgradeArmor
            // 
            this.pbxDragonUpgradeArmor.Enabled = false;
            this.pbxDragonUpgradeArmor.Location = new System.Drawing.Point(3, 2);
            this.pbxDragonUpgradeArmor.Name = "pbxDragonUpgradeArmor";
            this.pbxDragonUpgradeArmor.Size = new System.Drawing.Size(64, 64);
            this.pbxDragonUpgradeArmor.TabIndex = 0;
            this.pbxDragonUpgradeArmor.TabStop = false;
            // 
            // pnlDragonUpgradeFrostBreath
            // 
            this.pnlDragonUpgradeFrostBreath.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlDragonUpgradeFrostBreath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDragonUpgradeFrostBreath.Controls.Add(this.btnDragonUpgradeFrostBreath);
            this.pnlDragonUpgradeFrostBreath.Controls.Add(this.lblDragonUpgradeFrostBreathDesc);
            this.pnlDragonUpgradeFrostBreath.Controls.Add(this.lblDragonUpgradeFrostBreathSPS);
            this.pnlDragonUpgradeFrostBreath.Controls.Add(this.lblDragonUpgradeFrostBreathCost);
            this.pnlDragonUpgradeFrostBreath.Controls.Add(this.pbxDragonUpgradeFrostBreath);
            this.pnlDragonUpgradeFrostBreath.Enabled = false;
            this.pnlDragonUpgradeFrostBreath.Location = new System.Drawing.Point(3, 79);
            this.pnlDragonUpgradeFrostBreath.Name = "pnlDragonUpgradeFrostBreath";
            this.pnlDragonUpgradeFrostBreath.Size = new System.Drawing.Size(290, 70);
            this.pnlDragonUpgradeFrostBreath.TabIndex = 28;
            this.pnlDragonUpgradeFrostBreath.Visible = false;
            // 
            // btnDragonUpgradeFrostBreath
            // 
            this.btnDragonUpgradeFrostBreath.BackColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeFrostBreath.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeFrostBreath.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeFrostBreath.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDragonUpgradeFrostBreath.ForeColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeFrostBreath.Location = new System.Drawing.Point(-1, -1);
            this.btnDragonUpgradeFrostBreath.Name = "btnDragonUpgradeFrostBreath";
            this.btnDragonUpgradeFrostBreath.Size = new System.Drawing.Size(290, 70);
            this.btnDragonUpgradeFrostBreath.TabIndex = 30;
            this.btnDragonUpgradeFrostBreath.UseVisualStyleBackColor = false;
            this.btnDragonUpgradeFrostBreath.Click += new System.EventHandler(this.btnDragonUpgradeFrostBreath_Click);
            // 
            // lblDragonUpgradeFrostBreathDesc
            // 
            this.lblDragonUpgradeFrostBreathDesc.Enabled = false;
            this.lblDragonUpgradeFrostBreathDesc.ForeColor = System.Drawing.Color.White;
            this.lblDragonUpgradeFrostBreathDesc.Location = new System.Drawing.Point(72, 39);
            this.lblDragonUpgradeFrostBreathDesc.Name = "lblDragonUpgradeFrostBreathDesc";
            this.lblDragonUpgradeFrostBreathDesc.Size = new System.Drawing.Size(217, 28);
            this.lblDragonUpgradeFrostBreathDesc.TabIndex = 3;
            this.lblDragonUpgradeFrostBreathDesc.Text = "Frost Breath. I didn\'t know skeletons could breathe.";
            this.lblDragonUpgradeFrostBreathDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDragonUpgradeFrostBreathSPS
            // 
            this.lblDragonUpgradeFrostBreathSPS.Enabled = false;
            this.lblDragonUpgradeFrostBreathSPS.ForeColor = System.Drawing.Color.White;
            this.lblDragonUpgradeFrostBreathSPS.Location = new System.Drawing.Point(72, 21);
            this.lblDragonUpgradeFrostBreathSPS.Name = "lblDragonUpgradeFrostBreathSPS";
            this.lblDragonUpgradeFrostBreathSPS.Size = new System.Drawing.Size(217, 18);
            this.lblDragonUpgradeFrostBreathSPS.TabIndex = 2;
            this.lblDragonUpgradeFrostBreathSPS.Text = "Dragon Upgrade. 4x more efficient";
            this.lblDragonUpgradeFrostBreathSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDragonUpgradeFrostBreathCost
            // 
            this.lblDragonUpgradeFrostBreathCost.Enabled = false;
            this.lblDragonUpgradeFrostBreathCost.ForeColor = System.Drawing.Color.White;
            this.lblDragonUpgradeFrostBreathCost.Location = new System.Drawing.Point(72, 3);
            this.lblDragonUpgradeFrostBreathCost.Name = "lblDragonUpgradeFrostBreathCost";
            this.lblDragonUpgradeFrostBreathCost.Size = new System.Drawing.Size(217, 18);
            this.lblDragonUpgradeFrostBreathCost.TabIndex = 1;
            this.lblDragonUpgradeFrostBreathCost.Text = "16,500,000,000 Souls";
            this.lblDragonUpgradeFrostBreathCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxDragonUpgradeFrostBreath
            // 
            this.pbxDragonUpgradeFrostBreath.Enabled = false;
            this.pbxDragonUpgradeFrostBreath.Location = new System.Drawing.Point(3, 2);
            this.pbxDragonUpgradeFrostBreath.Name = "pbxDragonUpgradeFrostBreath";
            this.pbxDragonUpgradeFrostBreath.Size = new System.Drawing.Size(64, 64);
            this.pbxDragonUpgradeFrostBreath.TabIndex = 0;
            this.pbxDragonUpgradeFrostBreath.TabStop = false;
            // 
            // pnlDragonUpgradeRider
            // 
            this.pnlDragonUpgradeRider.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlDragonUpgradeRider.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDragonUpgradeRider.Controls.Add(this.btnDragonUpgradeRider);
            this.pnlDragonUpgradeRider.Controls.Add(this.lblDragonUpgradeRiderDesc);
            this.pnlDragonUpgradeRider.Controls.Add(this.lblDragonUpgradeRiderSPS);
            this.pnlDragonUpgradeRider.Controls.Add(this.lblDragonUpgradeRiderCost);
            this.pnlDragonUpgradeRider.Controls.Add(this.pbxDragonUpgradeRider);
            this.pnlDragonUpgradeRider.Enabled = false;
            this.pnlDragonUpgradeRider.Location = new System.Drawing.Point(3, 155);
            this.pnlDragonUpgradeRider.Name = "pnlDragonUpgradeRider";
            this.pnlDragonUpgradeRider.Size = new System.Drawing.Size(290, 70);
            this.pnlDragonUpgradeRider.TabIndex = 27;
            this.pnlDragonUpgradeRider.Visible = false;
            // 
            // btnDragonUpgradeRider
            // 
            this.btnDragonUpgradeRider.BackColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeRider.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeRider.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeRider.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDragonUpgradeRider.ForeColor = System.Drawing.Color.Transparent;
            this.btnDragonUpgradeRider.Location = new System.Drawing.Point(-1, -1);
            this.btnDragonUpgradeRider.Name = "btnDragonUpgradeRider";
            this.btnDragonUpgradeRider.Size = new System.Drawing.Size(290, 70);
            this.btnDragonUpgradeRider.TabIndex = 29;
            this.btnDragonUpgradeRider.UseVisualStyleBackColor = false;
            this.btnDragonUpgradeRider.Click += new System.EventHandler(this.btnDragonUpgradeRider_Click);
            // 
            // lblDragonUpgradeRiderDesc
            // 
            this.lblDragonUpgradeRiderDesc.Enabled = false;
            this.lblDragonUpgradeRiderDesc.ForeColor = System.Drawing.Color.White;
            this.lblDragonUpgradeRiderDesc.Location = new System.Drawing.Point(72, 39);
            this.lblDragonUpgradeRiderDesc.Name = "lblDragonUpgradeRiderDesc";
            this.lblDragonUpgradeRiderDesc.Size = new System.Drawing.Size(217, 28);
            this.lblDragonUpgradeRiderDesc.TabIndex = 3;
            this.lblDragonUpgradeRiderDesc.Text = "Dragon Rider. More like dragon dinner.";
            this.lblDragonUpgradeRiderDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDragonUpgradeRiderSPS
            // 
            this.lblDragonUpgradeRiderSPS.Enabled = false;
            this.lblDragonUpgradeRiderSPS.ForeColor = System.Drawing.Color.White;
            this.lblDragonUpgradeRiderSPS.Location = new System.Drawing.Point(72, 21);
            this.lblDragonUpgradeRiderSPS.Name = "lblDragonUpgradeRiderSPS";
            this.lblDragonUpgradeRiderSPS.Size = new System.Drawing.Size(217, 18);
            this.lblDragonUpgradeRiderSPS.TabIndex = 2;
            this.lblDragonUpgradeRiderSPS.Text = "Dragon Upgrade. 2x more efficient";
            this.lblDragonUpgradeRiderSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDragonUpgradeRiderCost
            // 
            this.lblDragonUpgradeRiderCost.Enabled = false;
            this.lblDragonUpgradeRiderCost.ForeColor = System.Drawing.Color.White;
            this.lblDragonUpgradeRiderCost.Location = new System.Drawing.Point(72, 3);
            this.lblDragonUpgradeRiderCost.Name = "lblDragonUpgradeRiderCost";
            this.lblDragonUpgradeRiderCost.Size = new System.Drawing.Size(217, 18);
            this.lblDragonUpgradeRiderCost.TabIndex = 1;
            this.lblDragonUpgradeRiderCost.Text = "3,300,000,000 Souls";
            this.lblDragonUpgradeRiderCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxDragonUpgradeRider
            // 
            this.pbxDragonUpgradeRider.Enabled = false;
            this.pbxDragonUpgradeRider.Location = new System.Drawing.Point(3, 2);
            this.pbxDragonUpgradeRider.Name = "pbxDragonUpgradeRider";
            this.pbxDragonUpgradeRider.Size = new System.Drawing.Size(64, 64);
            this.pbxDragonUpgradeRider.TabIndex = 0;
            this.pbxDragonUpgradeRider.TabStop = false;
            // 
            // pnlDeathKnightUpgradeHorses
            // 
            this.pnlDeathKnightUpgradeHorses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlDeathKnightUpgradeHorses.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDeathKnightUpgradeHorses.Controls.Add(this.btnDeathKnightUpgradeHorses);
            this.pnlDeathKnightUpgradeHorses.Controls.Add(this.lblDeathKnightUpgradeHorsesDesc);
            this.pnlDeathKnightUpgradeHorses.Controls.Add(this.lblDeathKnightUpgradeHorsesSPS);
            this.pnlDeathKnightUpgradeHorses.Controls.Add(this.lblDeathKnightUpgradeHorsesCost);
            this.pnlDeathKnightUpgradeHorses.Controls.Add(this.pbxDeathKnightUpgradeHorses);
            this.pnlDeathKnightUpgradeHorses.Enabled = false;
            this.pnlDeathKnightUpgradeHorses.Location = new System.Drawing.Point(3, 231);
            this.pnlDeathKnightUpgradeHorses.Name = "pnlDeathKnightUpgradeHorses";
            this.pnlDeathKnightUpgradeHorses.Size = new System.Drawing.Size(290, 70);
            this.pnlDeathKnightUpgradeHorses.TabIndex = 26;
            this.pnlDeathKnightUpgradeHorses.Visible = false;
            // 
            // btnDeathKnightUpgradeHorses
            // 
            this.btnDeathKnightUpgradeHorses.BackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeHorses.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeHorses.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeHorses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeathKnightUpgradeHorses.ForeColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeHorses.Location = new System.Drawing.Point(-1, -1);
            this.btnDeathKnightUpgradeHorses.Name = "btnDeathKnightUpgradeHorses";
            this.btnDeathKnightUpgradeHorses.Size = new System.Drawing.Size(290, 70);
            this.btnDeathKnightUpgradeHorses.TabIndex = 28;
            this.btnDeathKnightUpgradeHorses.UseVisualStyleBackColor = false;
            this.btnDeathKnightUpgradeHorses.Click += new System.EventHandler(this.btnDeathKnightUpgradeHorses_Click);
            // 
            // lblDeathKnightUpgradeHorsesDesc
            // 
            this.lblDeathKnightUpgradeHorsesDesc.Enabled = false;
            this.lblDeathKnightUpgradeHorsesDesc.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightUpgradeHorsesDesc.Location = new System.Drawing.Point(72, 39);
            this.lblDeathKnightUpgradeHorsesDesc.Name = "lblDeathKnightUpgradeHorsesDesc";
            this.lblDeathKnightUpgradeHorsesDesc.Size = new System.Drawing.Size(217, 28);
            this.lblDeathKnightUpgradeHorsesDesc.TabIndex = 3;
            this.lblDeathKnightUpgradeHorsesDesc.Text = "Shadow Horses. I bet the wraiths are jelous.";
            this.lblDeathKnightUpgradeHorsesDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDeathKnightUpgradeHorsesSPS
            // 
            this.lblDeathKnightUpgradeHorsesSPS.Enabled = false;
            this.lblDeathKnightUpgradeHorsesSPS.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightUpgradeHorsesSPS.Location = new System.Drawing.Point(72, 21);
            this.lblDeathKnightUpgradeHorsesSPS.Name = "lblDeathKnightUpgradeHorsesSPS";
            this.lblDeathKnightUpgradeHorsesSPS.Size = new System.Drawing.Size(217, 18);
            this.lblDeathKnightUpgradeHorsesSPS.TabIndex = 2;
            this.lblDeathKnightUpgradeHorsesSPS.Text = "Death Knight Upgrade. 10x more efficient";
            this.lblDeathKnightUpgradeHorsesSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDeathKnightUpgradeHorsesCost
            // 
            this.lblDeathKnightUpgradeHorsesCost.Enabled = false;
            this.lblDeathKnightUpgradeHorsesCost.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightUpgradeHorsesCost.Location = new System.Drawing.Point(72, 3);
            this.lblDeathKnightUpgradeHorsesCost.Name = "lblDeathKnightUpgradeHorsesCost";
            this.lblDeathKnightUpgradeHorsesCost.Size = new System.Drawing.Size(217, 18);
            this.lblDeathKnightUpgradeHorsesCost.TabIndex = 1;
            this.lblDeathKnightUpgradeHorsesCost.Text = "10,000,000,000 Souls";
            this.lblDeathKnightUpgradeHorsesCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxDeathKnightUpgradeHorses
            // 
            this.pbxDeathKnightUpgradeHorses.Enabled = false;
            this.pbxDeathKnightUpgradeHorses.Location = new System.Drawing.Point(3, 2);
            this.pbxDeathKnightUpgradeHorses.Name = "pbxDeathKnightUpgradeHorses";
            this.pbxDeathKnightUpgradeHorses.Size = new System.Drawing.Size(64, 64);
            this.pbxDeathKnightUpgradeHorses.TabIndex = 0;
            this.pbxDeathKnightUpgradeHorses.TabStop = false;
            // 
            // pnlDeathKnightUpgradeRunedArmor
            // 
            this.pnlDeathKnightUpgradeRunedArmor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlDeathKnightUpgradeRunedArmor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDeathKnightUpgradeRunedArmor.Controls.Add(this.btnDeathKnightUpgradeRunedArmor);
            this.pnlDeathKnightUpgradeRunedArmor.Controls.Add(this.lblDeathKnightUpgradeRunedArmorDesc);
            this.pnlDeathKnightUpgradeRunedArmor.Controls.Add(this.lblDeathKnightUpgradeRunedArmorSPS);
            this.pnlDeathKnightUpgradeRunedArmor.Controls.Add(this.lblDeathKnightUpgradeRunedArmorCost);
            this.pnlDeathKnightUpgradeRunedArmor.Controls.Add(this.pbxDeathKnightUpgradeRunedArmor);
            this.pnlDeathKnightUpgradeRunedArmor.Enabled = false;
            this.pnlDeathKnightUpgradeRunedArmor.Location = new System.Drawing.Point(3, 307);
            this.pnlDeathKnightUpgradeRunedArmor.Name = "pnlDeathKnightUpgradeRunedArmor";
            this.pnlDeathKnightUpgradeRunedArmor.Size = new System.Drawing.Size(290, 70);
            this.pnlDeathKnightUpgradeRunedArmor.TabIndex = 25;
            this.pnlDeathKnightUpgradeRunedArmor.Visible = false;
            // 
            // btnDeathKnightUpgradeRunedArmor
            // 
            this.btnDeathKnightUpgradeRunedArmor.BackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeRunedArmor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeRunedArmor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeRunedArmor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeathKnightUpgradeRunedArmor.ForeColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeRunedArmor.Location = new System.Drawing.Point(-1, -1);
            this.btnDeathKnightUpgradeRunedArmor.Name = "btnDeathKnightUpgradeRunedArmor";
            this.btnDeathKnightUpgradeRunedArmor.Size = new System.Drawing.Size(290, 70);
            this.btnDeathKnightUpgradeRunedArmor.TabIndex = 27;
            this.btnDeathKnightUpgradeRunedArmor.UseVisualStyleBackColor = false;
            this.btnDeathKnightUpgradeRunedArmor.Click += new System.EventHandler(this.btnDeathKnightUpgradeRunedArmor_Click);
            // 
            // lblDeathKnightUpgradeRunedArmorDesc
            // 
            this.lblDeathKnightUpgradeRunedArmorDesc.Enabled = false;
            this.lblDeathKnightUpgradeRunedArmorDesc.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightUpgradeRunedArmorDesc.Location = new System.Drawing.Point(72, 39);
            this.lblDeathKnightUpgradeRunedArmorDesc.Name = "lblDeathKnightUpgradeRunedArmorDesc";
            this.lblDeathKnightUpgradeRunedArmorDesc.Size = new System.Drawing.Size(217, 28);
            this.lblDeathKnightUpgradeRunedArmorDesc.TabIndex = 3;
            this.lblDeathKnightUpgradeRunedArmorDesc.Text = "Runed Armor. Its some kind of elvish. I can\'t read it.";
            this.lblDeathKnightUpgradeRunedArmorDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDeathKnightUpgradeRunedArmorSPS
            // 
            this.lblDeathKnightUpgradeRunedArmorSPS.Enabled = false;
            this.lblDeathKnightUpgradeRunedArmorSPS.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightUpgradeRunedArmorSPS.Location = new System.Drawing.Point(72, 21);
            this.lblDeathKnightUpgradeRunedArmorSPS.Name = "lblDeathKnightUpgradeRunedArmorSPS";
            this.lblDeathKnightUpgradeRunedArmorSPS.Size = new System.Drawing.Size(217, 18);
            this.lblDeathKnightUpgradeRunedArmorSPS.TabIndex = 2;
            this.lblDeathKnightUpgradeRunedArmorSPS.Text = "Death Knight Upgrade. 4x more efficient";
            this.lblDeathKnightUpgradeRunedArmorSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDeathKnightUpgradeRunedArmorCost
            // 
            this.lblDeathKnightUpgradeRunedArmorCost.Enabled = false;
            this.lblDeathKnightUpgradeRunedArmorCost.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightUpgradeRunedArmorCost.Location = new System.Drawing.Point(72, 3);
            this.lblDeathKnightUpgradeRunedArmorCost.Name = "lblDeathKnightUpgradeRunedArmorCost";
            this.lblDeathKnightUpgradeRunedArmorCost.Size = new System.Drawing.Size(217, 18);
            this.lblDeathKnightUpgradeRunedArmorCost.TabIndex = 1;
            this.lblDeathKnightUpgradeRunedArmorCost.Text = "1,000,000,000 Souls";
            this.lblDeathKnightUpgradeRunedArmorCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxDeathKnightUpgradeRunedArmor
            // 
            this.pbxDeathKnightUpgradeRunedArmor.Enabled = false;
            this.pbxDeathKnightUpgradeRunedArmor.Location = new System.Drawing.Point(3, 2);
            this.pbxDeathKnightUpgradeRunedArmor.Name = "pbxDeathKnightUpgradeRunedArmor";
            this.pbxDeathKnightUpgradeRunedArmor.Size = new System.Drawing.Size(64, 64);
            this.pbxDeathKnightUpgradeRunedArmor.TabIndex = 0;
            this.pbxDeathKnightUpgradeRunedArmor.TabStop = false;
            // 
            // pnlDeathKnightUpgradeSteel
            // 
            this.pnlDeathKnightUpgradeSteel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlDeathKnightUpgradeSteel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDeathKnightUpgradeSteel.Controls.Add(this.btnDeathKnightUpgradeSteel);
            this.pnlDeathKnightUpgradeSteel.Controls.Add(this.lblDeathKnightUpgradeSteelDesc);
            this.pnlDeathKnightUpgradeSteel.Controls.Add(this.lblDeathKnightUpgradeSteelSPS);
            this.pnlDeathKnightUpgradeSteel.Controls.Add(this.lblDeathKnightUpgradeSteelCost);
            this.pnlDeathKnightUpgradeSteel.Controls.Add(this.pbxDeathKnightUpgradeSteel);
            this.pnlDeathKnightUpgradeSteel.Enabled = false;
            this.pnlDeathKnightUpgradeSteel.Location = new System.Drawing.Point(3, 383);
            this.pnlDeathKnightUpgradeSteel.Name = "pnlDeathKnightUpgradeSteel";
            this.pnlDeathKnightUpgradeSteel.Size = new System.Drawing.Size(290, 70);
            this.pnlDeathKnightUpgradeSteel.TabIndex = 24;
            this.pnlDeathKnightUpgradeSteel.Visible = false;
            // 
            // btnDeathKnightUpgradeSteel
            // 
            this.btnDeathKnightUpgradeSteel.BackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeSteel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeSteel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeSteel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeathKnightUpgradeSteel.ForeColor = System.Drawing.Color.Transparent;
            this.btnDeathKnightUpgradeSteel.Location = new System.Drawing.Point(-1, -1);
            this.btnDeathKnightUpgradeSteel.Name = "btnDeathKnightUpgradeSteel";
            this.btnDeathKnightUpgradeSteel.Size = new System.Drawing.Size(290, 70);
            this.btnDeathKnightUpgradeSteel.TabIndex = 26;
            this.btnDeathKnightUpgradeSteel.UseVisualStyleBackColor = false;
            this.btnDeathKnightUpgradeSteel.Click += new System.EventHandler(this.btnDeathKnightUpgradeSteel_Click);
            // 
            // lblDeathKnightUpgradeSteelDesc
            // 
            this.lblDeathKnightUpgradeSteelDesc.Enabled = false;
            this.lblDeathKnightUpgradeSteelDesc.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightUpgradeSteelDesc.Location = new System.Drawing.Point(72, 39);
            this.lblDeathKnightUpgradeSteelDesc.Name = "lblDeathKnightUpgradeSteelDesc";
            this.lblDeathKnightUpgradeSteelDesc.Size = new System.Drawing.Size(217, 28);
            this.lblDeathKnightUpgradeSteelDesc.TabIndex = 3;
            this.lblDeathKnightUpgradeSteelDesc.Text = "Bloodforged Steel Weaponry. Blood, sweat, and tears went into making these.";
            this.lblDeathKnightUpgradeSteelDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDeathKnightUpgradeSteelSPS
            // 
            this.lblDeathKnightUpgradeSteelSPS.Enabled = false;
            this.lblDeathKnightUpgradeSteelSPS.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightUpgradeSteelSPS.Location = new System.Drawing.Point(72, 21);
            this.lblDeathKnightUpgradeSteelSPS.Name = "lblDeathKnightUpgradeSteelSPS";
            this.lblDeathKnightUpgradeSteelSPS.Size = new System.Drawing.Size(217, 18);
            this.lblDeathKnightUpgradeSteelSPS.TabIndex = 2;
            this.lblDeathKnightUpgradeSteelSPS.Text = "Death Knight Upgrade. 2x more efficient";
            this.lblDeathKnightUpgradeSteelSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDeathKnightUpgradeSteelCost
            // 
            this.lblDeathKnightUpgradeSteelCost.Enabled = false;
            this.lblDeathKnightUpgradeSteelCost.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightUpgradeSteelCost.Location = new System.Drawing.Point(72, 3);
            this.lblDeathKnightUpgradeSteelCost.Name = "lblDeathKnightUpgradeSteelCost";
            this.lblDeathKnightUpgradeSteelCost.Size = new System.Drawing.Size(217, 18);
            this.lblDeathKnightUpgradeSteelCost.TabIndex = 1;
            this.lblDeathKnightUpgradeSteelCost.Text = "200,000,000 Souls";
            this.lblDeathKnightUpgradeSteelCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxDeathKnightUpgradeSteel
            // 
            this.pbxDeathKnightUpgradeSteel.Enabled = false;
            this.pbxDeathKnightUpgradeSteel.Location = new System.Drawing.Point(3, 2);
            this.pbxDeathKnightUpgradeSteel.Name = "pbxDeathKnightUpgradeSteel";
            this.pbxDeathKnightUpgradeSteel.Size = new System.Drawing.Size(64, 64);
            this.pbxDeathKnightUpgradeSteel.TabIndex = 0;
            this.pbxDeathKnightUpgradeSteel.TabStop = false;
            // 
            // pnlLichUpgradeScrolls
            // 
            this.pnlLichUpgradeScrolls.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlLichUpgradeScrolls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLichUpgradeScrolls.Controls.Add(this.btnLichUpgradeScrolls);
            this.pnlLichUpgradeScrolls.Controls.Add(this.lblLichUpgradeScrollsDesc);
            this.pnlLichUpgradeScrolls.Controls.Add(this.lblLichUpgradeScrollsSPS);
            this.pnlLichUpgradeScrolls.Controls.Add(this.lblLichUpgradeScrollsCost);
            this.pnlLichUpgradeScrolls.Controls.Add(this.pbxLichUpgradeScrolls);
            this.pnlLichUpgradeScrolls.Enabled = false;
            this.pnlLichUpgradeScrolls.Location = new System.Drawing.Point(3, 459);
            this.pnlLichUpgradeScrolls.Name = "pnlLichUpgradeScrolls";
            this.pnlLichUpgradeScrolls.Size = new System.Drawing.Size(290, 70);
            this.pnlLichUpgradeScrolls.TabIndex = 23;
            this.pnlLichUpgradeScrolls.Visible = false;
            // 
            // btnLichUpgradeScrolls
            // 
            this.btnLichUpgradeScrolls.BackColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeScrolls.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeScrolls.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeScrolls.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLichUpgradeScrolls.ForeColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeScrolls.Location = new System.Drawing.Point(-1, -1);
            this.btnLichUpgradeScrolls.Name = "btnLichUpgradeScrolls";
            this.btnLichUpgradeScrolls.Size = new System.Drawing.Size(290, 70);
            this.btnLichUpgradeScrolls.TabIndex = 25;
            this.btnLichUpgradeScrolls.UseVisualStyleBackColor = false;
            this.btnLichUpgradeScrolls.Click += new System.EventHandler(this.btnLichUpgradeScrolls_Click);
            // 
            // lblLichUpgradeScrollsDesc
            // 
            this.lblLichUpgradeScrollsDesc.Enabled = false;
            this.lblLichUpgradeScrollsDesc.ForeColor = System.Drawing.Color.White;
            this.lblLichUpgradeScrollsDesc.Location = new System.Drawing.Point(72, 39);
            this.lblLichUpgradeScrollsDesc.Name = "lblLichUpgradeScrollsDesc";
            this.lblLichUpgradeScrollsDesc.Size = new System.Drawing.Size(217, 28);
            this.lblLichUpgradeScrollsDesc.TabIndex = 3;
            this.lblLichUpgradeScrollsDesc.Text = "Demonic Scrolls. Its like kindergarden all over again.";
            this.lblLichUpgradeScrollsDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLichUpgradeScrollsSPS
            // 
            this.lblLichUpgradeScrollsSPS.Enabled = false;
            this.lblLichUpgradeScrollsSPS.ForeColor = System.Drawing.Color.White;
            this.lblLichUpgradeScrollsSPS.Location = new System.Drawing.Point(72, 21);
            this.lblLichUpgradeScrollsSPS.Name = "lblLichUpgradeScrollsSPS";
            this.lblLichUpgradeScrollsSPS.Size = new System.Drawing.Size(217, 18);
            this.lblLichUpgradeScrollsSPS.TabIndex = 2;
            this.lblLichUpgradeScrollsSPS.Text = "Lich Upgrade. 10x more efficient";
            this.lblLichUpgradeScrollsSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLichUpgradeScrollsCost
            // 
            this.lblLichUpgradeScrollsCost.Enabled = false;
            this.lblLichUpgradeScrollsCost.ForeColor = System.Drawing.Color.White;
            this.lblLichUpgradeScrollsCost.Location = new System.Drawing.Point(72, 3);
            this.lblLichUpgradeScrollsCost.Name = "lblLichUpgradeScrollsCost";
            this.lblLichUpgradeScrollsCost.Size = new System.Drawing.Size(217, 18);
            this.lblLichUpgradeScrollsCost.TabIndex = 1;
            this.lblLichUpgradeScrollsCost.Text = "700,000,000 Souls";
            this.lblLichUpgradeScrollsCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxLichUpgradeScrolls
            // 
            this.pbxLichUpgradeScrolls.Enabled = false;
            this.pbxLichUpgradeScrolls.Location = new System.Drawing.Point(3, 2);
            this.pbxLichUpgradeScrolls.Name = "pbxLichUpgradeScrolls";
            this.pbxLichUpgradeScrolls.Size = new System.Drawing.Size(64, 64);
            this.pbxLichUpgradeScrolls.TabIndex = 0;
            this.pbxLichUpgradeScrolls.TabStop = false;
            // 
            // pnlLichUpgradeSummon
            // 
            this.pnlLichUpgradeSummon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlLichUpgradeSummon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLichUpgradeSummon.Controls.Add(this.btnLichUpgradeSummon);
            this.pnlLichUpgradeSummon.Controls.Add(this.lblLichUpgradeSummonDesc);
            this.pnlLichUpgradeSummon.Controls.Add(this.lblLichUpgradeSummonSPS);
            this.pnlLichUpgradeSummon.Controls.Add(this.lblLichUpgradeSummonCost);
            this.pnlLichUpgradeSummon.Controls.Add(this.pbxLichUpgradeSummon);
            this.pnlLichUpgradeSummon.Enabled = false;
            this.pnlLichUpgradeSummon.Location = new System.Drawing.Point(3, 535);
            this.pnlLichUpgradeSummon.Name = "pnlLichUpgradeSummon";
            this.pnlLichUpgradeSummon.Size = new System.Drawing.Size(290, 70);
            this.pnlLichUpgradeSummon.TabIndex = 22;
            this.pnlLichUpgradeSummon.Visible = false;
            // 
            // btnLichUpgradeSummon
            // 
            this.btnLichUpgradeSummon.BackColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeSummon.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeSummon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeSummon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLichUpgradeSummon.ForeColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeSummon.Location = new System.Drawing.Point(-1, -1);
            this.btnLichUpgradeSummon.Name = "btnLichUpgradeSummon";
            this.btnLichUpgradeSummon.Size = new System.Drawing.Size(290, 70);
            this.btnLichUpgradeSummon.TabIndex = 24;
            this.btnLichUpgradeSummon.UseVisualStyleBackColor = false;
            this.btnLichUpgradeSummon.Click += new System.EventHandler(this.btnLichUpgradeSummon_Click);
            // 
            // lblLichUpgradeSummonDesc
            // 
            this.lblLichUpgradeSummonDesc.Enabled = false;
            this.lblLichUpgradeSummonDesc.ForeColor = System.Drawing.Color.White;
            this.lblLichUpgradeSummonDesc.Location = new System.Drawing.Point(72, 39);
            this.lblLichUpgradeSummonDesc.Name = "lblLichUpgradeSummonDesc";
            this.lblLichUpgradeSummonDesc.Size = new System.Drawing.Size(217, 28);
            this.lblLichUpgradeSummonDesc.TabIndex = 3;
            this.lblLichUpgradeSummonDesc.Text = "Summon Lesser Undead. Oh boy! mini mes!";
            this.lblLichUpgradeSummonDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLichUpgradeSummonSPS
            // 
            this.lblLichUpgradeSummonSPS.Enabled = false;
            this.lblLichUpgradeSummonSPS.ForeColor = System.Drawing.Color.White;
            this.lblLichUpgradeSummonSPS.Location = new System.Drawing.Point(72, 21);
            this.lblLichUpgradeSummonSPS.Name = "lblLichUpgradeSummonSPS";
            this.lblLichUpgradeSummonSPS.Size = new System.Drawing.Size(217, 18);
            this.lblLichUpgradeSummonSPS.TabIndex = 2;
            this.lblLichUpgradeSummonSPS.Text = "Lich Upgrade. 4x more efficient";
            this.lblLichUpgradeSummonSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLichUpgradeSummonCost
            // 
            this.lblLichUpgradeSummonCost.Enabled = false;
            this.lblLichUpgradeSummonCost.ForeColor = System.Drawing.Color.White;
            this.lblLichUpgradeSummonCost.Location = new System.Drawing.Point(72, 3);
            this.lblLichUpgradeSummonCost.Name = "lblLichUpgradeSummonCost";
            this.lblLichUpgradeSummonCost.Size = new System.Drawing.Size(217, 18);
            this.lblLichUpgradeSummonCost.TabIndex = 1;
            this.lblLichUpgradeSummonCost.Text = "70,000,000 Souls";
            this.lblLichUpgradeSummonCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxLichUpgradeSummon
            // 
            this.pbxLichUpgradeSummon.Enabled = false;
            this.pbxLichUpgradeSummon.Location = new System.Drawing.Point(3, 2);
            this.pbxLichUpgradeSummon.Name = "pbxLichUpgradeSummon";
            this.pbxLichUpgradeSummon.Size = new System.Drawing.Size(64, 64);
            this.pbxLichUpgradeSummon.TabIndex = 0;
            this.pbxLichUpgradeSummon.TabStop = false;
            // 
            // pnlLichUpgradeMagic
            // 
            this.pnlLichUpgradeMagic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlLichUpgradeMagic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLichUpgradeMagic.Controls.Add(this.btnLichUpgradeMagic);
            this.pnlLichUpgradeMagic.Controls.Add(this.lblLichUpgradeMagicDesc);
            this.pnlLichUpgradeMagic.Controls.Add(this.lblLichUpgradeMagicSPS);
            this.pnlLichUpgradeMagic.Controls.Add(this.lblLichUpgradeMagicCost);
            this.pnlLichUpgradeMagic.Controls.Add(this.pbxLichUpgradeMagic);
            this.pnlLichUpgradeMagic.Enabled = false;
            this.pnlLichUpgradeMagic.Location = new System.Drawing.Point(3, 611);
            this.pnlLichUpgradeMagic.Name = "pnlLichUpgradeMagic";
            this.pnlLichUpgradeMagic.Size = new System.Drawing.Size(290, 70);
            this.pnlLichUpgradeMagic.TabIndex = 21;
            this.pnlLichUpgradeMagic.Visible = false;
            // 
            // btnLichUpgradeMagic
            // 
            this.btnLichUpgradeMagic.BackColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeMagic.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeMagic.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeMagic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLichUpgradeMagic.ForeColor = System.Drawing.Color.Transparent;
            this.btnLichUpgradeMagic.Location = new System.Drawing.Point(-1, -1);
            this.btnLichUpgradeMagic.Name = "btnLichUpgradeMagic";
            this.btnLichUpgradeMagic.Size = new System.Drawing.Size(290, 70);
            this.btnLichUpgradeMagic.TabIndex = 23;
            this.btnLichUpgradeMagic.UseVisualStyleBackColor = false;
            this.btnLichUpgradeMagic.Click += new System.EventHandler(this.btnLichUpgradeMagic_Click);
            // 
            // lblLichUpgradeMagicDesc
            // 
            this.lblLichUpgradeMagicDesc.Enabled = false;
            this.lblLichUpgradeMagicDesc.ForeColor = System.Drawing.Color.White;
            this.lblLichUpgradeMagicDesc.Location = new System.Drawing.Point(72, 39);
            this.lblLichUpgradeMagicDesc.Name = "lblLichUpgradeMagicDesc";
            this.lblLichUpgradeMagicDesc.Size = new System.Drawing.Size(217, 28);
            this.lblLichUpgradeMagicDesc.TabIndex = 3;
            this.lblLichUpgradeMagicDesc.Text = "Blood Magic. What if something doesn\'t have any blood?";
            this.lblLichUpgradeMagicDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLichUpgradeMagicSPS
            // 
            this.lblLichUpgradeMagicSPS.Enabled = false;
            this.lblLichUpgradeMagicSPS.ForeColor = System.Drawing.Color.White;
            this.lblLichUpgradeMagicSPS.Location = new System.Drawing.Point(72, 21);
            this.lblLichUpgradeMagicSPS.Name = "lblLichUpgradeMagicSPS";
            this.lblLichUpgradeMagicSPS.Size = new System.Drawing.Size(217, 18);
            this.lblLichUpgradeMagicSPS.TabIndex = 2;
            this.lblLichUpgradeMagicSPS.Text = "Lich Upgrade. 2x more efficient";
            this.lblLichUpgradeMagicSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLichUpgradeMagicCost
            // 
            this.lblLichUpgradeMagicCost.Enabled = false;
            this.lblLichUpgradeMagicCost.ForeColor = System.Drawing.Color.White;
            this.lblLichUpgradeMagicCost.Location = new System.Drawing.Point(72, 3);
            this.lblLichUpgradeMagicCost.Name = "lblLichUpgradeMagicCost";
            this.lblLichUpgradeMagicCost.Size = new System.Drawing.Size(217, 18);
            this.lblLichUpgradeMagicCost.TabIndex = 1;
            this.lblLichUpgradeMagicCost.Text = "14,000,000 Souls";
            this.lblLichUpgradeMagicCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxLichUpgradeMagic
            // 
            this.pbxLichUpgradeMagic.Enabled = false;
            this.pbxLichUpgradeMagic.Location = new System.Drawing.Point(3, 2);
            this.pbxLichUpgradeMagic.Name = "pbxLichUpgradeMagic";
            this.pbxLichUpgradeMagic.Size = new System.Drawing.Size(64, 64);
            this.pbxLichUpgradeMagic.TabIndex = 0;
            this.pbxLichUpgradeMagic.TabStop = false;
            // 
            // pnlWraithUpgradeWyvern
            // 
            this.pnlWraithUpgradeWyvern.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlWraithUpgradeWyvern.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWraithUpgradeWyvern.Controls.Add(this.btnWraithUpgradeWyvern);
            this.pnlWraithUpgradeWyvern.Controls.Add(this.lblWraithUpgradeWyvernDesc);
            this.pnlWraithUpgradeWyvern.Controls.Add(this.lblWraithUpgradeWyvernSPS);
            this.pnlWraithUpgradeWyvern.Controls.Add(this.lblWraithUpgradeWyvernCost);
            this.pnlWraithUpgradeWyvern.Controls.Add(this.pbxWraithUpgradeWyvern);
            this.pnlWraithUpgradeWyvern.Enabled = false;
            this.pnlWraithUpgradeWyvern.Location = new System.Drawing.Point(3, 687);
            this.pnlWraithUpgradeWyvern.Name = "pnlWraithUpgradeWyvern";
            this.pnlWraithUpgradeWyvern.Size = new System.Drawing.Size(290, 70);
            this.pnlWraithUpgradeWyvern.TabIndex = 20;
            this.pnlWraithUpgradeWyvern.Visible = false;
            // 
            // btnWraithUpgradeWyvern
            // 
            this.btnWraithUpgradeWyvern.BackColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeWyvern.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeWyvern.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeWyvern.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWraithUpgradeWyvern.ForeColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeWyvern.Location = new System.Drawing.Point(-1, -1);
            this.btnWraithUpgradeWyvern.Name = "btnWraithUpgradeWyvern";
            this.btnWraithUpgradeWyvern.Size = new System.Drawing.Size(290, 70);
            this.btnWraithUpgradeWyvern.TabIndex = 22;
            this.btnWraithUpgradeWyvern.UseVisualStyleBackColor = false;
            this.btnWraithUpgradeWyvern.Click += new System.EventHandler(this.btnWraithUpgradeWyvern_Click);
            // 
            // lblWraithUpgradeWyvernDesc
            // 
            this.lblWraithUpgradeWyvernDesc.Enabled = false;
            this.lblWraithUpgradeWyvernDesc.ForeColor = System.Drawing.Color.White;
            this.lblWraithUpgradeWyvernDesc.Location = new System.Drawing.Point(72, 39);
            this.lblWraithUpgradeWyvernDesc.Name = "lblWraithUpgradeWyvernDesc";
            this.lblWraithUpgradeWyvernDesc.Size = new System.Drawing.Size(217, 28);
            this.lblWraithUpgradeWyvernDesc.TabIndex = 3;
            this.lblWraithUpgradeWyvernDesc.Text = "Wyverns. \"Wraiths with wings!\"";
            this.lblWraithUpgradeWyvernDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWraithUpgradeWyvernSPS
            // 
            this.lblWraithUpgradeWyvernSPS.Enabled = false;
            this.lblWraithUpgradeWyvernSPS.ForeColor = System.Drawing.Color.White;
            this.lblWraithUpgradeWyvernSPS.Location = new System.Drawing.Point(72, 21);
            this.lblWraithUpgradeWyvernSPS.Name = "lblWraithUpgradeWyvernSPS";
            this.lblWraithUpgradeWyvernSPS.Size = new System.Drawing.Size(217, 18);
            this.lblWraithUpgradeWyvernSPS.TabIndex = 2;
            this.lblWraithUpgradeWyvernSPS.Text = "Wraith Upgrade. 10x more efficient";
            this.lblWraithUpgradeWyvernSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWraithUpgradeWyvernCost
            // 
            this.lblWraithUpgradeWyvernCost.Enabled = false;
            this.lblWraithUpgradeWyvernCost.ForeColor = System.Drawing.Color.White;
            this.lblWraithUpgradeWyvernCost.Location = new System.Drawing.Point(72, 3);
            this.lblWraithUpgradeWyvernCost.Name = "lblWraithUpgradeWyvernCost";
            this.lblWraithUpgradeWyvernCost.Size = new System.Drawing.Size(217, 18);
            this.lblWraithUpgradeWyvernCost.TabIndex = 1;
            this.lblWraithUpgradeWyvernCost.Text = "65,000,000 Souls";
            this.lblWraithUpgradeWyvernCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxWraithUpgradeWyvern
            // 
            this.pbxWraithUpgradeWyvern.Enabled = false;
            this.pbxWraithUpgradeWyvern.Image = ((System.Drawing.Image)(resources.GetObject("pbxWraithUpgradeWyvern.Image")));
            this.pbxWraithUpgradeWyvern.Location = new System.Drawing.Point(3, 2);
            this.pbxWraithUpgradeWyvern.Name = "pbxWraithUpgradeWyvern";
            this.pbxWraithUpgradeWyvern.Size = new System.Drawing.Size(64, 64);
            this.pbxWraithUpgradeWyvern.TabIndex = 0;
            this.pbxWraithUpgradeWyvern.TabStop = false;
            // 
            // pnlWraithUpgradeInfernalWeaponry
            // 
            this.pnlWraithUpgradeInfernalWeaponry.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlWraithUpgradeInfernalWeaponry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWraithUpgradeInfernalWeaponry.Controls.Add(this.btnWraithUpgradeInfernalWeapons);
            this.pnlWraithUpgradeInfernalWeaponry.Controls.Add(this.lblWraithUpgradeInfernalWeaponryDesc);
            this.pnlWraithUpgradeInfernalWeaponry.Controls.Add(this.lblWraithUpgradeInfernalWeaponrySPS);
            this.pnlWraithUpgradeInfernalWeaponry.Controls.Add(this.lblWraithUpgradeInfernalWeaponryCost);
            this.pnlWraithUpgradeInfernalWeaponry.Controls.Add(this.pbxWraithUpgradeInfernalWeaponry);
            this.pnlWraithUpgradeInfernalWeaponry.Enabled = false;
            this.pnlWraithUpgradeInfernalWeaponry.Location = new System.Drawing.Point(3, 763);
            this.pnlWraithUpgradeInfernalWeaponry.Name = "pnlWraithUpgradeInfernalWeaponry";
            this.pnlWraithUpgradeInfernalWeaponry.Size = new System.Drawing.Size(290, 70);
            this.pnlWraithUpgradeInfernalWeaponry.TabIndex = 19;
            this.pnlWraithUpgradeInfernalWeaponry.Visible = false;
            // 
            // btnWraithUpgradeInfernalWeapons
            // 
            this.btnWraithUpgradeInfernalWeapons.BackColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeInfernalWeapons.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeInfernalWeapons.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeInfernalWeapons.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWraithUpgradeInfernalWeapons.ForeColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeInfernalWeapons.Location = new System.Drawing.Point(-1, -1);
            this.btnWraithUpgradeInfernalWeapons.Name = "btnWraithUpgradeInfernalWeapons";
            this.btnWraithUpgradeInfernalWeapons.Size = new System.Drawing.Size(290, 70);
            this.btnWraithUpgradeInfernalWeapons.TabIndex = 21;
            this.btnWraithUpgradeInfernalWeapons.UseVisualStyleBackColor = false;
            this.btnWraithUpgradeInfernalWeapons.Click += new System.EventHandler(this.btnWraithUpgradeInfernalWeapons_Click);
            // 
            // lblWraithUpgradeInfernalWeaponryDesc
            // 
            this.lblWraithUpgradeInfernalWeaponryDesc.Enabled = false;
            this.lblWraithUpgradeInfernalWeaponryDesc.ForeColor = System.Drawing.Color.White;
            this.lblWraithUpgradeInfernalWeaponryDesc.Location = new System.Drawing.Point(72, 39);
            this.lblWraithUpgradeInfernalWeaponryDesc.Name = "lblWraithUpgradeInfernalWeaponryDesc";
            this.lblWraithUpgradeInfernalWeaponryDesc.Size = new System.Drawing.Size(217, 28);
            this.lblWraithUpgradeInfernalWeaponryDesc.TabIndex = 3;
            this.lblWraithUpgradeInfernalWeaponryDesc.Text = "Infernal Weaponry. You\'ve got a little flame there.";
            this.lblWraithUpgradeInfernalWeaponryDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWraithUpgradeInfernalWeaponrySPS
            // 
            this.lblWraithUpgradeInfernalWeaponrySPS.Enabled = false;
            this.lblWraithUpgradeInfernalWeaponrySPS.ForeColor = System.Drawing.Color.White;
            this.lblWraithUpgradeInfernalWeaponrySPS.Location = new System.Drawing.Point(72, 21);
            this.lblWraithUpgradeInfernalWeaponrySPS.Name = "lblWraithUpgradeInfernalWeaponrySPS";
            this.lblWraithUpgradeInfernalWeaponrySPS.Size = new System.Drawing.Size(217, 18);
            this.lblWraithUpgradeInfernalWeaponrySPS.TabIndex = 2;
            this.lblWraithUpgradeInfernalWeaponrySPS.Text = "Wraith Upgrade. 4x more efficient";
            this.lblWraithUpgradeInfernalWeaponrySPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWraithUpgradeInfernalWeaponryCost
            // 
            this.lblWraithUpgradeInfernalWeaponryCost.Enabled = false;
            this.lblWraithUpgradeInfernalWeaponryCost.ForeColor = System.Drawing.Color.White;
            this.lblWraithUpgradeInfernalWeaponryCost.Location = new System.Drawing.Point(72, 3);
            this.lblWraithUpgradeInfernalWeaponryCost.Name = "lblWraithUpgradeInfernalWeaponryCost";
            this.lblWraithUpgradeInfernalWeaponryCost.Size = new System.Drawing.Size(217, 18);
            this.lblWraithUpgradeInfernalWeaponryCost.TabIndex = 1;
            this.lblWraithUpgradeInfernalWeaponryCost.Text = "6,500,000 Souls";
            this.lblWraithUpgradeInfernalWeaponryCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxWraithUpgradeInfernalWeaponry
            // 
            this.pbxWraithUpgradeInfernalWeaponry.Enabled = false;
            this.pbxWraithUpgradeInfernalWeaponry.Image = ((System.Drawing.Image)(resources.GetObject("pbxWraithUpgradeInfernalWeaponry.Image")));
            this.pbxWraithUpgradeInfernalWeaponry.Location = new System.Drawing.Point(3, 2);
            this.pbxWraithUpgradeInfernalWeaponry.Name = "pbxWraithUpgradeInfernalWeaponry";
            this.pbxWraithUpgradeInfernalWeaponry.Size = new System.Drawing.Size(64, 64);
            this.pbxWraithUpgradeInfernalWeaponry.TabIndex = 0;
            this.pbxWraithUpgradeInfernalWeaponry.TabStop = false;
            // 
            // pnlWraithUpgradeHorse
            // 
            this.pnlWraithUpgradeHorse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlWraithUpgradeHorse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWraithUpgradeHorse.Controls.Add(this.btnWraithUpgradeHorse);
            this.pnlWraithUpgradeHorse.Controls.Add(this.lblWraithUpgradeHorseDesc);
            this.pnlWraithUpgradeHorse.Controls.Add(this.lblWraithUpgradeHorseSPS);
            this.pnlWraithUpgradeHorse.Controls.Add(this.lblWraithUpgradeHorseCost);
            this.pnlWraithUpgradeHorse.Controls.Add(this.pbxWraithUpgradeHorse);
            this.pnlWraithUpgradeHorse.Enabled = false;
            this.pnlWraithUpgradeHorse.Location = new System.Drawing.Point(3, 839);
            this.pnlWraithUpgradeHorse.Name = "pnlWraithUpgradeHorse";
            this.pnlWraithUpgradeHorse.Size = new System.Drawing.Size(290, 70);
            this.pnlWraithUpgradeHorse.TabIndex = 18;
            this.pnlWraithUpgradeHorse.Visible = false;
            // 
            // btnWraithUpgradeHorse
            // 
            this.btnWraithUpgradeHorse.BackColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeHorse.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeHorse.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeHorse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWraithUpgradeHorse.ForeColor = System.Drawing.Color.Transparent;
            this.btnWraithUpgradeHorse.Location = new System.Drawing.Point(-1, -1);
            this.btnWraithUpgradeHorse.Name = "btnWraithUpgradeHorse";
            this.btnWraithUpgradeHorse.Size = new System.Drawing.Size(290, 70);
            this.btnWraithUpgradeHorse.TabIndex = 22;
            this.btnWraithUpgradeHorse.UseVisualStyleBackColor = false;
            this.btnWraithUpgradeHorse.Click += new System.EventHandler(this.btnWraithUpgradeHorse_Click);
            // 
            // lblWraithUpgradeHorseDesc
            // 
            this.lblWraithUpgradeHorseDesc.Enabled = false;
            this.lblWraithUpgradeHorseDesc.ForeColor = System.Drawing.Color.White;
            this.lblWraithUpgradeHorseDesc.Location = new System.Drawing.Point(72, 39);
            this.lblWraithUpgradeHorseDesc.Name = "lblWraithUpgradeHorseDesc";
            this.lblWraithUpgradeHorseDesc.Size = new System.Drawing.Size(217, 28);
            this.lblWraithUpgradeHorseDesc.TabIndex = 3;
            this.lblWraithUpgradeHorseDesc.Text = "Demon Horse. Good thing its not a Lemon horse.";
            this.lblWraithUpgradeHorseDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWraithUpgradeHorseSPS
            // 
            this.lblWraithUpgradeHorseSPS.Enabled = false;
            this.lblWraithUpgradeHorseSPS.ForeColor = System.Drawing.Color.White;
            this.lblWraithUpgradeHorseSPS.Location = new System.Drawing.Point(72, 21);
            this.lblWraithUpgradeHorseSPS.Name = "lblWraithUpgradeHorseSPS";
            this.lblWraithUpgradeHorseSPS.Size = new System.Drawing.Size(217, 18);
            this.lblWraithUpgradeHorseSPS.TabIndex = 2;
            this.lblWraithUpgradeHorseSPS.Text = "Wraith Upgrade. 2x more efficient";
            this.lblWraithUpgradeHorseSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWraithUpgradeHorseCost
            // 
            this.lblWraithUpgradeHorseCost.Enabled = false;
            this.lblWraithUpgradeHorseCost.ForeColor = System.Drawing.Color.White;
            this.lblWraithUpgradeHorseCost.Location = new System.Drawing.Point(72, 3);
            this.lblWraithUpgradeHorseCost.Name = "lblWraithUpgradeHorseCost";
            this.lblWraithUpgradeHorseCost.Size = new System.Drawing.Size(217, 18);
            this.lblWraithUpgradeHorseCost.TabIndex = 1;
            this.lblWraithUpgradeHorseCost.Text = "1,300,000 Souls";
            this.lblWraithUpgradeHorseCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxWraithUpgradeHorse
            // 
            this.pbxWraithUpgradeHorse.Enabled = false;
            this.pbxWraithUpgradeHorse.Image = ((System.Drawing.Image)(resources.GetObject("pbxWraithUpgradeHorse.Image")));
            this.pbxWraithUpgradeHorse.Location = new System.Drawing.Point(3, 2);
            this.pbxWraithUpgradeHorse.Name = "pbxWraithUpgradeHorse";
            this.pbxWraithUpgradeHorse.Size = new System.Drawing.Size(64, 64);
            this.pbxWraithUpgradeHorse.TabIndex = 0;
            this.pbxWraithUpgradeHorse.TabStop = false;
            // 
            // pnlVampireUpgradeEnchantedWeaponry
            // 
            this.pnlVampireUpgradeEnchantedWeaponry.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlVampireUpgradeEnchantedWeaponry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlVampireUpgradeEnchantedWeaponry.Controls.Add(this.btnVampireUpgradeEnchantedWeaponry);
            this.pnlVampireUpgradeEnchantedWeaponry.Controls.Add(this.lblVampireUpgradeEnchantedWeaponryDesc);
            this.pnlVampireUpgradeEnchantedWeaponry.Controls.Add(this.lblVampireUpgradeEnchantedWeaponrySPS);
            this.pnlVampireUpgradeEnchantedWeaponry.Controls.Add(this.lblVampireUpgradeEnchantedWeaponryCost);
            this.pnlVampireUpgradeEnchantedWeaponry.Controls.Add(this.pbxVampireUpgradeEnchantedWeaponry);
            this.pnlVampireUpgradeEnchantedWeaponry.Enabled = false;
            this.pnlVampireUpgradeEnchantedWeaponry.Location = new System.Drawing.Point(3, 915);
            this.pnlVampireUpgradeEnchantedWeaponry.Name = "pnlVampireUpgradeEnchantedWeaponry";
            this.pnlVampireUpgradeEnchantedWeaponry.Size = new System.Drawing.Size(290, 70);
            this.pnlVampireUpgradeEnchantedWeaponry.TabIndex = 17;
            this.pnlVampireUpgradeEnchantedWeaponry.Visible = false;
            // 
            // btnVampireUpgradeEnchantedWeaponry
            // 
            this.btnVampireUpgradeEnchantedWeaponry.BackColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeEnchantedWeaponry.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeEnchantedWeaponry.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeEnchantedWeaponry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVampireUpgradeEnchantedWeaponry.ForeColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeEnchantedWeaponry.Location = new System.Drawing.Point(-1, -1);
            this.btnVampireUpgradeEnchantedWeaponry.Name = "btnVampireUpgradeEnchantedWeaponry";
            this.btnVampireUpgradeEnchantedWeaponry.Size = new System.Drawing.Size(290, 70);
            this.btnVampireUpgradeEnchantedWeaponry.TabIndex = 20;
            this.btnVampireUpgradeEnchantedWeaponry.UseVisualStyleBackColor = false;
            this.btnVampireUpgradeEnchantedWeaponry.Click += new System.EventHandler(this.btnVampireUpgradeEnchantedWeaponry_Click);
            // 
            // lblVampireUpgradeEnchantedWeaponryDesc
            // 
            this.lblVampireUpgradeEnchantedWeaponryDesc.Enabled = false;
            this.lblVampireUpgradeEnchantedWeaponryDesc.ForeColor = System.Drawing.Color.White;
            this.lblVampireUpgradeEnchantedWeaponryDesc.Location = new System.Drawing.Point(72, 39);
            this.lblVampireUpgradeEnchantedWeaponryDesc.Name = "lblVampireUpgradeEnchantedWeaponryDesc";
            this.lblVampireUpgradeEnchantedWeaponryDesc.Size = new System.Drawing.Size(217, 28);
            this.lblVampireUpgradeEnchantedWeaponryDesc.TabIndex = 3;
            this.lblVampireUpgradeEnchantedWeaponryDesc.Text = "Enchanted Weaponry. Lets cook up a little magic for these guys.";
            this.lblVampireUpgradeEnchantedWeaponryDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVampireUpgradeEnchantedWeaponrySPS
            // 
            this.lblVampireUpgradeEnchantedWeaponrySPS.Enabled = false;
            this.lblVampireUpgradeEnchantedWeaponrySPS.ForeColor = System.Drawing.Color.White;
            this.lblVampireUpgradeEnchantedWeaponrySPS.Location = new System.Drawing.Point(72, 21);
            this.lblVampireUpgradeEnchantedWeaponrySPS.Name = "lblVampireUpgradeEnchantedWeaponrySPS";
            this.lblVampireUpgradeEnchantedWeaponrySPS.Size = new System.Drawing.Size(217, 18);
            this.lblVampireUpgradeEnchantedWeaponrySPS.TabIndex = 2;
            this.lblVampireUpgradeEnchantedWeaponrySPS.Text = "Vampire upgrade. 10x more efficient";
            this.lblVampireUpgradeEnchantedWeaponrySPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVampireUpgradeEnchantedWeaponryCost
            // 
            this.lblVampireUpgradeEnchantedWeaponryCost.Enabled = false;
            this.lblVampireUpgradeEnchantedWeaponryCost.ForeColor = System.Drawing.Color.White;
            this.lblVampireUpgradeEnchantedWeaponryCost.Location = new System.Drawing.Point(72, 3);
            this.lblVampireUpgradeEnchantedWeaponryCost.Name = "lblVampireUpgradeEnchantedWeaponryCost";
            this.lblVampireUpgradeEnchantedWeaponryCost.Size = new System.Drawing.Size(217, 18);
            this.lblVampireUpgradeEnchantedWeaponryCost.TabIndex = 1;
            this.lblVampireUpgradeEnchantedWeaponryCost.Text = "6,000,000 Souls";
            this.lblVampireUpgradeEnchantedWeaponryCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxVampireUpgradeEnchantedWeaponry
            // 
            this.pbxVampireUpgradeEnchantedWeaponry.Enabled = false;
            this.pbxVampireUpgradeEnchantedWeaponry.Image = ((System.Drawing.Image)(resources.GetObject("pbxVampireUpgradeEnchantedWeaponry.Image")));
            this.pbxVampireUpgradeEnchantedWeaponry.Location = new System.Drawing.Point(3, 2);
            this.pbxVampireUpgradeEnchantedWeaponry.Name = "pbxVampireUpgradeEnchantedWeaponry";
            this.pbxVampireUpgradeEnchantedWeaponry.Size = new System.Drawing.Size(64, 64);
            this.pbxVampireUpgradeEnchantedWeaponry.TabIndex = 0;
            this.pbxVampireUpgradeEnchantedWeaponry.TabStop = false;
            // 
            // pnlVampireUpgradeBatForm
            // 
            this.pnlVampireUpgradeBatForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlVampireUpgradeBatForm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlVampireUpgradeBatForm.Controls.Add(this.btnVampireUpgradeBatForm);
            this.pnlVampireUpgradeBatForm.Controls.Add(this.lblVampireUpgradeBatFormDesc);
            this.pnlVampireUpgradeBatForm.Controls.Add(this.lblVampireUpgradeBatFormSPS);
            this.pnlVampireUpgradeBatForm.Controls.Add(this.lblVampireUpgradeBatFormCost);
            this.pnlVampireUpgradeBatForm.Controls.Add(this.pbxVampireUpgradeBatForm);
            this.pnlVampireUpgradeBatForm.Enabled = false;
            this.pnlVampireUpgradeBatForm.Location = new System.Drawing.Point(3, 991);
            this.pnlVampireUpgradeBatForm.Name = "pnlVampireUpgradeBatForm";
            this.pnlVampireUpgradeBatForm.Size = new System.Drawing.Size(290, 70);
            this.pnlVampireUpgradeBatForm.TabIndex = 16;
            this.pnlVampireUpgradeBatForm.Visible = false;
            // 
            // btnVampireUpgradeBatForm
            // 
            this.btnVampireUpgradeBatForm.BackColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeBatForm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeBatForm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeBatForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVampireUpgradeBatForm.ForeColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeBatForm.Location = new System.Drawing.Point(-1, -1);
            this.btnVampireUpgradeBatForm.Name = "btnVampireUpgradeBatForm";
            this.btnVampireUpgradeBatForm.Size = new System.Drawing.Size(290, 70);
            this.btnVampireUpgradeBatForm.TabIndex = 19;
            this.btnVampireUpgradeBatForm.UseVisualStyleBackColor = false;
            this.btnVampireUpgradeBatForm.Click += new System.EventHandler(this.btnVampireUpgradeBatForm_Click);
            // 
            // lblVampireUpgradeBatFormDesc
            // 
            this.lblVampireUpgradeBatFormDesc.Enabled = false;
            this.lblVampireUpgradeBatFormDesc.ForeColor = System.Drawing.Color.White;
            this.lblVampireUpgradeBatFormDesc.Location = new System.Drawing.Point(72, 39);
            this.lblVampireUpgradeBatFormDesc.Name = "lblVampireUpgradeBatFormDesc";
            this.lblVampireUpgradeBatFormDesc.Size = new System.Drawing.Size(217, 28);
            this.lblVampireUpgradeBatFormDesc.TabIndex = 3;
            this.lblVampireUpgradeBatFormDesc.Text = "Bat Form. Vambire bats? Yes? No?";
            this.lblVampireUpgradeBatFormDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVampireUpgradeBatFormSPS
            // 
            this.lblVampireUpgradeBatFormSPS.Enabled = false;
            this.lblVampireUpgradeBatFormSPS.ForeColor = System.Drawing.Color.White;
            this.lblVampireUpgradeBatFormSPS.Location = new System.Drawing.Point(72, 21);
            this.lblVampireUpgradeBatFormSPS.Name = "lblVampireUpgradeBatFormSPS";
            this.lblVampireUpgradeBatFormSPS.Size = new System.Drawing.Size(217, 18);
            this.lblVampireUpgradeBatFormSPS.TabIndex = 2;
            this.lblVampireUpgradeBatFormSPS.Text = "Vampire upgrade. 4x more efficient";
            this.lblVampireUpgradeBatFormSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVampireUpgradeBatFormCost
            // 
            this.lblVampireUpgradeBatFormCost.Enabled = false;
            this.lblVampireUpgradeBatFormCost.ForeColor = System.Drawing.Color.White;
            this.lblVampireUpgradeBatFormCost.Location = new System.Drawing.Point(72, 3);
            this.lblVampireUpgradeBatFormCost.Name = "lblVampireUpgradeBatFormCost";
            this.lblVampireUpgradeBatFormCost.Size = new System.Drawing.Size(217, 18);
            this.lblVampireUpgradeBatFormCost.TabIndex = 1;
            this.lblVampireUpgradeBatFormCost.Text = "600,000 Souls";
            this.lblVampireUpgradeBatFormCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxVampireUpgradeBatForm
            // 
            this.pbxVampireUpgradeBatForm.Enabled = false;
            this.pbxVampireUpgradeBatForm.Image = ((System.Drawing.Image)(resources.GetObject("pbxVampireUpgradeBatForm.Image")));
            this.pbxVampireUpgradeBatForm.Location = new System.Drawing.Point(3, 2);
            this.pbxVampireUpgradeBatForm.Name = "pbxVampireUpgradeBatForm";
            this.pbxVampireUpgradeBatForm.Size = new System.Drawing.Size(64, 64);
            this.pbxVampireUpgradeBatForm.TabIndex = 0;
            this.pbxVampireUpgradeBatForm.TabStop = false;
            // 
            // pnlVampireUpgradeHealing
            // 
            this.pnlVampireUpgradeHealing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlVampireUpgradeHealing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlVampireUpgradeHealing.Controls.Add(this.btnVampireUpgradeHealing);
            this.pnlVampireUpgradeHealing.Controls.Add(this.lblVampireUpgradeHealingDesc);
            this.pnlVampireUpgradeHealing.Controls.Add(this.lblVampireUpgradeHealingSPS);
            this.pnlVampireUpgradeHealing.Controls.Add(this.lblVampireUpgradeHealingCost);
            this.pnlVampireUpgradeHealing.Controls.Add(this.pbxVampireUpgradeHealing);
            this.pnlVampireUpgradeHealing.Enabled = false;
            this.pnlVampireUpgradeHealing.Location = new System.Drawing.Point(3, 1067);
            this.pnlVampireUpgradeHealing.Name = "pnlVampireUpgradeHealing";
            this.pnlVampireUpgradeHealing.Size = new System.Drawing.Size(290, 70);
            this.pnlVampireUpgradeHealing.TabIndex = 15;
            this.pnlVampireUpgradeHealing.Visible = false;
            // 
            // btnVampireUpgradeHealing
            // 
            this.btnVampireUpgradeHealing.BackColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeHealing.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeHealing.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeHealing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVampireUpgradeHealing.ForeColor = System.Drawing.Color.Transparent;
            this.btnVampireUpgradeHealing.Location = new System.Drawing.Point(-1, -1);
            this.btnVampireUpgradeHealing.Name = "btnVampireUpgradeHealing";
            this.btnVampireUpgradeHealing.Size = new System.Drawing.Size(290, 70);
            this.btnVampireUpgradeHealing.TabIndex = 18;
            this.btnVampireUpgradeHealing.UseVisualStyleBackColor = false;
            this.btnVampireUpgradeHealing.Click += new System.EventHandler(this.btnVampireUpgradeHealing_Click);
            // 
            // lblVampireUpgradeHealingDesc
            // 
            this.lblVampireUpgradeHealingDesc.Enabled = false;
            this.lblVampireUpgradeHealingDesc.ForeColor = System.Drawing.Color.White;
            this.lblVampireUpgradeHealingDesc.Location = new System.Drawing.Point(72, 39);
            this.lblVampireUpgradeHealingDesc.Name = "lblVampireUpgradeHealingDesc";
            this.lblVampireUpgradeHealingDesc.Size = new System.Drawing.Size(217, 28);
            this.lblVampireUpgradeHealingDesc.TabIndex = 3;
            this.lblVampireUpgradeHealingDesc.Text = "Quick Healing. No more slow healing related casualties.";
            this.lblVampireUpgradeHealingDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVampireUpgradeHealingSPS
            // 
            this.lblVampireUpgradeHealingSPS.Enabled = false;
            this.lblVampireUpgradeHealingSPS.ForeColor = System.Drawing.Color.White;
            this.lblVampireUpgradeHealingSPS.Location = new System.Drawing.Point(72, 21);
            this.lblVampireUpgradeHealingSPS.Name = "lblVampireUpgradeHealingSPS";
            this.lblVampireUpgradeHealingSPS.Size = new System.Drawing.Size(217, 18);
            this.lblVampireUpgradeHealingSPS.TabIndex = 2;
            this.lblVampireUpgradeHealingSPS.Text = "Vampire upgrade. 2x more efficient";
            this.lblVampireUpgradeHealingSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVampireUpgradeHealingCost
            // 
            this.lblVampireUpgradeHealingCost.Enabled = false;
            this.lblVampireUpgradeHealingCost.ForeColor = System.Drawing.Color.White;
            this.lblVampireUpgradeHealingCost.Location = new System.Drawing.Point(72, 3);
            this.lblVampireUpgradeHealingCost.Name = "lblVampireUpgradeHealingCost";
            this.lblVampireUpgradeHealingCost.Size = new System.Drawing.Size(217, 18);
            this.lblVampireUpgradeHealingCost.TabIndex = 1;
            this.lblVampireUpgradeHealingCost.Text = "120,000 Souls";
            this.lblVampireUpgradeHealingCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxVampireUpgradeHealing
            // 
            this.pbxVampireUpgradeHealing.Enabled = false;
            this.pbxVampireUpgradeHealing.Image = ((System.Drawing.Image)(resources.GetObject("pbxVampireUpgradeHealing.Image")));
            this.pbxVampireUpgradeHealing.Location = new System.Drawing.Point(3, 2);
            this.pbxVampireUpgradeHealing.Name = "pbxVampireUpgradeHealing";
            this.pbxVampireUpgradeHealing.Size = new System.Drawing.Size(64, 64);
            this.pbxVampireUpgradeHealing.TabIndex = 0;
            this.pbxVampireUpgradeHealing.TabStop = false;
            // 
            // pnlSkeletonUpgradeDarksteel
            // 
            this.pnlSkeletonUpgradeDarksteel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlSkeletonUpgradeDarksteel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSkeletonUpgradeDarksteel.Controls.Add(this.btnSkeletonUpgradeDarksteel);
            this.pnlSkeletonUpgradeDarksteel.Controls.Add(this.lblSkeletonUpgradeDarksteelDesc);
            this.pnlSkeletonUpgradeDarksteel.Controls.Add(this.lblSkeletonUpgradeDarksteelSPS);
            this.pnlSkeletonUpgradeDarksteel.Controls.Add(this.lblSkeletonUpgradeDarksteelCost);
            this.pnlSkeletonUpgradeDarksteel.Controls.Add(this.pbxSkeletonUpgradeDarksteel);
            this.pnlSkeletonUpgradeDarksteel.Enabled = false;
            this.pnlSkeletonUpgradeDarksteel.Location = new System.Drawing.Point(3, 1143);
            this.pnlSkeletonUpgradeDarksteel.Name = "pnlSkeletonUpgradeDarksteel";
            this.pnlSkeletonUpgradeDarksteel.Size = new System.Drawing.Size(290, 70);
            this.pnlSkeletonUpgradeDarksteel.TabIndex = 14;
            this.pnlSkeletonUpgradeDarksteel.Visible = false;
            // 
            // btnSkeletonUpgradeDarksteel
            // 
            this.btnSkeletonUpgradeDarksteel.BackColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeDarksteel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeDarksteel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeDarksteel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSkeletonUpgradeDarksteel.ForeColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeDarksteel.Location = new System.Drawing.Point(-1, -1);
            this.btnSkeletonUpgradeDarksteel.Name = "btnSkeletonUpgradeDarksteel";
            this.btnSkeletonUpgradeDarksteel.Size = new System.Drawing.Size(290, 70);
            this.btnSkeletonUpgradeDarksteel.TabIndex = 17;
            this.btnSkeletonUpgradeDarksteel.UseVisualStyleBackColor = false;
            this.btnSkeletonUpgradeDarksteel.Click += new System.EventHandler(this.btnSkeletonUpgradeDarksteel_Click);
            // 
            // lblSkeletonUpgradeDarksteelDesc
            // 
            this.lblSkeletonUpgradeDarksteelDesc.Enabled = false;
            this.lblSkeletonUpgradeDarksteelDesc.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonUpgradeDarksteelDesc.Location = new System.Drawing.Point(72, 39);
            this.lblSkeletonUpgradeDarksteelDesc.Name = "lblSkeletonUpgradeDarksteelDesc";
            this.lblSkeletonUpgradeDarksteelDesc.Size = new System.Drawing.Size(217, 28);
            this.lblSkeletonUpgradeDarksteelDesc.TabIndex = 3;
            this.lblSkeletonUpgradeDarksteelDesc.Text = "Darksteel Weaponry. Darker than normal steel.";
            this.lblSkeletonUpgradeDarksteelDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSkeletonUpgradeDarksteelSPS
            // 
            this.lblSkeletonUpgradeDarksteelSPS.Enabled = false;
            this.lblSkeletonUpgradeDarksteelSPS.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonUpgradeDarksteelSPS.Location = new System.Drawing.Point(72, 21);
            this.lblSkeletonUpgradeDarksteelSPS.Name = "lblSkeletonUpgradeDarksteelSPS";
            this.lblSkeletonUpgradeDarksteelSPS.Size = new System.Drawing.Size(217, 18);
            this.lblSkeletonUpgradeDarksteelSPS.TabIndex = 2;
            this.lblSkeletonUpgradeDarksteelSPS.Text = "Skeleton Upgrade. 10x more efficient";
            this.lblSkeletonUpgradeDarksteelSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSkeletonUpgradeDarksteelCost
            // 
            this.lblSkeletonUpgradeDarksteelCost.Enabled = false;
            this.lblSkeletonUpgradeDarksteelCost.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonUpgradeDarksteelCost.Location = new System.Drawing.Point(72, 3);
            this.lblSkeletonUpgradeDarksteelCost.Name = "lblSkeletonUpgradeDarksteelCost";
            this.lblSkeletonUpgradeDarksteelCost.Size = new System.Drawing.Size(217, 18);
            this.lblSkeletonUpgradeDarksteelCost.TabIndex = 1;
            this.lblSkeletonUpgradeDarksteelCost.Text = "500,000 Souls";
            this.lblSkeletonUpgradeDarksteelCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxSkeletonUpgradeDarksteel
            // 
            this.pbxSkeletonUpgradeDarksteel.Enabled = false;
            this.pbxSkeletonUpgradeDarksteel.Image = ((System.Drawing.Image)(resources.GetObject("pbxSkeletonUpgradeDarksteel.Image")));
            this.pbxSkeletonUpgradeDarksteel.Location = new System.Drawing.Point(3, 2);
            this.pbxSkeletonUpgradeDarksteel.Name = "pbxSkeletonUpgradeDarksteel";
            this.pbxSkeletonUpgradeDarksteel.Size = new System.Drawing.Size(64, 64);
            this.pbxSkeletonUpgradeDarksteel.TabIndex = 0;
            this.pbxSkeletonUpgradeDarksteel.TabStop = false;
            // 
            // pnlSkeletonUpgradeArmor
            // 
            this.pnlSkeletonUpgradeArmor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlSkeletonUpgradeArmor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSkeletonUpgradeArmor.Controls.Add(this.btnSkeletonUpgradeArmor);
            this.pnlSkeletonUpgradeArmor.Controls.Add(this.lblSkeletonUpgradeArmorDesc);
            this.pnlSkeletonUpgradeArmor.Controls.Add(this.lblSkeletonUpgradeArmorSPS);
            this.pnlSkeletonUpgradeArmor.Controls.Add(this.lblSkeletonUpgradeArmorCost);
            this.pnlSkeletonUpgradeArmor.Controls.Add(this.pbxSkeletonUpgradeArmor);
            this.pnlSkeletonUpgradeArmor.Enabled = false;
            this.pnlSkeletonUpgradeArmor.Location = new System.Drawing.Point(3, 1219);
            this.pnlSkeletonUpgradeArmor.Name = "pnlSkeletonUpgradeArmor";
            this.pnlSkeletonUpgradeArmor.Size = new System.Drawing.Size(290, 70);
            this.pnlSkeletonUpgradeArmor.TabIndex = 13;
            this.pnlSkeletonUpgradeArmor.Visible = false;
            // 
            // btnSkeletonUpgradeArmor
            // 
            this.btnSkeletonUpgradeArmor.BackColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeArmor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeArmor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeArmor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSkeletonUpgradeArmor.ForeColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeArmor.Location = new System.Drawing.Point(-1, -1);
            this.btnSkeletonUpgradeArmor.Name = "btnSkeletonUpgradeArmor";
            this.btnSkeletonUpgradeArmor.Size = new System.Drawing.Size(290, 70);
            this.btnSkeletonUpgradeArmor.TabIndex = 16;
            this.btnSkeletonUpgradeArmor.UseVisualStyleBackColor = false;
            this.btnSkeletonUpgradeArmor.Click += new System.EventHandler(this.btnSkeletonUpgradeArmor_Click);
            // 
            // lblSkeletonUpgradeArmorDesc
            // 
            this.lblSkeletonUpgradeArmorDesc.Enabled = false;
            this.lblSkeletonUpgradeArmorDesc.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonUpgradeArmorDesc.Location = new System.Drawing.Point(72, 39);
            this.lblSkeletonUpgradeArmorDesc.Name = "lblSkeletonUpgradeArmorDesc";
            this.lblSkeletonUpgradeArmorDesc.Size = new System.Drawing.Size(217, 28);
            this.lblSkeletonUpgradeArmorDesc.TabIndex = 3;
            this.lblSkeletonUpgradeArmorDesc.Text = "Iron Armor. You wouldn\'t think skeletons would need armor, but oh well.";
            this.lblSkeletonUpgradeArmorDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSkeletonUpgradeArmorSPS
            // 
            this.lblSkeletonUpgradeArmorSPS.Enabled = false;
            this.lblSkeletonUpgradeArmorSPS.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonUpgradeArmorSPS.Location = new System.Drawing.Point(72, 21);
            this.lblSkeletonUpgradeArmorSPS.Name = "lblSkeletonUpgradeArmorSPS";
            this.lblSkeletonUpgradeArmorSPS.Size = new System.Drawing.Size(217, 18);
            this.lblSkeletonUpgradeArmorSPS.TabIndex = 2;
            this.lblSkeletonUpgradeArmorSPS.Text = "Skeleton Upgrade. 4x more efficient";
            this.lblSkeletonUpgradeArmorSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSkeletonUpgradeArmorCost
            // 
            this.lblSkeletonUpgradeArmorCost.Enabled = false;
            this.lblSkeletonUpgradeArmorCost.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonUpgradeArmorCost.Location = new System.Drawing.Point(72, 3);
            this.lblSkeletonUpgradeArmorCost.Name = "lblSkeletonUpgradeArmorCost";
            this.lblSkeletonUpgradeArmorCost.Size = new System.Drawing.Size(217, 18);
            this.lblSkeletonUpgradeArmorCost.TabIndex = 1;
            this.lblSkeletonUpgradeArmorCost.Text = "50,000 Souls";
            this.lblSkeletonUpgradeArmorCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxSkeletonUpgradeArmor
            // 
            this.pbxSkeletonUpgradeArmor.Enabled = false;
            this.pbxSkeletonUpgradeArmor.Image = ((System.Drawing.Image)(resources.GetObject("pbxSkeletonUpgradeArmor.Image")));
            this.pbxSkeletonUpgradeArmor.Location = new System.Drawing.Point(3, 2);
            this.pbxSkeletonUpgradeArmor.Name = "pbxSkeletonUpgradeArmor";
            this.pbxSkeletonUpgradeArmor.Size = new System.Drawing.Size(64, 64);
            this.pbxSkeletonUpgradeArmor.TabIndex = 0;
            this.pbxSkeletonUpgradeArmor.TabStop = false;
            // 
            // pnlSkeletonUpgradeWeapons
            // 
            this.pnlSkeletonUpgradeWeapons.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlSkeletonUpgradeWeapons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSkeletonUpgradeWeapons.Controls.Add(this.btnSkeletonUpgradeWeapons);
            this.pnlSkeletonUpgradeWeapons.Controls.Add(this.lblSkeletonUpgradeWeaponsDesc);
            this.pnlSkeletonUpgradeWeapons.Controls.Add(this.lblSkeletonUpgradeWeaponsSPS);
            this.pnlSkeletonUpgradeWeapons.Controls.Add(this.lblSkeletonUpgradeWeaponsCost);
            this.pnlSkeletonUpgradeWeapons.Controls.Add(this.pbxSkeletonUpgradeWeapons);
            this.pnlSkeletonUpgradeWeapons.Enabled = false;
            this.pnlSkeletonUpgradeWeapons.Location = new System.Drawing.Point(3, 1295);
            this.pnlSkeletonUpgradeWeapons.Name = "pnlSkeletonUpgradeWeapons";
            this.pnlSkeletonUpgradeWeapons.Size = new System.Drawing.Size(290, 70);
            this.pnlSkeletonUpgradeWeapons.TabIndex = 12;
            this.pnlSkeletonUpgradeWeapons.Visible = false;
            // 
            // btnSkeletonUpgradeWeapons
            // 
            this.btnSkeletonUpgradeWeapons.BackColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeWeapons.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeWeapons.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeWeapons.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSkeletonUpgradeWeapons.ForeColor = System.Drawing.Color.Transparent;
            this.btnSkeletonUpgradeWeapons.Location = new System.Drawing.Point(-1, -1);
            this.btnSkeletonUpgradeWeapons.Name = "btnSkeletonUpgradeWeapons";
            this.btnSkeletonUpgradeWeapons.Size = new System.Drawing.Size(290, 70);
            this.btnSkeletonUpgradeWeapons.TabIndex = 15;
            this.btnSkeletonUpgradeWeapons.UseVisualStyleBackColor = false;
            this.btnSkeletonUpgradeWeapons.Click += new System.EventHandler(this.btnSkeletonUpgradeWeapons_Click);
            // 
            // lblSkeletonUpgradeWeaponsDesc
            // 
            this.lblSkeletonUpgradeWeaponsDesc.Enabled = false;
            this.lblSkeletonUpgradeWeaponsDesc.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonUpgradeWeaponsDesc.Location = new System.Drawing.Point(72, 39);
            this.lblSkeletonUpgradeWeaponsDesc.Name = "lblSkeletonUpgradeWeaponsDesc";
            this.lblSkeletonUpgradeWeaponsDesc.Size = new System.Drawing.Size(217, 28);
            this.lblSkeletonUpgradeWeaponsDesc.TabIndex = 3;
            this.lblSkeletonUpgradeWeaponsDesc.Text = "Iron Weaponry. A little rusty, but who wouldn\'t be after being dead for so long.";
            this.lblSkeletonUpgradeWeaponsDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSkeletonUpgradeWeaponsSPS
            // 
            this.lblSkeletonUpgradeWeaponsSPS.Enabled = false;
            this.lblSkeletonUpgradeWeaponsSPS.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonUpgradeWeaponsSPS.Location = new System.Drawing.Point(72, 21);
            this.lblSkeletonUpgradeWeaponsSPS.Name = "lblSkeletonUpgradeWeaponsSPS";
            this.lblSkeletonUpgradeWeaponsSPS.Size = new System.Drawing.Size(217, 18);
            this.lblSkeletonUpgradeWeaponsSPS.TabIndex = 2;
            this.lblSkeletonUpgradeWeaponsSPS.Text = "Skeleton Upgrade. 2x more efficient";
            this.lblSkeletonUpgradeWeaponsSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSkeletonUpgradeWeaponsCost
            // 
            this.lblSkeletonUpgradeWeaponsCost.Enabled = false;
            this.lblSkeletonUpgradeWeaponsCost.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonUpgradeWeaponsCost.Location = new System.Drawing.Point(72, 3);
            this.lblSkeletonUpgradeWeaponsCost.Name = "lblSkeletonUpgradeWeaponsCost";
            this.lblSkeletonUpgradeWeaponsCost.Size = new System.Drawing.Size(217, 18);
            this.lblSkeletonUpgradeWeaponsCost.TabIndex = 1;
            this.lblSkeletonUpgradeWeaponsCost.Text = "10,000 Souls";
            this.lblSkeletonUpgradeWeaponsCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxSkeletonUpgradeWeapons
            // 
            this.pbxSkeletonUpgradeWeapons.Enabled = false;
            this.pbxSkeletonUpgradeWeapons.Image = ((System.Drawing.Image)(resources.GetObject("pbxSkeletonUpgradeWeapons.Image")));
            this.pbxSkeletonUpgradeWeapons.Location = new System.Drawing.Point(3, 2);
            this.pbxSkeletonUpgradeWeapons.Name = "pbxSkeletonUpgradeWeapons";
            this.pbxSkeletonUpgradeWeapons.Size = new System.Drawing.Size(64, 64);
            this.pbxSkeletonUpgradeWeapons.TabIndex = 0;
            this.pbxSkeletonUpgradeWeapons.TabStop = false;
            // 
            // pnlGhoulUpgradeArmor
            // 
            this.pnlGhoulUpgradeArmor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlGhoulUpgradeArmor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlGhoulUpgradeArmor.Controls.Add(this.btnGhoulUpgradeArmor);
            this.pnlGhoulUpgradeArmor.Controls.Add(this.lblGhoulUpgradeArmorDesc);
            this.pnlGhoulUpgradeArmor.Controls.Add(this.lblGhoulUpgradeArmorSPS);
            this.pnlGhoulUpgradeArmor.Controls.Add(this.lblGhoulUpgradeArmorCost);
            this.pnlGhoulUpgradeArmor.Controls.Add(this.pbxGhoulUpgradeArmor);
            this.pnlGhoulUpgradeArmor.Enabled = false;
            this.pnlGhoulUpgradeArmor.Location = new System.Drawing.Point(3, 1371);
            this.pnlGhoulUpgradeArmor.Name = "pnlGhoulUpgradeArmor";
            this.pnlGhoulUpgradeArmor.Size = new System.Drawing.Size(290, 70);
            this.pnlGhoulUpgradeArmor.TabIndex = 11;
            this.pnlGhoulUpgradeArmor.Visible = false;
            // 
            // btnGhoulUpgradeArmor
            // 
            this.btnGhoulUpgradeArmor.BackColor = System.Drawing.Color.Transparent;
            this.btnGhoulUpgradeArmor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGhoulUpgradeArmor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGhoulUpgradeArmor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGhoulUpgradeArmor.ForeColor = System.Drawing.Color.Transparent;
            this.btnGhoulUpgradeArmor.Location = new System.Drawing.Point(-1, -1);
            this.btnGhoulUpgradeArmor.Name = "btnGhoulUpgradeArmor";
            this.btnGhoulUpgradeArmor.Size = new System.Drawing.Size(290, 70);
            this.btnGhoulUpgradeArmor.TabIndex = 14;
            this.btnGhoulUpgradeArmor.UseVisualStyleBackColor = false;
            this.btnGhoulUpgradeArmor.Click += new System.EventHandler(this.btnGhoulUpgradeArmor_Click);
            // 
            // lblGhoulUpgradeArmorDesc
            // 
            this.lblGhoulUpgradeArmorDesc.Enabled = false;
            this.lblGhoulUpgradeArmorDesc.ForeColor = System.Drawing.Color.White;
            this.lblGhoulUpgradeArmorDesc.Location = new System.Drawing.Point(72, 39);
            this.lblGhoulUpgradeArmorDesc.Name = "lblGhoulUpgradeArmorDesc";
            this.lblGhoulUpgradeArmorDesc.Size = new System.Drawing.Size(217, 28);
            this.lblGhoulUpgradeArmorDesc.TabIndex = 3;
            this.lblGhoulUpgradeArmorDesc.Text = "Leather Armor.  No more ghoul giblets.";
            this.lblGhoulUpgradeArmorDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGhoulUpgradeArmorSPS
            // 
            this.lblGhoulUpgradeArmorSPS.Enabled = false;
            this.lblGhoulUpgradeArmorSPS.ForeColor = System.Drawing.Color.White;
            this.lblGhoulUpgradeArmorSPS.Location = new System.Drawing.Point(72, 21);
            this.lblGhoulUpgradeArmorSPS.Name = "lblGhoulUpgradeArmorSPS";
            this.lblGhoulUpgradeArmorSPS.Size = new System.Drawing.Size(217, 18);
            this.lblGhoulUpgradeArmorSPS.TabIndex = 2;
            this.lblGhoulUpgradeArmorSPS.Text = "Ghoul Upgrade. 10x more efficient";
            this.lblGhoulUpgradeArmorSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGhoulUpgradeArmorCost
            // 
            this.lblGhoulUpgradeArmorCost.Enabled = false;
            this.lblGhoulUpgradeArmorCost.ForeColor = System.Drawing.Color.White;
            this.lblGhoulUpgradeArmorCost.Location = new System.Drawing.Point(72, 3);
            this.lblGhoulUpgradeArmorCost.Name = "lblGhoulUpgradeArmorCost";
            this.lblGhoulUpgradeArmorCost.Size = new System.Drawing.Size(217, 18);
            this.lblGhoulUpgradeArmorCost.TabIndex = 1;
            this.lblGhoulUpgradeArmorCost.Text = "50,000 Souls";
            this.lblGhoulUpgradeArmorCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxGhoulUpgradeArmor
            // 
            this.pbxGhoulUpgradeArmor.Enabled = false;
            this.pbxGhoulUpgradeArmor.Image = ((System.Drawing.Image)(resources.GetObject("pbxGhoulUpgradeArmor.Image")));
            this.pbxGhoulUpgradeArmor.Location = new System.Drawing.Point(3, 2);
            this.pbxGhoulUpgradeArmor.Name = "pbxGhoulUpgradeArmor";
            this.pbxGhoulUpgradeArmor.Size = new System.Drawing.Size(64, 64);
            this.pbxGhoulUpgradeArmor.TabIndex = 0;
            this.pbxGhoulUpgradeArmor.TabStop = false;
            // 
            // pnlGhoulUpgradeParalysis
            // 
            this.pnlGhoulUpgradeParalysis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlGhoulUpgradeParalysis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlGhoulUpgradeParalysis.Controls.Add(this.btnGhoulUpgradeParalysis);
            this.pnlGhoulUpgradeParalysis.Controls.Add(this.lblGhoulUpgradeParalysisDesc);
            this.pnlGhoulUpgradeParalysis.Controls.Add(this.lblGhoulUpgradeParalysisSPS);
            this.pnlGhoulUpgradeParalysis.Controls.Add(this.lblGhoulUpgradeParalysisCost);
            this.pnlGhoulUpgradeParalysis.Controls.Add(this.pbxGhoulUpgradeParalysis);
            this.pnlGhoulUpgradeParalysis.Enabled = false;
            this.pnlGhoulUpgradeParalysis.Location = new System.Drawing.Point(3, 1447);
            this.pnlGhoulUpgradeParalysis.Name = "pnlGhoulUpgradeParalysis";
            this.pnlGhoulUpgradeParalysis.Size = new System.Drawing.Size(290, 70);
            this.pnlGhoulUpgradeParalysis.TabIndex = 10;
            this.pnlGhoulUpgradeParalysis.Visible = false;
            // 
            // btnGhoulUpgradeParalysis
            // 
            this.btnGhoulUpgradeParalysis.BackColor = System.Drawing.Color.Transparent;
            this.btnGhoulUpgradeParalysis.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGhoulUpgradeParalysis.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGhoulUpgradeParalysis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGhoulUpgradeParalysis.ForeColor = System.Drawing.Color.Transparent;
            this.btnGhoulUpgradeParalysis.Location = new System.Drawing.Point(-1, -1);
            this.btnGhoulUpgradeParalysis.Name = "btnGhoulUpgradeParalysis";
            this.btnGhoulUpgradeParalysis.Size = new System.Drawing.Size(290, 70);
            this.btnGhoulUpgradeParalysis.TabIndex = 13;
            this.btnGhoulUpgradeParalysis.UseVisualStyleBackColor = false;
            this.btnGhoulUpgradeParalysis.Click += new System.EventHandler(this.btnGhoulUpgradeParalysis_Click);
            // 
            // lblGhoulUpgradeParalysisDesc
            // 
            this.lblGhoulUpgradeParalysisDesc.Enabled = false;
            this.lblGhoulUpgradeParalysisDesc.ForeColor = System.Drawing.Color.White;
            this.lblGhoulUpgradeParalysisDesc.Location = new System.Drawing.Point(72, 39);
            this.lblGhoulUpgradeParalysisDesc.Name = "lblGhoulUpgradeParalysisDesc";
            this.lblGhoulUpgradeParalysisDesc.Size = new System.Drawing.Size(217, 28);
            this.lblGhoulUpgradeParalysisDesc.TabIndex = 3;
            this.lblGhoulUpgradeParalysisDesc.Text = "Paralysis Touch. Like Midas\' touch, but less cool.";
            this.lblGhoulUpgradeParalysisDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGhoulUpgradeParalysisSPS
            // 
            this.lblGhoulUpgradeParalysisSPS.Enabled = false;
            this.lblGhoulUpgradeParalysisSPS.ForeColor = System.Drawing.Color.White;
            this.lblGhoulUpgradeParalysisSPS.Location = new System.Drawing.Point(72, 21);
            this.lblGhoulUpgradeParalysisSPS.Name = "lblGhoulUpgradeParalysisSPS";
            this.lblGhoulUpgradeParalysisSPS.Size = new System.Drawing.Size(217, 18);
            this.lblGhoulUpgradeParalysisSPS.TabIndex = 2;
            this.lblGhoulUpgradeParalysisSPS.Text = "Ghoul Upgrade. 4x more efficient";
            this.lblGhoulUpgradeParalysisSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGhoulUpgradeParalysisCost
            // 
            this.lblGhoulUpgradeParalysisCost.Enabled = false;
            this.lblGhoulUpgradeParalysisCost.ForeColor = System.Drawing.Color.White;
            this.lblGhoulUpgradeParalysisCost.Location = new System.Drawing.Point(72, 3);
            this.lblGhoulUpgradeParalysisCost.Name = "lblGhoulUpgradeParalysisCost";
            this.lblGhoulUpgradeParalysisCost.Size = new System.Drawing.Size(217, 18);
            this.lblGhoulUpgradeParalysisCost.TabIndex = 1;
            this.lblGhoulUpgradeParalysisCost.Text = "5,000 Souls";
            this.lblGhoulUpgradeParalysisCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxGhoulUpgradeParalysis
            // 
            this.pbxGhoulUpgradeParalysis.Enabled = false;
            this.pbxGhoulUpgradeParalysis.Image = ((System.Drawing.Image)(resources.GetObject("pbxGhoulUpgradeParalysis.Image")));
            this.pbxGhoulUpgradeParalysis.Location = new System.Drawing.Point(3, 2);
            this.pbxGhoulUpgradeParalysis.Name = "pbxGhoulUpgradeParalysis";
            this.pbxGhoulUpgradeParalysis.Size = new System.Drawing.Size(64, 64);
            this.pbxGhoulUpgradeParalysis.TabIndex = 0;
            this.pbxGhoulUpgradeParalysis.TabStop = false;
            // 
            // pnlGhoulFangsUpgrade
            // 
            this.pnlGhoulFangsUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlGhoulFangsUpgrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlGhoulFangsUpgrade.Controls.Add(this.btnGhoulFangsUpgrade);
            this.pnlGhoulFangsUpgrade.Controls.Add(this.lblGhoulFangsUpgradeDesc);
            this.pnlGhoulFangsUpgrade.Controls.Add(this.lblGhoulFangsUpgradeSPS);
            this.pnlGhoulFangsUpgrade.Controls.Add(this.lblGhoulFangsUpgradeCost);
            this.pnlGhoulFangsUpgrade.Controls.Add(this.pbxGhoulFangsUpgrade);
            this.pnlGhoulFangsUpgrade.Enabled = false;
            this.pnlGhoulFangsUpgrade.Location = new System.Drawing.Point(3, 1523);
            this.pnlGhoulFangsUpgrade.Name = "pnlGhoulFangsUpgrade";
            this.pnlGhoulFangsUpgrade.Size = new System.Drawing.Size(290, 70);
            this.pnlGhoulFangsUpgrade.TabIndex = 9;
            this.pnlGhoulFangsUpgrade.Visible = false;
            // 
            // btnGhoulFangsUpgrade
            // 
            this.btnGhoulFangsUpgrade.BackColor = System.Drawing.Color.Transparent;
            this.btnGhoulFangsUpgrade.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGhoulFangsUpgrade.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGhoulFangsUpgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGhoulFangsUpgrade.ForeColor = System.Drawing.Color.Transparent;
            this.btnGhoulFangsUpgrade.Location = new System.Drawing.Point(-1, -1);
            this.btnGhoulFangsUpgrade.Name = "btnGhoulFangsUpgrade";
            this.btnGhoulFangsUpgrade.Size = new System.Drawing.Size(290, 70);
            this.btnGhoulFangsUpgrade.TabIndex = 12;
            this.btnGhoulFangsUpgrade.UseVisualStyleBackColor = false;
            this.btnGhoulFangsUpgrade.Click += new System.EventHandler(this.btnGhoulFangsUpgrade_Click);
            // 
            // lblGhoulFangsUpgradeDesc
            // 
            this.lblGhoulFangsUpgradeDesc.Enabled = false;
            this.lblGhoulFangsUpgradeDesc.ForeColor = System.Drawing.Color.White;
            this.lblGhoulFangsUpgradeDesc.Location = new System.Drawing.Point(72, 39);
            this.lblGhoulFangsUpgradeDesc.Name = "lblGhoulFangsUpgradeDesc";
            this.lblGhoulFangsUpgradeDesc.Size = new System.Drawing.Size(217, 28);
            this.lblGhoulFangsUpgradeDesc.TabIndex = 3;
            this.lblGhoulFangsUpgradeDesc.Text = "Sharpeneded Fangs. Now with less bark and more bite.";
            this.lblGhoulFangsUpgradeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGhoulFangsUpgradeSPS
            // 
            this.lblGhoulFangsUpgradeSPS.Enabled = false;
            this.lblGhoulFangsUpgradeSPS.ForeColor = System.Drawing.Color.White;
            this.lblGhoulFangsUpgradeSPS.Location = new System.Drawing.Point(72, 21);
            this.lblGhoulFangsUpgradeSPS.Name = "lblGhoulFangsUpgradeSPS";
            this.lblGhoulFangsUpgradeSPS.Size = new System.Drawing.Size(217, 18);
            this.lblGhoulFangsUpgradeSPS.TabIndex = 2;
            this.lblGhoulFangsUpgradeSPS.Text = "Ghoul Upgrade. 2x more efficient";
            this.lblGhoulFangsUpgradeSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGhoulFangsUpgradeCost
            // 
            this.lblGhoulFangsUpgradeCost.Enabled = false;
            this.lblGhoulFangsUpgradeCost.ForeColor = System.Drawing.Color.White;
            this.lblGhoulFangsUpgradeCost.Location = new System.Drawing.Point(72, 3);
            this.lblGhoulFangsUpgradeCost.Name = "lblGhoulFangsUpgradeCost";
            this.lblGhoulFangsUpgradeCost.Size = new System.Drawing.Size(217, 18);
            this.lblGhoulFangsUpgradeCost.TabIndex = 1;
            this.lblGhoulFangsUpgradeCost.Text = "1,000 Souls";
            this.lblGhoulFangsUpgradeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxGhoulFangsUpgrade
            // 
            this.pbxGhoulFangsUpgrade.Enabled = false;
            this.pbxGhoulFangsUpgrade.Image = ((System.Drawing.Image)(resources.GetObject("pbxGhoulFangsUpgrade.Image")));
            this.pbxGhoulFangsUpgrade.Location = new System.Drawing.Point(3, 2);
            this.pbxGhoulFangsUpgrade.Name = "pbxGhoulFangsUpgrade";
            this.pbxGhoulFangsUpgrade.Size = new System.Drawing.Size(64, 64);
            this.pbxGhoulFangsUpgrade.TabIndex = 0;
            this.pbxGhoulFangsUpgrade.TabStop = false;
            // 
            // pnlZombieMutantUpgrade
            // 
            this.pnlZombieMutantUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlZombieMutantUpgrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlZombieMutantUpgrade.Controls.Add(this.btnZombieMutantUpgrade);
            this.pnlZombieMutantUpgrade.Controls.Add(this.lblZombieMutantUpgradeDesc);
            this.pnlZombieMutantUpgrade.Controls.Add(this.lblZombieMutantUpgradeSPS);
            this.pnlZombieMutantUpgrade.Controls.Add(this.lblZombieMutantUpgradeCost);
            this.pnlZombieMutantUpgrade.Controls.Add(this.pbxZombieMutantUpgrade);
            this.pnlZombieMutantUpgrade.Enabled = false;
            this.pnlZombieMutantUpgrade.Location = new System.Drawing.Point(3, 1599);
            this.pnlZombieMutantUpgrade.Name = "pnlZombieMutantUpgrade";
            this.pnlZombieMutantUpgrade.Size = new System.Drawing.Size(290, 70);
            this.pnlZombieMutantUpgrade.TabIndex = 5;
            this.pnlZombieMutantUpgrade.Visible = false;
            // 
            // btnZombieMutantUpgrade
            // 
            this.btnZombieMutantUpgrade.BackColor = System.Drawing.Color.Transparent;
            this.btnZombieMutantUpgrade.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnZombieMutantUpgrade.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnZombieMutantUpgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZombieMutantUpgrade.ForeColor = System.Drawing.Color.Transparent;
            this.btnZombieMutantUpgrade.Location = new System.Drawing.Point(-1, -1);
            this.btnZombieMutantUpgrade.Name = "btnZombieMutantUpgrade";
            this.btnZombieMutantUpgrade.Size = new System.Drawing.Size(290, 70);
            this.btnZombieMutantUpgrade.TabIndex = 11;
            this.btnZombieMutantUpgrade.UseVisualStyleBackColor = false;
            this.btnZombieMutantUpgrade.Click += new System.EventHandler(this.btnZombieMutantUpgrade_Click);
            // 
            // lblZombieMutantUpgradeDesc
            // 
            this.lblZombieMutantUpgradeDesc.Enabled = false;
            this.lblZombieMutantUpgradeDesc.ForeColor = System.Drawing.Color.White;
            this.lblZombieMutantUpgradeDesc.Location = new System.Drawing.Point(72, 39);
            this.lblZombieMutantUpgradeDesc.Name = "lblZombieMutantUpgradeDesc";
            this.lblZombieMutantUpgradeDesc.Size = new System.Drawing.Size(217, 28);
            this.lblZombieMutantUpgradeDesc.TabIndex = 3;
            this.lblZombieMutantUpgradeDesc.Text = "Mutant zombies. Grossly disproportionate, but super strong.";
            this.lblZombieMutantUpgradeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZombieMutantUpgradeSPS
            // 
            this.lblZombieMutantUpgradeSPS.Enabled = false;
            this.lblZombieMutantUpgradeSPS.ForeColor = System.Drawing.Color.White;
            this.lblZombieMutantUpgradeSPS.Location = new System.Drawing.Point(72, 21);
            this.lblZombieMutantUpgradeSPS.Name = "lblZombieMutantUpgradeSPS";
            this.lblZombieMutantUpgradeSPS.Size = new System.Drawing.Size(217, 18);
            this.lblZombieMutantUpgradeSPS.TabIndex = 2;
            this.lblZombieMutantUpgradeSPS.Text = "Zombie Upgrade. 10x more effective";
            this.lblZombieMutantUpgradeSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZombieMutantUpgradeCost
            // 
            this.lblZombieMutantUpgradeCost.Enabled = false;
            this.lblZombieMutantUpgradeCost.ForeColor = System.Drawing.Color.White;
            this.lblZombieMutantUpgradeCost.Location = new System.Drawing.Point(72, 3);
            this.lblZombieMutantUpgradeCost.Name = "lblZombieMutantUpgradeCost";
            this.lblZombieMutantUpgradeCost.Size = new System.Drawing.Size(217, 18);
            this.lblZombieMutantUpgradeCost.TabIndex = 1;
            this.lblZombieMutantUpgradeCost.Text = "10,000 Souls";
            this.lblZombieMutantUpgradeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxZombieMutantUpgrade
            // 
            this.pbxZombieMutantUpgrade.Enabled = false;
            this.pbxZombieMutantUpgrade.Image = ((System.Drawing.Image)(resources.GetObject("pbxZombieMutantUpgrade.Image")));
            this.pbxZombieMutantUpgrade.Location = new System.Drawing.Point(3, 2);
            this.pbxZombieMutantUpgrade.Name = "pbxZombieMutantUpgrade";
            this.pbxZombieMutantUpgrade.Size = new System.Drawing.Size(64, 64);
            this.pbxZombieMutantUpgrade.TabIndex = 0;
            this.pbxZombieMutantUpgrade.TabStop = false;
            // 
            // pnlZombieDiseasedUpgrade
            // 
            this.pnlZombieDiseasedUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlZombieDiseasedUpgrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlZombieDiseasedUpgrade.Controls.Add(this.btnZombieDiseasedUpgrade);
            this.pnlZombieDiseasedUpgrade.Controls.Add(this.lblZombieDiseasedUpgradeDesc);
            this.pnlZombieDiseasedUpgrade.Controls.Add(this.lblZombieDiseasedUpgradeSPS);
            this.pnlZombieDiseasedUpgrade.Controls.Add(this.lblZombieDiseasedUpgradeCost);
            this.pnlZombieDiseasedUpgrade.Controls.Add(this.pbxZombieDiseasedUpgrade);
            this.pnlZombieDiseasedUpgrade.Enabled = false;
            this.pnlZombieDiseasedUpgrade.Location = new System.Drawing.Point(3, 1675);
            this.pnlZombieDiseasedUpgrade.Name = "pnlZombieDiseasedUpgrade";
            this.pnlZombieDiseasedUpgrade.Size = new System.Drawing.Size(290, 70);
            this.pnlZombieDiseasedUpgrade.TabIndex = 4;
            this.pnlZombieDiseasedUpgrade.Visible = false;
            // 
            // btnZombieDiseasedUpgrade
            // 
            this.btnZombieDiseasedUpgrade.BackColor = System.Drawing.Color.Transparent;
            this.btnZombieDiseasedUpgrade.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnZombieDiseasedUpgrade.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnZombieDiseasedUpgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZombieDiseasedUpgrade.ForeColor = System.Drawing.Color.Transparent;
            this.btnZombieDiseasedUpgrade.Location = new System.Drawing.Point(-1, -1);
            this.btnZombieDiseasedUpgrade.Name = "btnZombieDiseasedUpgrade";
            this.btnZombieDiseasedUpgrade.Size = new System.Drawing.Size(290, 70);
            this.btnZombieDiseasedUpgrade.TabIndex = 10;
            this.btnZombieDiseasedUpgrade.UseVisualStyleBackColor = false;
            this.btnZombieDiseasedUpgrade.Click += new System.EventHandler(this.btnZombieDiseasedUpgrade_Click);
            // 
            // lblZombieDiseasedUpgradeDesc
            // 
            this.lblZombieDiseasedUpgradeDesc.Enabled = false;
            this.lblZombieDiseasedUpgradeDesc.ForeColor = System.Drawing.Color.White;
            this.lblZombieDiseasedUpgradeDesc.Location = new System.Drawing.Point(72, 39);
            this.lblZombieDiseasedUpgradeDesc.Name = "lblZombieDiseasedUpgradeDesc";
            this.lblZombieDiseasedUpgradeDesc.Size = new System.Drawing.Size(217, 28);
            this.lblZombieDiseasedUpgradeDesc.TabIndex = 3;
            this.lblZombieDiseasedUpgradeDesc.Text = "Diseased zombies. Spread the plague!";
            this.lblZombieDiseasedUpgradeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZombieDiseasedUpgradeSPS
            // 
            this.lblZombieDiseasedUpgradeSPS.Enabled = false;
            this.lblZombieDiseasedUpgradeSPS.ForeColor = System.Drawing.Color.White;
            this.lblZombieDiseasedUpgradeSPS.Location = new System.Drawing.Point(72, 21);
            this.lblZombieDiseasedUpgradeSPS.Name = "lblZombieDiseasedUpgradeSPS";
            this.lblZombieDiseasedUpgradeSPS.Size = new System.Drawing.Size(217, 18);
            this.lblZombieDiseasedUpgradeSPS.TabIndex = 2;
            this.lblZombieDiseasedUpgradeSPS.Text = "Zombie Upgrade. 4x more effective";
            this.lblZombieDiseasedUpgradeSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZombieDiseasedUpgradeCost
            // 
            this.lblZombieDiseasedUpgradeCost.Enabled = false;
            this.lblZombieDiseasedUpgradeCost.ForeColor = System.Drawing.Color.White;
            this.lblZombieDiseasedUpgradeCost.Location = new System.Drawing.Point(72, 3);
            this.lblZombieDiseasedUpgradeCost.Name = "lblZombieDiseasedUpgradeCost";
            this.lblZombieDiseasedUpgradeCost.Size = new System.Drawing.Size(217, 18);
            this.lblZombieDiseasedUpgradeCost.TabIndex = 1;
            this.lblZombieDiseasedUpgradeCost.Text = "500 Souls";
            this.lblZombieDiseasedUpgradeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxZombieDiseasedUpgrade
            // 
            this.pbxZombieDiseasedUpgrade.Enabled = false;
            this.pbxZombieDiseasedUpgrade.Image = ((System.Drawing.Image)(resources.GetObject("pbxZombieDiseasedUpgrade.Image")));
            this.pbxZombieDiseasedUpgrade.Location = new System.Drawing.Point(3, 2);
            this.pbxZombieDiseasedUpgrade.Name = "pbxZombieDiseasedUpgrade";
            this.pbxZombieDiseasedUpgrade.Size = new System.Drawing.Size(64, 64);
            this.pbxZombieDiseasedUpgrade.TabIndex = 0;
            this.pbxZombieDiseasedUpgrade.TabStop = false;
            // 
            // pnlZombieFastUpgrade
            // 
            this.pnlZombieFastUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlZombieFastUpgrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlZombieFastUpgrade.Controls.Add(this.btnZombieFastUpgrade);
            this.pnlZombieFastUpgrade.Controls.Add(this.lblZombieFastUpgradeDesc);
            this.pnlZombieFastUpgrade.Controls.Add(this.lblZombieFastUpgradeSPS);
            this.pnlZombieFastUpgrade.Controls.Add(this.lblZombieFastUpgradeCost);
            this.pnlZombieFastUpgrade.Controls.Add(this.pbxZombieFastUpgrade);
            this.pnlZombieFastUpgrade.Enabled = false;
            this.pnlZombieFastUpgrade.Location = new System.Drawing.Point(3, 1751);
            this.pnlZombieFastUpgrade.Name = "pnlZombieFastUpgrade";
            this.pnlZombieFastUpgrade.Size = new System.Drawing.Size(290, 70);
            this.pnlZombieFastUpgrade.TabIndex = 0;
            this.pnlZombieFastUpgrade.Visible = false;
            // 
            // btnZombieFastUpgrade
            // 
            this.btnZombieFastUpgrade.BackColor = System.Drawing.Color.Transparent;
            this.btnZombieFastUpgrade.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnZombieFastUpgrade.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnZombieFastUpgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZombieFastUpgrade.ForeColor = System.Drawing.Color.Transparent;
            this.btnZombieFastUpgrade.Location = new System.Drawing.Point(-1, -1);
            this.btnZombieFastUpgrade.Name = "btnZombieFastUpgrade";
            this.btnZombieFastUpgrade.Size = new System.Drawing.Size(290, 70);
            this.btnZombieFastUpgrade.TabIndex = 9;
            this.btnZombieFastUpgrade.UseVisualStyleBackColor = false;
            this.btnZombieFastUpgrade.Click += new System.EventHandler(this.btnZombieFastUpgrade_Click);
            // 
            // lblZombieFastUpgradeDesc
            // 
            this.lblZombieFastUpgradeDesc.Enabled = false;
            this.lblZombieFastUpgradeDesc.ForeColor = System.Drawing.Color.White;
            this.lblZombieFastUpgradeDesc.Location = new System.Drawing.Point(72, 39);
            this.lblZombieFastUpgradeDesc.Name = "lblZombieFastUpgradeDesc";
            this.lblZombieFastUpgradeDesc.Size = new System.Drawing.Size(217, 28);
            this.lblZombieFastUpgradeDesc.TabIndex = 3;
            this.lblZombieFastUpgradeDesc.Text = "Faster Zombies = more dangerous";
            this.lblZombieFastUpgradeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZombieFastUpgradeSPS
            // 
            this.lblZombieFastUpgradeSPS.Enabled = false;
            this.lblZombieFastUpgradeSPS.ForeColor = System.Drawing.Color.White;
            this.lblZombieFastUpgradeSPS.Location = new System.Drawing.Point(72, 21);
            this.lblZombieFastUpgradeSPS.Name = "lblZombieFastUpgradeSPS";
            this.lblZombieFastUpgradeSPS.Size = new System.Drawing.Size(217, 18);
            this.lblZombieFastUpgradeSPS.TabIndex = 2;
            this.lblZombieFastUpgradeSPS.Text = "Zombie Upgrade. 2x more effective";
            this.lblZombieFastUpgradeSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZombieFastUpgradeCost
            // 
            this.lblZombieFastUpgradeCost.Enabled = false;
            this.lblZombieFastUpgradeCost.ForeColor = System.Drawing.Color.White;
            this.lblZombieFastUpgradeCost.Location = new System.Drawing.Point(72, 3);
            this.lblZombieFastUpgradeCost.Name = "lblZombieFastUpgradeCost";
            this.lblZombieFastUpgradeCost.Size = new System.Drawing.Size(217, 18);
            this.lblZombieFastUpgradeCost.TabIndex = 1;
            this.lblZombieFastUpgradeCost.Text = "100 Souls";
            this.lblZombieFastUpgradeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxZombieFastUpgrade
            // 
            this.pbxZombieFastUpgrade.Enabled = false;
            this.pbxZombieFastUpgrade.Image = ((System.Drawing.Image)(resources.GetObject("pbxZombieFastUpgrade.Image")));
            this.pbxZombieFastUpgrade.Location = new System.Drawing.Point(3, 2);
            this.pbxZombieFastUpgrade.Name = "pbxZombieFastUpgrade";
            this.pbxZombieFastUpgrade.Size = new System.Drawing.Size(64, 64);
            this.pbxZombieFastUpgrade.TabIndex = 0;
            this.pbxZombieFastUpgrade.TabStop = false;
            // 
            // pnlDemonHelperUpgrade
            // 
            this.pnlDemonHelperUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlDemonHelperUpgrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDemonHelperUpgrade.Controls.Add(this.btnDemonHelperUpgrade);
            this.pnlDemonHelperUpgrade.Controls.Add(this.lblDemonHelperUpgradeDesc);
            this.pnlDemonHelperUpgrade.Controls.Add(this.lblDemonHelperUpgradeSPC);
            this.pnlDemonHelperUpgrade.Controls.Add(this.lblDemonHelperUpgradeCost);
            this.pnlDemonHelperUpgrade.Controls.Add(this.pbxDemonHelperUpgrade);
            this.pnlDemonHelperUpgrade.Enabled = false;
            this.pnlDemonHelperUpgrade.Location = new System.Drawing.Point(3, 1827);
            this.pnlDemonHelperUpgrade.Name = "pnlDemonHelperUpgrade";
            this.pnlDemonHelperUpgrade.Size = new System.Drawing.Size(290, 70);
            this.pnlDemonHelperUpgrade.TabIndex = 8;
            this.pnlDemonHelperUpgrade.Visible = false;
            // 
            // btnDemonHelperUpgrade
            // 
            this.btnDemonHelperUpgrade.BackColor = System.Drawing.Color.Transparent;
            this.btnDemonHelperUpgrade.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDemonHelperUpgrade.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDemonHelperUpgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDemonHelperUpgrade.ForeColor = System.Drawing.Color.Transparent;
            this.btnDemonHelperUpgrade.Location = new System.Drawing.Point(-1, -1);
            this.btnDemonHelperUpgrade.Name = "btnDemonHelperUpgrade";
            this.btnDemonHelperUpgrade.Size = new System.Drawing.Size(290, 70);
            this.btnDemonHelperUpgrade.TabIndex = 8;
            this.btnDemonHelperUpgrade.UseVisualStyleBackColor = false;
            this.btnDemonHelperUpgrade.Click += new System.EventHandler(this.btnDemonHelperUpgrade_Click);
            // 
            // lblDemonHelperUpgradeDesc
            // 
            this.lblDemonHelperUpgradeDesc.Enabled = false;
            this.lblDemonHelperUpgradeDesc.ForeColor = System.Drawing.Color.White;
            this.lblDemonHelperUpgradeDesc.Location = new System.Drawing.Point(72, 39);
            this.lblDemonHelperUpgradeDesc.Name = "lblDemonHelperUpgradeDesc";
            this.lblDemonHelperUpgradeDesc.Size = new System.Drawing.Size(217, 28);
            this.lblDemonHelperUpgradeDesc.TabIndex = 3;
            this.lblDemonHelperUpgradeDesc.Text = "Demon Helper. Looks menacing, but at least he doesn\'t drop stuff.";
            this.lblDemonHelperUpgradeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDemonHelperUpgradeSPC
            // 
            this.lblDemonHelperUpgradeSPC.Enabled = false;
            this.lblDemonHelperUpgradeSPC.ForeColor = System.Drawing.Color.White;
            this.lblDemonHelperUpgradeSPC.Location = new System.Drawing.Point(72, 21);
            this.lblDemonHelperUpgradeSPC.Name = "lblDemonHelperUpgradeSPC";
            this.lblDemonHelperUpgradeSPC.Size = new System.Drawing.Size(217, 18);
            this.lblDemonHelperUpgradeSPC.TabIndex = 2;
            this.lblDemonHelperUpgradeSPC.Text = "+1% of your SPS";
            this.lblDemonHelperUpgradeSPC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDemonHelperUpgradeCost
            // 
            this.lblDemonHelperUpgradeCost.Enabled = false;
            this.lblDemonHelperUpgradeCost.ForeColor = System.Drawing.Color.White;
            this.lblDemonHelperUpgradeCost.Location = new System.Drawing.Point(72, 3);
            this.lblDemonHelperUpgradeCost.Name = "lblDemonHelperUpgradeCost";
            this.lblDemonHelperUpgradeCost.Size = new System.Drawing.Size(217, 18);
            this.lblDemonHelperUpgradeCost.TabIndex = 1;
            this.lblDemonHelperUpgradeCost.Text = "1,000,000 Souls";
            this.lblDemonHelperUpgradeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxDemonHelperUpgrade
            // 
            this.pbxDemonHelperUpgrade.Enabled = false;
            this.pbxDemonHelperUpgrade.Image = ((System.Drawing.Image)(resources.GetObject("pbxDemonHelperUpgrade.Image")));
            this.pbxDemonHelperUpgrade.Location = new System.Drawing.Point(3, 2);
            this.pbxDemonHelperUpgrade.Name = "pbxDemonHelperUpgrade";
            this.pbxDemonHelperUpgrade.Size = new System.Drawing.Size(64, 64);
            this.pbxDemonHelperUpgrade.TabIndex = 0;
            this.pbxDemonHelperUpgrade.TabStop = false;
            // 
            // pnlAltarUpgrade
            // 
            this.pnlAltarUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlAltarUpgrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAltarUpgrade.Controls.Add(this.btnAltarUpgrade);
            this.pnlAltarUpgrade.Controls.Add(this.lblAltarUpgradeDesc);
            this.pnlAltarUpgrade.Controls.Add(this.lblAltarUpgradeSPC);
            this.pnlAltarUpgrade.Controls.Add(this.lblAltarUpgradeCost);
            this.pnlAltarUpgrade.Controls.Add(this.pbxAltarUpgrade);
            this.pnlAltarUpgrade.Enabled = false;
            this.pnlAltarUpgrade.Location = new System.Drawing.Point(3, 1903);
            this.pnlAltarUpgrade.Name = "pnlAltarUpgrade";
            this.pnlAltarUpgrade.Size = new System.Drawing.Size(290, 70);
            this.pnlAltarUpgrade.TabIndex = 7;
            this.pnlAltarUpgrade.Visible = false;
            // 
            // btnAltarUpgrade
            // 
            this.btnAltarUpgrade.BackColor = System.Drawing.Color.Transparent;
            this.btnAltarUpgrade.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnAltarUpgrade.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnAltarUpgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAltarUpgrade.ForeColor = System.Drawing.Color.Transparent;
            this.btnAltarUpgrade.Location = new System.Drawing.Point(-1, -1);
            this.btnAltarUpgrade.Name = "btnAltarUpgrade";
            this.btnAltarUpgrade.Size = new System.Drawing.Size(290, 70);
            this.btnAltarUpgrade.TabIndex = 7;
            this.btnAltarUpgrade.UseVisualStyleBackColor = false;
            this.btnAltarUpgrade.Click += new System.EventHandler(this.btnAltarUpgrade_Click);
            // 
            // lblAltarUpgradeDesc
            // 
            this.lblAltarUpgradeDesc.Enabled = false;
            this.lblAltarUpgradeDesc.ForeColor = System.Drawing.Color.White;
            this.lblAltarUpgradeDesc.Location = new System.Drawing.Point(72, 39);
            this.lblAltarUpgradeDesc.Name = "lblAltarUpgradeDesc";
            this.lblAltarUpgradeDesc.Size = new System.Drawing.Size(217, 28);
            this.lblAltarUpgradeDesc.TabIndex = 3;
            this.lblAltarUpgradeDesc.Text = "Demonic Altar. Now you can sacrifice people! Yay!";
            this.lblAltarUpgradeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAltarUpgradeSPC
            // 
            this.lblAltarUpgradeSPC.Enabled = false;
            this.lblAltarUpgradeSPC.ForeColor = System.Drawing.Color.White;
            this.lblAltarUpgradeSPC.Location = new System.Drawing.Point(72, 21);
            this.lblAltarUpgradeSPC.Name = "lblAltarUpgradeSPC";
            this.lblAltarUpgradeSPC.Size = new System.Drawing.Size(217, 18);
            this.lblAltarUpgradeSPC.TabIndex = 2;
            this.lblAltarUpgradeSPC.Text = "+1% of your SPS";
            this.lblAltarUpgradeSPC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAltarUpgradeCost
            // 
            this.lblAltarUpgradeCost.Enabled = false;
            this.lblAltarUpgradeCost.ForeColor = System.Drawing.Color.White;
            this.lblAltarUpgradeCost.Location = new System.Drawing.Point(72, 3);
            this.lblAltarUpgradeCost.Name = "lblAltarUpgradeCost";
            this.lblAltarUpgradeCost.Size = new System.Drawing.Size(217, 18);
            this.lblAltarUpgradeCost.TabIndex = 1;
            this.lblAltarUpgradeCost.Text = "100,000 Souls";
            this.lblAltarUpgradeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxAltarUpgrade
            // 
            this.pbxAltarUpgrade.Enabled = false;
            this.pbxAltarUpgrade.Image = ((System.Drawing.Image)(resources.GetObject("pbxAltarUpgrade.Image")));
            this.pbxAltarUpgrade.Location = new System.Drawing.Point(3, 2);
            this.pbxAltarUpgrade.Name = "pbxAltarUpgrade";
            this.pbxAltarUpgrade.Size = new System.Drawing.Size(64, 64);
            this.pbxAltarUpgrade.TabIndex = 0;
            this.pbxAltarUpgrade.TabStop = false;
            // 
            // pnlImpUpgrade
            // 
            this.pnlImpUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlImpUpgrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlImpUpgrade.Controls.Add(this.btnImpUpgrade);
            this.pnlImpUpgrade.Controls.Add(this.lblImpUpgradeDesc);
            this.pnlImpUpgrade.Controls.Add(this.lblImpUpgradeSPC);
            this.pnlImpUpgrade.Controls.Add(this.lblImpUpgradeCost);
            this.pnlImpUpgrade.Controls.Add(this.pbxImpUpgrade);
            this.pnlImpUpgrade.Enabled = false;
            this.pnlImpUpgrade.Location = new System.Drawing.Point(3, 1979);
            this.pnlImpUpgrade.Name = "pnlImpUpgrade";
            this.pnlImpUpgrade.Size = new System.Drawing.Size(290, 70);
            this.pnlImpUpgrade.TabIndex = 6;
            this.pnlImpUpgrade.Visible = false;
            // 
            // btnImpUpgrade
            // 
            this.btnImpUpgrade.BackColor = System.Drawing.Color.Transparent;
            this.btnImpUpgrade.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnImpUpgrade.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnImpUpgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImpUpgrade.ForeColor = System.Drawing.Color.Transparent;
            this.btnImpUpgrade.Location = new System.Drawing.Point(-1, -1);
            this.btnImpUpgrade.Name = "btnImpUpgrade";
            this.btnImpUpgrade.Size = new System.Drawing.Size(290, 70);
            this.btnImpUpgrade.TabIndex = 6;
            this.btnImpUpgrade.UseVisualStyleBackColor = false;
            this.btnImpUpgrade.Click += new System.EventHandler(this.btnImpUpgrade_Click);
            // 
            // lblImpUpgradeDesc
            // 
            this.lblImpUpgradeDesc.Enabled = false;
            this.lblImpUpgradeDesc.ForeColor = System.Drawing.Color.White;
            this.lblImpUpgradeDesc.Location = new System.Drawing.Point(72, 39);
            this.lblImpUpgradeDesc.Name = "lblImpUpgradeDesc";
            this.lblImpUpgradeDesc.Size = new System.Drawing.Size(217, 28);
            this.lblImpUpgradeDesc.TabIndex = 3;
            this.lblImpUpgradeDesc.Text = "Imp Helpers. Cleans up around the cove.";
            this.lblImpUpgradeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblImpUpgradeSPC
            // 
            this.lblImpUpgradeSPC.Enabled = false;
            this.lblImpUpgradeSPC.ForeColor = System.Drawing.Color.White;
            this.lblImpUpgradeSPC.Location = new System.Drawing.Point(72, 21);
            this.lblImpUpgradeSPC.Name = "lblImpUpgradeSPC";
            this.lblImpUpgradeSPC.Size = new System.Drawing.Size(217, 18);
            this.lblImpUpgradeSPC.TabIndex = 2;
            this.lblImpUpgradeSPC.Text = "+1% of your SPS";
            this.lblImpUpgradeSPC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblImpUpgradeCost
            // 
            this.lblImpUpgradeCost.Enabled = false;
            this.lblImpUpgradeCost.ForeColor = System.Drawing.Color.White;
            this.lblImpUpgradeCost.Location = new System.Drawing.Point(72, 3);
            this.lblImpUpgradeCost.Name = "lblImpUpgradeCost";
            this.lblImpUpgradeCost.Size = new System.Drawing.Size(217, 18);
            this.lblImpUpgradeCost.TabIndex = 1;
            this.lblImpUpgradeCost.Text = "10,000 Souls";
            this.lblImpUpgradeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxImpUpgrade
            // 
            this.pbxImpUpgrade.Enabled = false;
            this.pbxImpUpgrade.Image = ((System.Drawing.Image)(resources.GetObject("pbxImpUpgrade.Image")));
            this.pbxImpUpgrade.Location = new System.Drawing.Point(3, 2);
            this.pbxImpUpgrade.Name = "pbxImpUpgrade";
            this.pbxImpUpgrade.Size = new System.Drawing.Size(64, 64);
            this.pbxImpUpgrade.TabIndex = 0;
            this.pbxImpUpgrade.TabStop = false;
            // 
            // pnlCouldronUpgrade
            // 
            this.pnlCouldronUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlCouldronUpgrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCouldronUpgrade.Controls.Add(this.btnCouldronupgrade);
            this.pnlCouldronUpgrade.Controls.Add(this.lblCouldronUpgradeDesc);
            this.pnlCouldronUpgrade.Controls.Add(this.lblCouldronUpgradeSPC);
            this.pnlCouldronUpgrade.Controls.Add(this.lblCouldronUpgradeCost);
            this.pnlCouldronUpgrade.Controls.Add(this.pbxlCouldronUpgrade);
            this.pnlCouldronUpgrade.Enabled = false;
            this.pnlCouldronUpgrade.Location = new System.Drawing.Point(3, 2055);
            this.pnlCouldronUpgrade.Name = "pnlCouldronUpgrade";
            this.pnlCouldronUpgrade.Size = new System.Drawing.Size(290, 70);
            this.pnlCouldronUpgrade.TabIndex = 5;
            this.pnlCouldronUpgrade.Visible = false;
            // 
            // btnCouldronupgrade
            // 
            this.btnCouldronupgrade.BackColor = System.Drawing.Color.Transparent;
            this.btnCouldronupgrade.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnCouldronupgrade.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnCouldronupgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCouldronupgrade.ForeColor = System.Drawing.Color.Transparent;
            this.btnCouldronupgrade.Location = new System.Drawing.Point(-1, -1);
            this.btnCouldronupgrade.Name = "btnCouldronupgrade";
            this.btnCouldronupgrade.Size = new System.Drawing.Size(290, 70);
            this.btnCouldronupgrade.TabIndex = 5;
            this.btnCouldronupgrade.UseVisualStyleBackColor = false;
            this.btnCouldronupgrade.Click += new System.EventHandler(this.btnCouldronupgrade_Click);
            // 
            // lblCouldronUpgradeDesc
            // 
            this.lblCouldronUpgradeDesc.Enabled = false;
            this.lblCouldronUpgradeDesc.ForeColor = System.Drawing.Color.White;
            this.lblCouldronUpgradeDesc.Location = new System.Drawing.Point(72, 39);
            this.lblCouldronUpgradeDesc.Name = "lblCouldronUpgradeDesc";
            this.lblCouldronUpgradeDesc.Size = new System.Drawing.Size(217, 28);
            this.lblCouldronUpgradeDesc.TabIndex = 3;
            this.lblCouldronUpgradeDesc.Text = "Couldron. Useful for mixing up new brews.";
            this.lblCouldronUpgradeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCouldronUpgradeSPC
            // 
            this.lblCouldronUpgradeSPC.Enabled = false;
            this.lblCouldronUpgradeSPC.ForeColor = System.Drawing.Color.White;
            this.lblCouldronUpgradeSPC.Location = new System.Drawing.Point(72, 21);
            this.lblCouldronUpgradeSPC.Name = "lblCouldronUpgradeSPC";
            this.lblCouldronUpgradeSPC.Size = new System.Drawing.Size(217, 18);
            this.lblCouldronUpgradeSPC.TabIndex = 2;
            this.lblCouldronUpgradeSPC.Text = "+1% of your SPS";
            this.lblCouldronUpgradeSPC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCouldronUpgradeCost
            // 
            this.lblCouldronUpgradeCost.Enabled = false;
            this.lblCouldronUpgradeCost.ForeColor = System.Drawing.Color.White;
            this.lblCouldronUpgradeCost.Location = new System.Drawing.Point(72, 3);
            this.lblCouldronUpgradeCost.Name = "lblCouldronUpgradeCost";
            this.lblCouldronUpgradeCost.Size = new System.Drawing.Size(217, 18);
            this.lblCouldronUpgradeCost.TabIndex = 1;
            this.lblCouldronUpgradeCost.Text = "1,000 Souls";
            this.lblCouldronUpgradeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxlCouldronUpgrade
            // 
            this.pbxlCouldronUpgrade.Enabled = false;
            this.pbxlCouldronUpgrade.Image = ((System.Drawing.Image)(resources.GetObject("pbxlCouldronUpgrade.Image")));
            this.pbxlCouldronUpgrade.Location = new System.Drawing.Point(3, 2);
            this.pbxlCouldronUpgrade.Name = "pbxlCouldronUpgrade";
            this.pbxlCouldronUpgrade.Size = new System.Drawing.Size(64, 64);
            this.pbxlCouldronUpgrade.TabIndex = 0;
            this.pbxlCouldronUpgrade.TabStop = false;
            // 
            // pnlBookUpgrade
            // 
            this.pnlBookUpgrade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlBookUpgrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBookUpgrade.Controls.Add(this.btnBookUpgrade);
            this.pnlBookUpgrade.Controls.Add(this.lblBookUpgradeDesc);
            this.pnlBookUpgrade.Controls.Add(this.lblBookUpgradeSPS);
            this.pnlBookUpgrade.Controls.Add(this.lblBookUpgradeCost);
            this.pnlBookUpgrade.Controls.Add(this.pbxBookUpgrade);
            this.pnlBookUpgrade.Location = new System.Drawing.Point(3, 2131);
            this.pnlBookUpgrade.Name = "pnlBookUpgrade";
            this.pnlBookUpgrade.Size = new System.Drawing.Size(290, 70);
            this.pnlBookUpgrade.TabIndex = 4;
            // 
            // btnBookUpgrade
            // 
            this.btnBookUpgrade.BackColor = System.Drawing.Color.Transparent;
            this.btnBookUpgrade.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnBookUpgrade.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnBookUpgrade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBookUpgrade.ForeColor = System.Drawing.Color.Transparent;
            this.btnBookUpgrade.Location = new System.Drawing.Point(-1, -1);
            this.btnBookUpgrade.Name = "btnBookUpgrade";
            this.btnBookUpgrade.Size = new System.Drawing.Size(290, 70);
            this.btnBookUpgrade.TabIndex = 4;
            this.btnBookUpgrade.UseVisualStyleBackColor = false;
            this.btnBookUpgrade.Click += new System.EventHandler(this.btnBookUpgrade_Click);
            // 
            // lblBookUpgradeDesc
            // 
            this.lblBookUpgradeDesc.Enabled = false;
            this.lblBookUpgradeDesc.ForeColor = System.Drawing.Color.White;
            this.lblBookUpgradeDesc.Location = new System.Drawing.Point(72, 39);
            this.lblBookUpgradeDesc.Name = "lblBookUpgradeDesc";
            this.lblBookUpgradeDesc.Size = new System.Drawing.Size(217, 28);
            this.lblBookUpgradeDesc.TabIndex = 3;
            this.lblBookUpgradeDesc.Text = "Summoning Book. Found in a cave. I wonder what it does.";
            this.lblBookUpgradeDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBookUpgradeSPS
            // 
            this.lblBookUpgradeSPS.Enabled = false;
            this.lblBookUpgradeSPS.ForeColor = System.Drawing.Color.White;
            this.lblBookUpgradeSPS.Location = new System.Drawing.Point(72, 21);
            this.lblBookUpgradeSPS.Name = "lblBookUpgradeSPS";
            this.lblBookUpgradeSPS.Size = new System.Drawing.Size(217, 18);
            this.lblBookUpgradeSPS.TabIndex = 2;
            this.lblBookUpgradeSPS.Text = "Adds 1 spc";
            this.lblBookUpgradeSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBookUpgradeCost
            // 
            this.lblBookUpgradeCost.Enabled = false;
            this.lblBookUpgradeCost.ForeColor = System.Drawing.Color.White;
            this.lblBookUpgradeCost.Location = new System.Drawing.Point(72, 3);
            this.lblBookUpgradeCost.Name = "lblBookUpgradeCost";
            this.lblBookUpgradeCost.Size = new System.Drawing.Size(217, 18);
            this.lblBookUpgradeCost.TabIndex = 1;
            this.lblBookUpgradeCost.Text = "0 Souls";
            this.lblBookUpgradeCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxBookUpgrade
            // 
            this.pbxBookUpgrade.Enabled = false;
            this.pbxBookUpgrade.Image = ((System.Drawing.Image)(resources.GetObject("pbxBookUpgrade.Image")));
            this.pbxBookUpgrade.Location = new System.Drawing.Point(3, 2);
            this.pbxBookUpgrade.Name = "pbxBookUpgrade";
            this.pbxBookUpgrade.Size = new System.Drawing.Size(64, 64);
            this.pbxBookUpgrade.TabIndex = 0;
            this.pbxBookUpgrade.TabStop = false;
            // 
            // fpnlAutoClickers
            // 
            this.fpnlAutoClickers.AutoScroll = true;
            this.fpnlAutoClickers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(97)))), ((int)(((byte)(94)))), ((int)(((byte)(164)))));
            this.fpnlAutoClickers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.fpnlAutoClickers.Controls.Add(this.pnlZombie);
            this.fpnlAutoClickers.Controls.Add(this.pnlGhoul);
            this.fpnlAutoClickers.Controls.Add(this.pnlSkeleton);
            this.fpnlAutoClickers.Controls.Add(this.pnlVampire);
            this.fpnlAutoClickers.Controls.Add(this.pnlWraith);
            this.fpnlAutoClickers.Controls.Add(this.pnlLich);
            this.fpnlAutoClickers.Controls.Add(this.pnlDeathKnight);
            this.fpnlAutoClickers.Controls.Add(this.pnlDragon);
            this.fpnlAutoClickers.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.fpnlAutoClickers.Location = new System.Drawing.Point(678, 236);
            this.fpnlAutoClickers.Name = "fpnlAutoClickers";
            this.fpnlAutoClickers.Size = new System.Drawing.Size(318, 481);
            this.fpnlAutoClickers.TabIndex = 2;
            this.fpnlAutoClickers.WrapContents = false;
            // 
            // pnlZombie
            // 
            this.pnlZombie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlZombie.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlZombie.Controls.Add(this.btnZombie);
            this.pnlZombie.Controls.Add(this.lblZombieDesc);
            this.pnlZombie.Controls.Add(this.lblZombieAmount);
            this.pnlZombie.Controls.Add(this.lblZombieCost);
            this.pnlZombie.Controls.Add(this.pbxZombie);
            this.pnlZombie.Enabled = false;
            this.pnlZombie.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.pnlZombie.Location = new System.Drawing.Point(3, 3);
            this.pnlZombie.Name = "pnlZombie";
            this.pnlZombie.Size = new System.Drawing.Size(290, 78);
            this.pnlZombie.TabIndex = 6;
            this.pnlZombie.Visible = false;
            // 
            // btnZombie
            // 
            this.btnZombie.BackColor = System.Drawing.Color.Transparent;
            this.btnZombie.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnZombie.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnZombie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnZombie.ForeColor = System.Drawing.Color.Transparent;
            this.btnZombie.Location = new System.Drawing.Point(-1, -1);
            this.btnZombie.Name = "btnZombie";
            this.btnZombie.Size = new System.Drawing.Size(290, 78);
            this.btnZombie.TabIndex = 31;
            this.btnZombie.UseVisualStyleBackColor = false;
            this.btnZombie.Click += new System.EventHandler(this.btnZombie_Click);
            // 
            // lblZombieDesc
            // 
            this.lblZombieDesc.Enabled = false;
            this.lblZombieDesc.ForeColor = System.Drawing.Color.White;
            this.lblZombieDesc.Location = new System.Drawing.Point(72, 39);
            this.lblZombieDesc.Name = "lblZombieDesc";
            this.lblZombieDesc.Size = new System.Drawing.Size(217, 28);
            this.lblZombieDesc.TabIndex = 3;
            this.lblZombieDesc.Text = "Zombie";
            this.lblZombieDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZombieAmount
            // 
            this.lblZombieAmount.Enabled = false;
            this.lblZombieAmount.ForeColor = System.Drawing.Color.White;
            this.lblZombieAmount.Location = new System.Drawing.Point(72, 21);
            this.lblZombieAmount.Name = "lblZombieAmount";
            this.lblZombieAmount.Size = new System.Drawing.Size(217, 18);
            this.lblZombieAmount.TabIndex = 2;
            this.lblZombieAmount.Text = "Population: 0 SPS: 0";
            this.lblZombieAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblZombieCost
            // 
            this.lblZombieCost.Enabled = false;
            this.lblZombieCost.ForeColor = System.Drawing.Color.White;
            this.lblZombieCost.Location = new System.Drawing.Point(72, 3);
            this.lblZombieCost.Name = "lblZombieCost";
            this.lblZombieCost.Size = new System.Drawing.Size(217, 18);
            this.lblZombieCost.TabIndex = 1;
            this.lblZombieCost.Text = "15 Souls";
            this.lblZombieCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxZombie
            // 
            this.pbxZombie.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxZombie.Image = ((System.Drawing.Image)(resources.GetObject("pbxZombie.Image")));
            this.pbxZombie.Location = new System.Drawing.Point(3, 2);
            this.pbxZombie.Name = "pbxZombie";
            this.pbxZombie.Size = new System.Drawing.Size(64, 71);
            this.pbxZombie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxZombie.TabIndex = 0;
            this.pbxZombie.TabStop = false;
            // 
            // pnlGhoul
            // 
            this.pnlGhoul.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlGhoul.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlGhoul.Controls.Add(this.btnGhoul);
            this.pnlGhoul.Controls.Add(this.lblGhoulDesc);
            this.pnlGhoul.Controls.Add(this.lblGhoulAmount);
            this.pnlGhoul.Controls.Add(this.lblGhoulCost);
            this.pnlGhoul.Controls.Add(this.pbxGhoul);
            this.pnlGhoul.Enabled = false;
            this.pnlGhoul.Location = new System.Drawing.Point(3, 87);
            this.pnlGhoul.Name = "pnlGhoul";
            this.pnlGhoul.Size = new System.Drawing.Size(290, 78);
            this.pnlGhoul.TabIndex = 7;
            this.pnlGhoul.Visible = false;
            // 
            // btnGhoul
            // 
            this.btnGhoul.BackColor = System.Drawing.Color.Transparent;
            this.btnGhoul.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnGhoul.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnGhoul.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGhoul.ForeColor = System.Drawing.Color.Transparent;
            this.btnGhoul.Location = new System.Drawing.Point(-1, -1);
            this.btnGhoul.Name = "btnGhoul";
            this.btnGhoul.Size = new System.Drawing.Size(290, 78);
            this.btnGhoul.TabIndex = 32;
            this.btnGhoul.UseVisualStyleBackColor = false;
            this.btnGhoul.Click += new System.EventHandler(this.btnGhoul_Click);
            // 
            // lblGhoulDesc
            // 
            this.lblGhoulDesc.Enabled = false;
            this.lblGhoulDesc.ForeColor = System.Drawing.Color.White;
            this.lblGhoulDesc.Location = new System.Drawing.Point(72, 39);
            this.lblGhoulDesc.Name = "lblGhoulDesc";
            this.lblGhoulDesc.Size = new System.Drawing.Size(217, 28);
            this.lblGhoulDesc.TabIndex = 3;
            this.lblGhoulDesc.Text = "Ghoul";
            this.lblGhoulDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGhoulAmount
            // 
            this.lblGhoulAmount.Enabled = false;
            this.lblGhoulAmount.ForeColor = System.Drawing.Color.White;
            this.lblGhoulAmount.Location = new System.Drawing.Point(72, 21);
            this.lblGhoulAmount.Name = "lblGhoulAmount";
            this.lblGhoulAmount.Size = new System.Drawing.Size(217, 18);
            this.lblGhoulAmount.TabIndex = 2;
            this.lblGhoulAmount.Text = "Population: 0 SPS: 0";
            this.lblGhoulAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGhoulCost
            // 
            this.lblGhoulCost.Enabled = false;
            this.lblGhoulCost.ForeColor = System.Drawing.Color.White;
            this.lblGhoulCost.Location = new System.Drawing.Point(72, 3);
            this.lblGhoulCost.Name = "lblGhoulCost";
            this.lblGhoulCost.Size = new System.Drawing.Size(217, 18);
            this.lblGhoulCost.TabIndex = 1;
            this.lblGhoulCost.Text = "100 Souls";
            this.lblGhoulCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxGhoul
            // 
            this.pbxGhoul.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxGhoul.Image = ((System.Drawing.Image)(resources.GetObject("pbxGhoul.Image")));
            this.pbxGhoul.Location = new System.Drawing.Point(3, 2);
            this.pbxGhoul.Name = "pbxGhoul";
            this.pbxGhoul.Size = new System.Drawing.Size(64, 71);
            this.pbxGhoul.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxGhoul.TabIndex = 0;
            this.pbxGhoul.TabStop = false;
            // 
            // pnlSkeleton
            // 
            this.pnlSkeleton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlSkeleton.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSkeleton.Controls.Add(this.btnSkeleton);
            this.pnlSkeleton.Controls.Add(this.lblSkeletonDesc);
            this.pnlSkeleton.Controls.Add(this.lblSkeletonAmount);
            this.pnlSkeleton.Controls.Add(this.lblSkeletonCost);
            this.pnlSkeleton.Controls.Add(this.pbxSkeleton);
            this.pnlSkeleton.Enabled = false;
            this.pnlSkeleton.Location = new System.Drawing.Point(3, 171);
            this.pnlSkeleton.Name = "pnlSkeleton";
            this.pnlSkeleton.Size = new System.Drawing.Size(290, 78);
            this.pnlSkeleton.TabIndex = 8;
            this.pnlSkeleton.Visible = false;
            // 
            // btnSkeleton
            // 
            this.btnSkeleton.BackColor = System.Drawing.Color.Transparent;
            this.btnSkeleton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnSkeleton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnSkeleton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSkeleton.ForeColor = System.Drawing.Color.Transparent;
            this.btnSkeleton.Location = new System.Drawing.Point(-1, -1);
            this.btnSkeleton.Name = "btnSkeleton";
            this.btnSkeleton.Size = new System.Drawing.Size(290, 78);
            this.btnSkeleton.TabIndex = 32;
            this.btnSkeleton.UseVisualStyleBackColor = false;
            this.btnSkeleton.Click += new System.EventHandler(this.btnSkeleton_Click);
            // 
            // lblSkeletonDesc
            // 
            this.lblSkeletonDesc.Enabled = false;
            this.lblSkeletonDesc.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonDesc.Location = new System.Drawing.Point(72, 39);
            this.lblSkeletonDesc.Name = "lblSkeletonDesc";
            this.lblSkeletonDesc.Size = new System.Drawing.Size(217, 28);
            this.lblSkeletonDesc.TabIndex = 3;
            this.lblSkeletonDesc.Text = "Skeleton";
            this.lblSkeletonDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSkeletonAmount
            // 
            this.lblSkeletonAmount.Enabled = false;
            this.lblSkeletonAmount.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonAmount.Location = new System.Drawing.Point(72, 21);
            this.lblSkeletonAmount.Name = "lblSkeletonAmount";
            this.lblSkeletonAmount.Size = new System.Drawing.Size(217, 18);
            this.lblSkeletonAmount.TabIndex = 2;
            this.lblSkeletonAmount.Text = "Population: 0 SPS: 0";
            this.lblSkeletonAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSkeletonCost
            // 
            this.lblSkeletonCost.Enabled = false;
            this.lblSkeletonCost.ForeColor = System.Drawing.Color.White;
            this.lblSkeletonCost.Location = new System.Drawing.Point(72, 3);
            this.lblSkeletonCost.Name = "lblSkeletonCost";
            this.lblSkeletonCost.Size = new System.Drawing.Size(217, 18);
            this.lblSkeletonCost.TabIndex = 1;
            this.lblSkeletonCost.Text = "500 Souls";
            this.lblSkeletonCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxSkeleton
            // 
            this.pbxSkeleton.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxSkeleton.Image = ((System.Drawing.Image)(resources.GetObject("pbxSkeleton.Image")));
            this.pbxSkeleton.Location = new System.Drawing.Point(3, 2);
            this.pbxSkeleton.Name = "pbxSkeleton";
            this.pbxSkeleton.Size = new System.Drawing.Size(64, 71);
            this.pbxSkeleton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxSkeleton.TabIndex = 0;
            this.pbxSkeleton.TabStop = false;
            // 
            // pnlVampire
            // 
            this.pnlVampire.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlVampire.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlVampire.Controls.Add(this.btnVampire);
            this.pnlVampire.Controls.Add(this.lblVampireDescription);
            this.pnlVampire.Controls.Add(this.lblVampireAmount);
            this.pnlVampire.Controls.Add(this.lblVampireCost);
            this.pnlVampire.Controls.Add(this.pbxVampire);
            this.pnlVampire.Enabled = false;
            this.pnlVampire.Location = new System.Drawing.Point(3, 255);
            this.pnlVampire.Name = "pnlVampire";
            this.pnlVampire.Size = new System.Drawing.Size(290, 78);
            this.pnlVampire.TabIndex = 9;
            this.pnlVampire.Visible = false;
            // 
            // btnVampire
            // 
            this.btnVampire.BackColor = System.Drawing.Color.Transparent;
            this.btnVampire.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnVampire.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnVampire.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVampire.ForeColor = System.Drawing.Color.Transparent;
            this.btnVampire.Location = new System.Drawing.Point(-1, -1);
            this.btnVampire.Name = "btnVampire";
            this.btnVampire.Size = new System.Drawing.Size(290, 78);
            this.btnVampire.TabIndex = 32;
            this.btnVampire.UseVisualStyleBackColor = false;
            this.btnVampire.Click += new System.EventHandler(this.btnVampire_Click);
            // 
            // lblVampireDescription
            // 
            this.lblVampireDescription.Enabled = false;
            this.lblVampireDescription.ForeColor = System.Drawing.Color.White;
            this.lblVampireDescription.Location = new System.Drawing.Point(72, 39);
            this.lblVampireDescription.Name = "lblVampireDescription";
            this.lblVampireDescription.Size = new System.Drawing.Size(217, 28);
            this.lblVampireDescription.TabIndex = 3;
            this.lblVampireDescription.Text = "Vampire";
            this.lblVampireDescription.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVampireAmount
            // 
            this.lblVampireAmount.Enabled = false;
            this.lblVampireAmount.ForeColor = System.Drawing.Color.White;
            this.lblVampireAmount.Location = new System.Drawing.Point(72, 21);
            this.lblVampireAmount.Name = "lblVampireAmount";
            this.lblVampireAmount.Size = new System.Drawing.Size(217, 18);
            this.lblVampireAmount.TabIndex = 2;
            this.lblVampireAmount.Text = "Population: 0 SPS: 0";
            this.lblVampireAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblVampireCost
            // 
            this.lblVampireCost.Enabled = false;
            this.lblVampireCost.ForeColor = System.Drawing.Color.White;
            this.lblVampireCost.Location = new System.Drawing.Point(72, 3);
            this.lblVampireCost.Name = "lblVampireCost";
            this.lblVampireCost.Size = new System.Drawing.Size(217, 18);
            this.lblVampireCost.TabIndex = 1;
            this.lblVampireCost.Text = "3,000 Souls";
            this.lblVampireCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxVampire
            // 
            this.pbxVampire.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxVampire.Image = ((System.Drawing.Image)(resources.GetObject("pbxVampire.Image")));
            this.pbxVampire.Location = new System.Drawing.Point(3, 2);
            this.pbxVampire.Name = "pbxVampire";
            this.pbxVampire.Size = new System.Drawing.Size(64, 71);
            this.pbxVampire.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxVampire.TabIndex = 0;
            this.pbxVampire.TabStop = false;
            // 
            // pnlWraith
            // 
            this.pnlWraith.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlWraith.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWraith.Controls.Add(this.btnWraith);
            this.pnlWraith.Controls.Add(this.lblWraithDesc);
            this.pnlWraith.Controls.Add(this.lblWraithAmount);
            this.pnlWraith.Controls.Add(this.lblWraithCost);
            this.pnlWraith.Controls.Add(this.pbxWraith);
            this.pnlWraith.Enabled = false;
            this.pnlWraith.Location = new System.Drawing.Point(3, 339);
            this.pnlWraith.Name = "pnlWraith";
            this.pnlWraith.Size = new System.Drawing.Size(290, 78);
            this.pnlWraith.TabIndex = 10;
            this.pnlWraith.Visible = false;
            // 
            // btnWraith
            // 
            this.btnWraith.BackColor = System.Drawing.Color.Transparent;
            this.btnWraith.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnWraith.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnWraith.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWraith.ForeColor = System.Drawing.Color.Transparent;
            this.btnWraith.Location = new System.Drawing.Point(-1, -1);
            this.btnWraith.Name = "btnWraith";
            this.btnWraith.Size = new System.Drawing.Size(290, 78);
            this.btnWraith.TabIndex = 32;
            this.btnWraith.UseVisualStyleBackColor = false;
            this.btnWraith.Click += new System.EventHandler(this.btnWraith_Click);
            // 
            // lblWraithDesc
            // 
            this.lblWraithDesc.Enabled = false;
            this.lblWraithDesc.ForeColor = System.Drawing.Color.White;
            this.lblWraithDesc.Location = new System.Drawing.Point(72, 39);
            this.lblWraithDesc.Name = "lblWraithDesc";
            this.lblWraithDesc.Size = new System.Drawing.Size(217, 28);
            this.lblWraithDesc.TabIndex = 3;
            this.lblWraithDesc.Text = "Wraith";
            this.lblWraithDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWraithAmount
            // 
            this.lblWraithAmount.Enabled = false;
            this.lblWraithAmount.ForeColor = System.Drawing.Color.White;
            this.lblWraithAmount.Location = new System.Drawing.Point(72, 21);
            this.lblWraithAmount.Name = "lblWraithAmount";
            this.lblWraithAmount.Size = new System.Drawing.Size(217, 18);
            this.lblWraithAmount.TabIndex = 2;
            this.lblWraithAmount.Text = "Population: 0 SPS: 0";
            this.lblWraithAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWraithCost
            // 
            this.lblWraithCost.Enabled = false;
            this.lblWraithCost.ForeColor = System.Drawing.Color.White;
            this.lblWraithCost.Location = new System.Drawing.Point(72, 3);
            this.lblWraithCost.Name = "lblWraithCost";
            this.lblWraithCost.Size = new System.Drawing.Size(217, 18);
            this.lblWraithCost.TabIndex = 1;
            this.lblWraithCost.Text = "10,000 Souls";
            this.lblWraithCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxWraith
            // 
            this.pbxWraith.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxWraith.Image = ((System.Drawing.Image)(resources.GetObject("pbxWraith.Image")));
            this.pbxWraith.Location = new System.Drawing.Point(3, 2);
            this.pbxWraith.Name = "pbxWraith";
            this.pbxWraith.Size = new System.Drawing.Size(64, 71);
            this.pbxWraith.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxWraith.TabIndex = 0;
            this.pbxWraith.TabStop = false;
            // 
            // pnlLich
            // 
            this.pnlLich.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlLich.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLich.Controls.Add(this.btnLich);
            this.pnlLich.Controls.Add(this.lblLichDesc);
            this.pnlLich.Controls.Add(this.lblLichAmount);
            this.pnlLich.Controls.Add(this.lblLichCost);
            this.pnlLich.Controls.Add(this.pbxLich);
            this.pnlLich.Enabled = false;
            this.pnlLich.Location = new System.Drawing.Point(3, 423);
            this.pnlLich.Name = "pnlLich";
            this.pnlLich.Size = new System.Drawing.Size(290, 78);
            this.pnlLich.TabIndex = 11;
            this.pnlLich.Visible = false;
            // 
            // btnLich
            // 
            this.btnLich.BackColor = System.Drawing.Color.Transparent;
            this.btnLich.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnLich.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnLich.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLich.ForeColor = System.Drawing.Color.Transparent;
            this.btnLich.Location = new System.Drawing.Point(-1, -1);
            this.btnLich.Name = "btnLich";
            this.btnLich.Size = new System.Drawing.Size(290, 78);
            this.btnLich.TabIndex = 32;
            this.btnLich.UseVisualStyleBackColor = false;
            this.btnLich.Click += new System.EventHandler(this.btnLich_Click);
            // 
            // lblLichDesc
            // 
            this.lblLichDesc.Enabled = false;
            this.lblLichDesc.ForeColor = System.Drawing.Color.White;
            this.lblLichDesc.Location = new System.Drawing.Point(72, 39);
            this.lblLichDesc.Name = "lblLichDesc";
            this.lblLichDesc.Size = new System.Drawing.Size(217, 28);
            this.lblLichDesc.TabIndex = 3;
            this.lblLichDesc.Text = "Lich";
            this.lblLichDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLichAmount
            // 
            this.lblLichAmount.Enabled = false;
            this.lblLichAmount.ForeColor = System.Drawing.Color.White;
            this.lblLichAmount.Location = new System.Drawing.Point(72, 21);
            this.lblLichAmount.Name = "lblLichAmount";
            this.lblLichAmount.Size = new System.Drawing.Size(217, 18);
            this.lblLichAmount.TabIndex = 2;
            this.lblLichAmount.Text = "Population: 0 SPS: 0";
            this.lblLichAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLichCost
            // 
            this.lblLichCost.Enabled = false;
            this.lblLichCost.ForeColor = System.Drawing.Color.White;
            this.lblLichCost.Location = new System.Drawing.Point(72, 3);
            this.lblLichCost.Name = "lblLichCost";
            this.lblLichCost.Size = new System.Drawing.Size(217, 18);
            this.lblLichCost.TabIndex = 1;
            this.lblLichCost.Text = "40,000 Souls";
            this.lblLichCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxLich
            // 
            this.pbxLich.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxLich.Location = new System.Drawing.Point(3, 2);
            this.pbxLich.Name = "pbxLich";
            this.pbxLich.Size = new System.Drawing.Size(64, 71);
            this.pbxLich.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxLich.TabIndex = 0;
            this.pbxLich.TabStop = false;
            // 
            // pnlDeathKnight
            // 
            this.pnlDeathKnight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlDeathKnight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDeathKnight.Controls.Add(this.btnDeathKnight);
            this.pnlDeathKnight.Controls.Add(this.lblDeathKnightDesc);
            this.pnlDeathKnight.Controls.Add(this.lblDeathKnightAmount);
            this.pnlDeathKnight.Controls.Add(this.lblDeathKnightCost);
            this.pnlDeathKnight.Controls.Add(this.pbxDeathKnight);
            this.pnlDeathKnight.Enabled = false;
            this.pnlDeathKnight.Location = new System.Drawing.Point(3, 507);
            this.pnlDeathKnight.Name = "pnlDeathKnight";
            this.pnlDeathKnight.Size = new System.Drawing.Size(290, 78);
            this.pnlDeathKnight.TabIndex = 12;
            this.pnlDeathKnight.Visible = false;
            // 
            // btnDeathKnight
            // 
            this.btnDeathKnight.BackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnight.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnight.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDeathKnight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeathKnight.ForeColor = System.Drawing.Color.Transparent;
            this.btnDeathKnight.Location = new System.Drawing.Point(-1, -1);
            this.btnDeathKnight.Name = "btnDeathKnight";
            this.btnDeathKnight.Size = new System.Drawing.Size(290, 78);
            this.btnDeathKnight.TabIndex = 32;
            this.btnDeathKnight.UseVisualStyleBackColor = false;
            this.btnDeathKnight.Click += new System.EventHandler(this.btnDeathKnight_Click);
            // 
            // lblDeathKnightDesc
            // 
            this.lblDeathKnightDesc.Enabled = false;
            this.lblDeathKnightDesc.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightDesc.Location = new System.Drawing.Point(72, 39);
            this.lblDeathKnightDesc.Name = "lblDeathKnightDesc";
            this.lblDeathKnightDesc.Size = new System.Drawing.Size(217, 28);
            this.lblDeathKnightDesc.TabIndex = 3;
            this.lblDeathKnightDesc.Text = "DeathKnight";
            this.lblDeathKnightDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDeathKnightAmount
            // 
            this.lblDeathKnightAmount.Enabled = false;
            this.lblDeathKnightAmount.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightAmount.Location = new System.Drawing.Point(72, 21);
            this.lblDeathKnightAmount.Name = "lblDeathKnightAmount";
            this.lblDeathKnightAmount.Size = new System.Drawing.Size(217, 18);
            this.lblDeathKnightAmount.TabIndex = 2;
            this.lblDeathKnightAmount.Text = "Population: 0 SPS: 0";
            this.lblDeathKnightAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDeathKnightCost
            // 
            this.lblDeathKnightCost.Enabled = false;
            this.lblDeathKnightCost.ForeColor = System.Drawing.Color.White;
            this.lblDeathKnightCost.Location = new System.Drawing.Point(72, 3);
            this.lblDeathKnightCost.Name = "lblDeathKnightCost";
            this.lblDeathKnightCost.Size = new System.Drawing.Size(217, 18);
            this.lblDeathKnightCost.TabIndex = 1;
            this.lblDeathKnightCost.Text = "200,000 Souls";
            this.lblDeathKnightCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxDeathKnight
            // 
            this.pbxDeathKnight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxDeathKnight.Location = new System.Drawing.Point(3, 2);
            this.pbxDeathKnight.Name = "pbxDeathKnight";
            this.pbxDeathKnight.Size = new System.Drawing.Size(64, 71);
            this.pbxDeathKnight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxDeathKnight.TabIndex = 0;
            this.pbxDeathKnight.TabStop = false;
            // 
            // pnlDragon
            // 
            this.pnlDragon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlDragon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDragon.Controls.Add(this.btnDragon);
            this.pnlDragon.Controls.Add(this.lblDragonDesc);
            this.pnlDragon.Controls.Add(this.lblDragonAmount);
            this.pnlDragon.Controls.Add(this.lblDragonCost);
            this.pnlDragon.Controls.Add(this.pbxDragon);
            this.pnlDragon.Enabled = false;
            this.pnlDragon.Location = new System.Drawing.Point(3, 591);
            this.pnlDragon.Name = "pnlDragon";
            this.pnlDragon.Size = new System.Drawing.Size(290, 78);
            this.pnlDragon.TabIndex = 13;
            this.pnlDragon.Visible = false;
            // 
            // btnDragon
            // 
            this.btnDragon.BackColor = System.Drawing.Color.Transparent;
            this.btnDragon.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDragon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDragon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDragon.ForeColor = System.Drawing.Color.Transparent;
            this.btnDragon.Location = new System.Drawing.Point(-1, -1);
            this.btnDragon.Name = "btnDragon";
            this.btnDragon.Size = new System.Drawing.Size(290, 78);
            this.btnDragon.TabIndex = 32;
            this.btnDragon.UseVisualStyleBackColor = false;
            this.btnDragon.Click += new System.EventHandler(this.btnDragon_Click);
            // 
            // lblDragonDesc
            // 
            this.lblDragonDesc.Enabled = false;
            this.lblDragonDesc.ForeColor = System.Drawing.Color.White;
            this.lblDragonDesc.Location = new System.Drawing.Point(72, 39);
            this.lblDragonDesc.Name = "lblDragonDesc";
            this.lblDragonDesc.Size = new System.Drawing.Size(217, 28);
            this.lblDragonDesc.TabIndex = 3;
            this.lblDragonDesc.Text = "Skeletal Dragon";
            this.lblDragonDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDragonAmount
            // 
            this.lblDragonAmount.Enabled = false;
            this.lblDragonAmount.ForeColor = System.Drawing.Color.White;
            this.lblDragonAmount.Location = new System.Drawing.Point(72, 21);
            this.lblDragonAmount.Name = "lblDragonAmount";
            this.lblDragonAmount.Size = new System.Drawing.Size(217, 18);
            this.lblDragonAmount.TabIndex = 2;
            this.lblDragonAmount.Text = "Population: 0 SPS: 0";
            this.lblDragonAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDragonCost
            // 
            this.lblDragonCost.Enabled = false;
            this.lblDragonCost.ForeColor = System.Drawing.Color.White;
            this.lblDragonCost.Location = new System.Drawing.Point(72, 3);
            this.lblDragonCost.Name = "lblDragonCost";
            this.lblDragonCost.Size = new System.Drawing.Size(217, 18);
            this.lblDragonCost.TabIndex = 1;
            this.lblDragonCost.Text = "1,300,000 Souls";
            this.lblDragonCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxDragon
            // 
            this.pbxDragon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxDragon.Location = new System.Drawing.Point(3, 2);
            this.pbxDragon.Name = "pbxDragon";
            this.pbxDragon.Size = new System.Drawing.Size(64, 71);
            this.pbxDragon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxDragon.TabIndex = 0;
            this.pbxDragon.TabStop = false;
            // 
            // pnlInformation
            // 
            this.pnlInformation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(97)))), ((int)(((byte)(94)))), ((int)(((byte)(164)))));
            this.pnlInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlInformation.Controls.Add(this.btnSave);
            this.pnlInformation.Controls.Add(this.lblReportsRefresh);
            this.pnlInformation.Controls.Add(this.lblStatsPlayTime);
            this.pnlInformation.Controls.Add(this.lblStatsDispPlayTime);
            this.pnlInformation.Controls.Add(this.lblStatsUpgradesPurchased);
            this.pnlInformation.Controls.Add(this.lblStatsDispUpgradesPurchased);
            this.pnlInformation.Controls.Add(this.lblStatsUpgradesUnlocked);
            this.pnlInformation.Controls.Add(this.lblStatsDispUpgradesUnlocked);
            this.pnlInformation.Controls.Add(this.lblStatsTotalSoulsGained);
            this.pnlInformation.Controls.Add(this.lblStatsDispSoulsTotal);
            this.pnlInformation.Controls.Add(this.lblStatsSoulsSpent);
            this.pnlInformation.Controls.Add(this.lblStatsDispSoulsSpent);
            this.pnlInformation.Controls.Add(this.lblStatsClickCount);
            this.pnlInformation.Controls.Add(this.lblStatsDispClickCount);
            this.pnlInformation.Controls.Add(this.lblStatsSPC);
            this.pnlInformation.Controls.Add(this.lblStatsSPS);
            this.pnlInformation.Controls.Add(this.lblStatsSouls);
            this.pnlInformation.Controls.Add(this.lblStatsDispSPC);
            this.pnlInformation.Controls.Add(this.lblStatsDispSPS);
            this.pnlInformation.Controls.Add(this.lblStatsDispSouls);
            this.pnlInformation.Controls.Add(this.lblStatistics);
            this.pnlInformation.Controls.Add(this.btnSPSOverTimeGraph);
            this.pnlInformation.Controls.Add(this.btnClicksOverTimeGraph);
            this.pnlInformation.Controls.Add(this.btnStatistics);
            this.pnlInformation.Location = new System.Drawing.Point(491, 65);
            this.pnlInformation.Name = "pnlInformation";
            this.pnlInformation.Size = new System.Drawing.Size(181, 652);
            this.pnlInformation.TabIndex = 3;
            // 
            // lblReportsRefresh
            // 
            this.lblReportsRefresh.AutoSize = true;
            this.lblReportsRefresh.Location = new System.Drawing.Point(14, 437);
            this.lblReportsRefresh.Name = "lblReportsRefresh";
            this.lblReportsRefresh.Size = new System.Drawing.Size(146, 13);
            this.lblReportsRefresh.TabIndex = 23;
            this.lblReportsRefresh.Text = "*Reports refresh every minute";
            // 
            // lblStatsPlayTime
            // 
            this.lblStatsPlayTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsPlayTime.Location = new System.Drawing.Point(5, 324);
            this.lblStatsPlayTime.Name = "lblStatsPlayTime";
            this.lblStatsPlayTime.Size = new System.Drawing.Size(163, 15);
            this.lblStatsPlayTime.TabIndex = 22;
            this.lblStatsPlayTime.Text = "0";
            // 
            // lblStatsDispPlayTime
            // 
            this.lblStatsDispPlayTime.AutoSize = true;
            this.lblStatsDispPlayTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsDispPlayTime.Location = new System.Drawing.Point(5, 306);
            this.lblStatsDispPlayTime.Name = "lblStatsDispPlayTime";
            this.lblStatsDispPlayTime.Size = new System.Drawing.Size(64, 15);
            this.lblStatsDispPlayTime.TabIndex = 21;
            this.lblStatsDispPlayTime.Text = "Play Time:";
            // 
            // lblStatsUpgradesPurchased
            // 
            this.lblStatsUpgradesPurchased.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsUpgradesPurchased.Location = new System.Drawing.Point(5, 289);
            this.lblStatsUpgradesPurchased.Name = "lblStatsUpgradesPurchased";
            this.lblStatsUpgradesPurchased.Size = new System.Drawing.Size(163, 15);
            this.lblStatsUpgradesPurchased.TabIndex = 20;
            this.lblStatsUpgradesPurchased.Text = "0";
            // 
            // lblStatsDispUpgradesPurchased
            // 
            this.lblStatsDispUpgradesPurchased.AutoSize = true;
            this.lblStatsDispUpgradesPurchased.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsDispUpgradesPurchased.Location = new System.Drawing.Point(5, 271);
            this.lblStatsDispUpgradesPurchased.Name = "lblStatsDispUpgradesPurchased";
            this.lblStatsDispUpgradesPurchased.Size = new System.Drawing.Size(123, 15);
            this.lblStatsDispUpgradesPurchased.TabIndex = 19;
            this.lblStatsDispUpgradesPurchased.Text = "Upgrades Purchased";
            // 
            // lblStatsUpgradesUnlocked
            // 
            this.lblStatsUpgradesUnlocked.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsUpgradesUnlocked.Location = new System.Drawing.Point(5, 256);
            this.lblStatsUpgradesUnlocked.Name = "lblStatsUpgradesUnlocked";
            this.lblStatsUpgradesUnlocked.Size = new System.Drawing.Size(163, 15);
            this.lblStatsUpgradesUnlocked.TabIndex = 18;
            this.lblStatsUpgradesUnlocked.Text = "0";
            // 
            // lblStatsDispUpgradesUnlocked
            // 
            this.lblStatsDispUpgradesUnlocked.AutoSize = true;
            this.lblStatsDispUpgradesUnlocked.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsDispUpgradesUnlocked.Location = new System.Drawing.Point(5, 238);
            this.lblStatsDispUpgradesUnlocked.Name = "lblStatsDispUpgradesUnlocked";
            this.lblStatsDispUpgradesUnlocked.Size = new System.Drawing.Size(119, 15);
            this.lblStatsDispUpgradesUnlocked.TabIndex = 17;
            this.lblStatsDispUpgradesUnlocked.Text = "Upgrades Unlocked:";
            // 
            // lblStatsTotalSoulsGained
            // 
            this.lblStatsTotalSoulsGained.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsTotalSoulsGained.Location = new System.Drawing.Point(5, 222);
            this.lblStatsTotalSoulsGained.Name = "lblStatsTotalSoulsGained";
            this.lblStatsTotalSoulsGained.Size = new System.Drawing.Size(163, 15);
            this.lblStatsTotalSoulsGained.TabIndex = 16;
            this.lblStatsTotalSoulsGained.Text = "0";
            // 
            // lblStatsDispSoulsTotal
            // 
            this.lblStatsDispSoulsTotal.AutoSize = true;
            this.lblStatsDispSoulsTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsDispSoulsTotal.Location = new System.Drawing.Point(5, 203);
            this.lblStatsDispSoulsTotal.Name = "lblStatsDispSoulsTotal";
            this.lblStatsDispSoulsTotal.Size = new System.Drawing.Size(114, 15);
            this.lblStatsDispSoulsTotal.TabIndex = 15;
            this.lblStatsDispSoulsTotal.Text = "Total Souls Gained:";
            // 
            // lblStatsSoulsSpent
            // 
            this.lblStatsSoulsSpent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsSoulsSpent.Location = new System.Drawing.Point(5, 184);
            this.lblStatsSoulsSpent.Name = "lblStatsSoulsSpent";
            this.lblStatsSoulsSpent.Size = new System.Drawing.Size(163, 15);
            this.lblStatsSoulsSpent.TabIndex = 14;
            this.lblStatsSoulsSpent.Text = "0";
            // 
            // lblStatsDispSoulsSpent
            // 
            this.lblStatsDispSoulsSpent.AutoSize = true;
            this.lblStatsDispSoulsSpent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsDispSoulsSpent.Location = new System.Drawing.Point(5, 169);
            this.lblStatsDispSoulsSpent.Name = "lblStatsDispSoulsSpent";
            this.lblStatsDispSoulsSpent.Size = new System.Drawing.Size(76, 15);
            this.lblStatsDispSoulsSpent.TabIndex = 13;
            this.lblStatsDispSoulsSpent.Text = "Souls Spent:";
            // 
            // lblStatsClickCount
            // 
            this.lblStatsClickCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsClickCount.Location = new System.Drawing.Point(5, 149);
            this.lblStatsClickCount.Name = "lblStatsClickCount";
            this.lblStatsClickCount.Size = new System.Drawing.Size(163, 15);
            this.lblStatsClickCount.TabIndex = 12;
            this.lblStatsClickCount.Text = "0";
            // 
            // lblStatsDispClickCount
            // 
            this.lblStatsDispClickCount.AutoSize = true;
            this.lblStatsDispClickCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsDispClickCount.Location = new System.Drawing.Point(5, 134);
            this.lblStatsDispClickCount.Name = "lblStatsDispClickCount";
            this.lblStatsDispClickCount.Size = new System.Drawing.Size(71, 15);
            this.lblStatsDispClickCount.TabIndex = 11;
            this.lblStatsDispClickCount.Text = "Click Count:";
            // 
            // lblStatsSPC
            // 
            this.lblStatsSPC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsSPC.Location = new System.Drawing.Point(5, 118);
            this.lblStatsSPC.Name = "lblStatsSPC";
            this.lblStatsSPC.Size = new System.Drawing.Size(163, 15);
            this.lblStatsSPC.TabIndex = 10;
            this.lblStatsSPC.Text = "0";
            // 
            // lblStatsSPS
            // 
            this.lblStatsSPS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsSPS.Location = new System.Drawing.Point(5, 88);
            this.lblStatsSPS.Name = "lblStatsSPS";
            this.lblStatsSPS.Size = new System.Drawing.Size(163, 15);
            this.lblStatsSPS.TabIndex = 9;
            this.lblStatsSPS.Text = "0";
            // 
            // lblStatsSouls
            // 
            this.lblStatsSouls.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsSouls.Location = new System.Drawing.Point(5, 58);
            this.lblStatsSouls.Name = "lblStatsSouls";
            this.lblStatsSouls.Size = new System.Drawing.Size(163, 15);
            this.lblStatsSouls.TabIndex = 8;
            this.lblStatsSouls.Text = "0";
            // 
            // lblStatsDispSPC
            // 
            this.lblStatsDispSPC.AutoSize = true;
            this.lblStatsDispSPC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsDispSPC.Location = new System.Drawing.Point(5, 103);
            this.lblStatsDispSPC.Name = "lblStatsDispSPC";
            this.lblStatsDispSPC.Size = new System.Drawing.Size(129, 15);
            this.lblStatsDispSPC.TabIndex = 7;
            this.lblStatsDispSPC.Text = "Souls per Click (SPC): ";
            // 
            // lblStatsDispSPS
            // 
            this.lblStatsDispSPS.AutoSize = true;
            this.lblStatsDispSPS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsDispSPS.Location = new System.Drawing.Point(5, 73);
            this.lblStatsDispSPS.Name = "lblStatsDispSPS";
            this.lblStatsDispSPS.Size = new System.Drawing.Size(145, 15);
            this.lblStatsDispSPS.TabIndex = 6;
            this.lblStatsDispSPS.Text = "Souls per Second (SPS): ";
            // 
            // lblStatsDispSouls
            // 
            this.lblStatsDispSouls.AutoSize = true;
            this.lblStatsDispSouls.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.5F);
            this.lblStatsDispSouls.Location = new System.Drawing.Point(5, 43);
            this.lblStatsDispSouls.Name = "lblStatsDispSouls";
            this.lblStatsDispSouls.Size = new System.Drawing.Size(44, 15);
            this.lblStatsDispSouls.TabIndex = 5;
            this.lblStatsDispSouls.Text = "Souls: ";
            // 
            // lblStatistics
            // 
            this.lblStatistics.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.lblStatistics.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.5F);
            this.lblStatistics.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblStatistics.Location = new System.Drawing.Point(3, 3);
            this.lblStatistics.Name = "lblStatistics";
            this.lblStatistics.Size = new System.Drawing.Size(171, 36);
            this.lblStatistics.TabIndex = 4;
            this.lblStatistics.Text = "Statistics:";
            this.lblStatistics.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSPSOverTimeGraph
            // 
            this.btnSPSOverTimeGraph.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.btnSPSOverTimeGraph.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSPSOverTimeGraph.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnSPSOverTimeGraph.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSPSOverTimeGraph.Location = new System.Drawing.Point(3, 560);
            this.btnSPSOverTimeGraph.Name = "btnSPSOverTimeGraph";
            this.btnSPSOverTimeGraph.Size = new System.Drawing.Size(171, 48);
            this.btnSPSOverTimeGraph.TabIndex = 2;
            this.btnSPSOverTimeGraph.Text = "View amount of monsters purchased graph";
            this.btnSPSOverTimeGraph.UseVisualStyleBackColor = false;
            this.btnSPSOverTimeGraph.Click += new System.EventHandler(this.btnSPSOverTimeGraph_Click);
            // 
            // btnClicksOverTimeGraph
            // 
            this.btnClicksOverTimeGraph.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.btnClicksOverTimeGraph.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClicksOverTimeGraph.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnClicksOverTimeGraph.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnClicksOverTimeGraph.Location = new System.Drawing.Point(3, 506);
            this.btnClicksOverTimeGraph.Name = "btnClicksOverTimeGraph";
            this.btnClicksOverTimeGraph.Size = new System.Drawing.Size(171, 48);
            this.btnClicksOverTimeGraph.TabIndex = 1;
            this.btnClicksOverTimeGraph.Text = "View souls spent relative to souls available graph";
            this.btnClicksOverTimeGraph.UseVisualStyleBackColor = false;
            this.btnClicksOverTimeGraph.Click += new System.EventHandler(this.btnClicksOverTimeGraph_Click);
            // 
            // btnStatistics
            // 
            this.btnStatistics.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.btnStatistics.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStatistics.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnStatistics.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnStatistics.Location = new System.Drawing.Point(3, 452);
            this.btnStatistics.Name = "btnStatistics";
            this.btnStatistics.Size = new System.Drawing.Size(171, 48);
            this.btnStatistics.TabIndex = 0;
            this.btnStatistics.Text = "View Statistics";
            this.btnStatistics.UseVisualStyleBackColor = false;
            this.btnStatistics.Click += new System.EventHandler(this.btnStatistics_Click);
            // 
            // pbxClickThis
            // 
            this.pbxClickThis.BackColor = System.Drawing.Color.Transparent;
            this.pbxClickThis.Location = new System.Drawing.Point(12, 150);
            this.pbxClickThis.Name = "pbxClickThis";
            this.pbxClickThis.Size = new System.Drawing.Size(480, 416);
            this.pbxClickThis.TabIndex = 4;
            this.pbxClickThis.TabStop = false;
            this.pbxClickThis.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbxClickThis_MouseClick);
            // 
            // lblSouls
            // 
            this.lblSouls.BackColor = System.Drawing.Color.Transparent;
            this.lblSouls.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lblSouls.Location = new System.Drawing.Point(12, 71);
            this.lblSouls.Name = "lblSouls";
            this.lblSouls.Size = new System.Drawing.Size(471, 23);
            this.lblSouls.TabIndex = 5;
            this.lblSouls.Text = "Souls: 0";
            this.lblSouls.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSPS
            // 
            this.lblSPS.BackColor = System.Drawing.Color.Transparent;
            this.lblSPS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblSPS.Location = new System.Drawing.Point(12, 96);
            this.lblSPS.Name = "lblSPS";
            this.lblSPS.Size = new System.Drawing.Size(471, 25);
            this.lblSPS.TabIndex = 6;
            this.lblSPS.Text = "SPS: 0";
            this.lblSPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxBackground
            // 
            this.pbxBackground.Image = ((System.Drawing.Image)(resources.GetObject("pbxBackground.Image")));
            this.pbxBackground.Location = new System.Drawing.Point(10, 65);
            this.pbxBackground.Name = "pbxBackground";
            this.pbxBackground.Size = new System.Drawing.Size(671, 652);
            this.pbxBackground.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxBackground.TabIndex = 7;
            this.pbxBackground.TabStop = false;
            // 
            // timerStats
            // 
            this.timerStats.Interval = 5000;
            this.timerStats.Tick += new System.EventHandler(this.timerStats_Tick);
            // 
            // timerSave
            // 
            this.timerSave.Interval = 60000;
            this.timerSave.Tick += new System.EventHandler(this.timerSave_Tick);
            // 
            // timerSPS
            // 
            this.timerSPS.Interval = 1000;
            this.timerSPS.Tick += new System.EventHandler(this.timerSPS_Tick);
            // 
            // timerCheckAffordability
            // 
            this.timerCheckAffordability.Tick += new System.EventHandler(this.timerCheckAffordability_Tick);
            // 
            // timerSoulieMan
            // 
            this.timerSoulieMan.Interval = 50;
            this.timerSoulieMan.Tick += new System.EventHandler(this.timerSoulieMan_Tick);
            // 
            // pbxSoulieMan
            // 
            this.pbxSoulieMan.BackColor = System.Drawing.Color.Transparent;
            this.pbxSoulieMan.Location = new System.Drawing.Point(17, 577);
            this.pbxSoulieMan.Name = "pbxSoulieMan";
            this.pbxSoulieMan.Size = new System.Drawing.Size(32, 128);
            this.pbxSoulieMan.TabIndex = 8;
            this.pbxSoulieMan.TabStop = false;
            this.pbxSoulieMan.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnSave.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSave.Location = new System.Drawing.Point(41, 614);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(93, 31);
            this.btnSave.TabIndex = 24;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(200)))));
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.pbxProfilePic);
            this.Controls.Add(this.lblSPS);
            this.Controls.Add(this.lblSouls);
            this.Controls.Add(this.pnlTitle);
            this.Controls.Add(this.fpnlUpgrades);
            this.Controls.Add(this.fpnlAutoClickers);
            this.Controls.Add(this.pnlInformation);
            this.Controls.Add(this.pbxSoulieMan);
            this.Controls.Add(this.pbxClickThis);
            this.Controls.Add(this.pbxBackground);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Necroclicker (0 Souls)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.pnlTitle.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxProfilePic)).EndInit();
            this.fpnlUpgrades.ResumeLayout(false);
            this.pnlDragonUpgradeArmor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDragonUpgradeArmor)).EndInit();
            this.pnlDragonUpgradeFrostBreath.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDragonUpgradeFrostBreath)).EndInit();
            this.pnlDragonUpgradeRider.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDragonUpgradeRider)).EndInit();
            this.pnlDeathKnightUpgradeHorses.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeathKnightUpgradeHorses)).EndInit();
            this.pnlDeathKnightUpgradeRunedArmor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeathKnightUpgradeRunedArmor)).EndInit();
            this.pnlDeathKnightUpgradeSteel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeathKnightUpgradeSteel)).EndInit();
            this.pnlLichUpgradeScrolls.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxLichUpgradeScrolls)).EndInit();
            this.pnlLichUpgradeSummon.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxLichUpgradeSummon)).EndInit();
            this.pnlLichUpgradeMagic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxLichUpgradeMagic)).EndInit();
            this.pnlWraithUpgradeWyvern.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxWraithUpgradeWyvern)).EndInit();
            this.pnlWraithUpgradeInfernalWeaponry.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxWraithUpgradeInfernalWeaponry)).EndInit();
            this.pnlWraithUpgradeHorse.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxWraithUpgradeHorse)).EndInit();
            this.pnlVampireUpgradeEnchantedWeaponry.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxVampireUpgradeEnchantedWeaponry)).EndInit();
            this.pnlVampireUpgradeBatForm.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxVampireUpgradeBatForm)).EndInit();
            this.pnlVampireUpgradeHealing.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxVampireUpgradeHealing)).EndInit();
            this.pnlSkeletonUpgradeDarksteel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxSkeletonUpgradeDarksteel)).EndInit();
            this.pnlSkeletonUpgradeArmor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxSkeletonUpgradeArmor)).EndInit();
            this.pnlSkeletonUpgradeWeapons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxSkeletonUpgradeWeapons)).EndInit();
            this.pnlGhoulUpgradeArmor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxGhoulUpgradeArmor)).EndInit();
            this.pnlGhoulUpgradeParalysis.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxGhoulUpgradeParalysis)).EndInit();
            this.pnlGhoulFangsUpgrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxGhoulFangsUpgrade)).EndInit();
            this.pnlZombieMutantUpgrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxZombieMutantUpgrade)).EndInit();
            this.pnlZombieDiseasedUpgrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxZombieDiseasedUpgrade)).EndInit();
            this.pnlZombieFastUpgrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxZombieFastUpgrade)).EndInit();
            this.pnlDemonHelperUpgrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDemonHelperUpgrade)).EndInit();
            this.pnlAltarUpgrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxAltarUpgrade)).EndInit();
            this.pnlImpUpgrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxImpUpgrade)).EndInit();
            this.pnlCouldronUpgrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxlCouldronUpgrade)).EndInit();
            this.pnlBookUpgrade.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxBookUpgrade)).EndInit();
            this.fpnlAutoClickers.ResumeLayout(false);
            this.pnlZombie.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxZombie)).EndInit();
            this.pnlGhoul.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxGhoul)).EndInit();
            this.pnlSkeleton.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxSkeleton)).EndInit();
            this.pnlVampire.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxVampire)).EndInit();
            this.pnlWraith.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxWraith)).EndInit();
            this.pnlLich.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxLich)).EndInit();
            this.pnlDeathKnight.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDeathKnight)).EndInit();
            this.pnlDragon.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxDragon)).EndInit();
            this.pnlInformation.ResumeLayout(false);
            this.pnlInformation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClickThis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBackground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSoulieMan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnHighScores;
        private System.Windows.Forms.FlowLayoutPanel fpnlUpgrades;
        private System.Windows.Forms.Panel pnlZombieFastUpgrade;
        private System.Windows.Forms.Label lblZombieFastUpgradeCost;
        private System.Windows.Forms.PictureBox pbxZombieFastUpgrade;
        private System.Windows.Forms.FlowLayoutPanel fpnlAutoClickers;
        private System.Windows.Forms.Panel pnlInformation;
        private System.Windows.Forms.PictureBox pbxClickThis;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.PictureBox pbxProfilePic;
        private System.Windows.Forms.Label lblZombieFastUpgradeDesc;
        private System.Windows.Forms.Label lblZombieFastUpgradeSPS;
        private System.Windows.Forms.Label lblSouls;
        private System.Windows.Forms.Label lblSPS;
        private System.Windows.Forms.Panel pnlBookUpgrade;
        private System.Windows.Forms.Label lblBookUpgradeDesc;
        private System.Windows.Forms.Label lblBookUpgradeSPS;
        private System.Windows.Forms.Label lblBookUpgradeCost;
        private System.Windows.Forms.PictureBox pbxBookUpgrade;
        private System.Windows.Forms.PictureBox pbxBackground;
        private System.Windows.Forms.Panel pnlZombieDiseasedUpgrade;
        private System.Windows.Forms.Label lblZombieDiseasedUpgradeDesc;
        private System.Windows.Forms.Label lblZombieDiseasedUpgradeSPS;
        private System.Windows.Forms.Label lblZombieDiseasedUpgradeCost;
        private System.Windows.Forms.PictureBox pbxZombieDiseasedUpgrade;
        private System.Windows.Forms.Panel pnlCouldronUpgrade;
        private System.Windows.Forms.Label lblCouldronUpgradeDesc;
        private System.Windows.Forms.Label lblCouldronUpgradeSPC;
        private System.Windows.Forms.Label lblCouldronUpgradeCost;
        private System.Windows.Forms.PictureBox pbxlCouldronUpgrade;
        private System.Windows.Forms.Panel pnlZombieMutantUpgrade;
        private System.Windows.Forms.Label lblZombieMutantUpgradeDesc;
        private System.Windows.Forms.Label lblZombieMutantUpgradeSPS;
        private System.Windows.Forms.Label lblZombieMutantUpgradeCost;
        private System.Windows.Forms.PictureBox pbxZombieMutantUpgrade;
        private System.Windows.Forms.Panel pnlAltarUpgrade;
        private System.Windows.Forms.Label lblAltarUpgradeDesc;
        private System.Windows.Forms.Label lblAltarUpgradeSPC;
        private System.Windows.Forms.Label lblAltarUpgradeCost;
        private System.Windows.Forms.PictureBox pbxAltarUpgrade;
        private System.Windows.Forms.Panel pnlImpUpgrade;
        private System.Windows.Forms.Label lblImpUpgradeDesc;
        private System.Windows.Forms.Label lblImpUpgradeSPC;
        private System.Windows.Forms.Label lblImpUpgradeCost;
        private System.Windows.Forms.PictureBox pbxImpUpgrade;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Panel pnlDemonHelperUpgrade;
        private System.Windows.Forms.Label lblDemonHelperUpgradeDesc;
        private System.Windows.Forms.Label lblDemonHelperUpgradeSPC;
        private System.Windows.Forms.Label lblDemonHelperUpgradeCost;
        private System.Windows.Forms.PictureBox pbxDemonHelperUpgrade;
        private System.Windows.Forms.Panel pnlGhoulUpgradeArmor;
        private System.Windows.Forms.Label lblGhoulUpgradeArmorDesc;
        private System.Windows.Forms.Label lblGhoulUpgradeArmorSPS;
        private System.Windows.Forms.Label lblGhoulUpgradeArmorCost;
        private System.Windows.Forms.PictureBox pbxGhoulUpgradeArmor;
        private System.Windows.Forms.Panel pnlGhoulUpgradeParalysis;
        private System.Windows.Forms.Label lblGhoulUpgradeParalysisDesc;
        private System.Windows.Forms.Label lblGhoulUpgradeParalysisSPS;
        private System.Windows.Forms.Label lblGhoulUpgradeParalysisCost;
        private System.Windows.Forms.PictureBox pbxGhoulUpgradeParalysis;
        private System.Windows.Forms.Panel pnlGhoulFangsUpgrade;
        private System.Windows.Forms.Label lblGhoulFangsUpgradeDesc;
        private System.Windows.Forms.Label lblGhoulFangsUpgradeSPS;
        private System.Windows.Forms.Label lblGhoulFangsUpgradeCost;
        private System.Windows.Forms.PictureBox pbxGhoulFangsUpgrade;
        private System.Windows.Forms.Panel pnlSkeletonUpgradeWeapons;
        private System.Windows.Forms.Label lblSkeletonUpgradeWeaponsDesc;
        private System.Windows.Forms.Label lblSkeletonUpgradeWeaponsSPS;
        private System.Windows.Forms.Label lblSkeletonUpgradeWeaponsCost;
        private System.Windows.Forms.PictureBox pbxSkeletonUpgradeWeapons;
        private System.Windows.Forms.Panel pnlSkeletonUpgradeArmor;
        private System.Windows.Forms.Label lblSkeletonUpgradeArmorDesc;
        private System.Windows.Forms.Label lblSkeletonUpgradeArmorSPS;
        private System.Windows.Forms.Label lblSkeletonUpgradeArmorCost;
        private System.Windows.Forms.PictureBox pbxSkeletonUpgradeArmor;
        private System.Windows.Forms.Panel pnlSkeletonUpgradeDarksteel;
        private System.Windows.Forms.Label lblSkeletonUpgradeDarksteelDesc;
        private System.Windows.Forms.Label lblSkeletonUpgradeDarksteelSPS;
        private System.Windows.Forms.Label lblSkeletonUpgradeDarksteelCost;
        private System.Windows.Forms.PictureBox pbxSkeletonUpgradeDarksteel;
        private System.Windows.Forms.Panel pnlVampireUpgradeEnchantedWeaponry;
        private System.Windows.Forms.Label lblVampireUpgradeEnchantedWeaponryDesc;
        private System.Windows.Forms.Label lblVampireUpgradeEnchantedWeaponrySPS;
        private System.Windows.Forms.Label lblVampireUpgradeEnchantedWeaponryCost;
        private System.Windows.Forms.PictureBox pbxVampireUpgradeEnchantedWeaponry;
        private System.Windows.Forms.Panel pnlVampireUpgradeBatForm;
        private System.Windows.Forms.Label lblVampireUpgradeBatFormDesc;
        private System.Windows.Forms.Label lblVampireUpgradeBatFormSPS;
        private System.Windows.Forms.Label lblVampireUpgradeBatFormCost;
        private System.Windows.Forms.PictureBox pbxVampireUpgradeBatForm;
        private System.Windows.Forms.Panel pnlVampireUpgradeHealing;
        private System.Windows.Forms.Label lblVampireUpgradeHealingDesc;
        private System.Windows.Forms.Label lblVampireUpgradeHealingSPS;
        private System.Windows.Forms.Label lblVampireUpgradeHealingCost;
        private System.Windows.Forms.PictureBox pbxVampireUpgradeHealing;
        private System.Windows.Forms.Panel pnlZombie;
        private System.Windows.Forms.Label lblZombieDesc;
        private System.Windows.Forms.Label lblZombieAmount;
        private System.Windows.Forms.Label lblZombieCost;
        private System.Windows.Forms.PictureBox pbxZombie;
        private System.Windows.Forms.Panel pnlWraith;
        private System.Windows.Forms.Label lblWraithDesc;
        private System.Windows.Forms.Label lblWraithAmount;
        private System.Windows.Forms.Label lblWraithCost;
        private System.Windows.Forms.PictureBox pbxWraith;
        private System.Windows.Forms.Panel pnlVampire;
        private System.Windows.Forms.Label lblVampireDescription;
        private System.Windows.Forms.Label lblVampireAmount;
        private System.Windows.Forms.Label lblVampireCost;
        private System.Windows.Forms.PictureBox pbxVampire;
        private System.Windows.Forms.Panel pnlSkeleton;
        private System.Windows.Forms.Label lblSkeletonDesc;
        private System.Windows.Forms.Label lblSkeletonAmount;
        private System.Windows.Forms.Label lblSkeletonCost;
        private System.Windows.Forms.PictureBox pbxSkeleton;
        private System.Windows.Forms.Panel pnlGhoul;
        private System.Windows.Forms.Label lblGhoulDesc;
        private System.Windows.Forms.Label lblGhoulAmount;
        private System.Windows.Forms.Label lblGhoulCost;
        private System.Windows.Forms.PictureBox pbxGhoul;
        private System.Windows.Forms.Button btnSPSOverTimeGraph;
        private System.Windows.Forms.Button btnClicksOverTimeGraph;
        private System.Windows.Forms.Button btnStatistics;
        private System.Windows.Forms.Button btnAdminButton;
        private System.Windows.Forms.Panel pnlLichUpgradeScrolls;
        private System.Windows.Forms.Label lblLichUpgradeScrollsDesc;
        private System.Windows.Forms.Label lblLichUpgradeScrollsSPS;
        private System.Windows.Forms.Label lblLichUpgradeScrollsCost;
        private System.Windows.Forms.PictureBox pbxLichUpgradeScrolls;
        private System.Windows.Forms.Panel pnlLichUpgradeSummon;
        private System.Windows.Forms.Label lblLichUpgradeSummonDesc;
        private System.Windows.Forms.Label lblLichUpgradeSummonSPS;
        private System.Windows.Forms.Label lblLichUpgradeSummonCost;
        private System.Windows.Forms.PictureBox pbxLichUpgradeSummon;
        private System.Windows.Forms.Panel pnlLichUpgradeMagic;
        private System.Windows.Forms.Label lblLichUpgradeMagicDesc;
        private System.Windows.Forms.Label lblLichUpgradeMagicSPS;
        private System.Windows.Forms.Label lblLichUpgradeMagicCost;
        private System.Windows.Forms.PictureBox pbxLichUpgradeMagic;
        private System.Windows.Forms.Panel pnlWraithUpgradeWyvern;
        private System.Windows.Forms.Label lblWraithUpgradeWyvernDesc;
        private System.Windows.Forms.Label lblWraithUpgradeWyvernSPS;
        private System.Windows.Forms.Label lblWraithUpgradeWyvernCost;
        private System.Windows.Forms.PictureBox pbxWraithUpgradeWyvern;
        private System.Windows.Forms.Panel pnlWraithUpgradeInfernalWeaponry;
        private System.Windows.Forms.Label lblWraithUpgradeInfernalWeaponryDesc;
        private System.Windows.Forms.Label lblWraithUpgradeInfernalWeaponrySPS;
        private System.Windows.Forms.Label lblWraithUpgradeInfernalWeaponryCost;
        private System.Windows.Forms.PictureBox pbxWraithUpgradeInfernalWeaponry;
        private System.Windows.Forms.Panel pnlWraithUpgradeHorse;
        private System.Windows.Forms.Label lblWraithUpgradeHorseDesc;
        private System.Windows.Forms.Label lblWraithUpgradeHorseSPS;
        private System.Windows.Forms.Label lblWraithUpgradeHorseCost;
        private System.Windows.Forms.PictureBox pbxWraithUpgradeHorse;
        private System.Windows.Forms.Panel pnlDeathKnightUpgradeRunedArmor;
        private System.Windows.Forms.Label lblDeathKnightUpgradeRunedArmorDesc;
        private System.Windows.Forms.Label lblDeathKnightUpgradeRunedArmorSPS;
        private System.Windows.Forms.Label lblDeathKnightUpgradeRunedArmorCost;
        private System.Windows.Forms.PictureBox pbxDeathKnightUpgradeRunedArmor;
        private System.Windows.Forms.Panel pnlDeathKnightUpgradeSteel;
        private System.Windows.Forms.Label lblDeathKnightUpgradeSteelDesc;
        private System.Windows.Forms.Label lblDeathKnightUpgradeSteelSPS;
        private System.Windows.Forms.Label lblDeathKnightUpgradeSteelCost;
        private System.Windows.Forms.PictureBox pbxDeathKnightUpgradeSteel;
        private System.Windows.Forms.Panel pnlDragonUpgradeRider;
        private System.Windows.Forms.Label lblDragonUpgradeRiderDesc;
        private System.Windows.Forms.Label lblDragonUpgradeRiderSPS;
        private System.Windows.Forms.Label lblDragonUpgradeRiderCost;
        private System.Windows.Forms.PictureBox pbxDragonUpgradeRider;
        private System.Windows.Forms.Panel pnlDeathKnightUpgradeHorses;
        private System.Windows.Forms.Label lblDeathKnightUpgradeHorsesDesc;
        private System.Windows.Forms.Label lblDeathKnightUpgradeHorsesSPS;
        private System.Windows.Forms.Label lblDeathKnightUpgradeHorsesCost;
        private System.Windows.Forms.PictureBox pbxDeathKnightUpgradeHorses;
        private System.Windows.Forms.Panel pnlDragonUpgradeFrostBreath;
        private System.Windows.Forms.Label lblDragonUpgradeFrostBreathDesc;
        private System.Windows.Forms.Label lblDragonUpgradeFrostBreathSPS;
        private System.Windows.Forms.Label lblDragonUpgradeFrostBreathCost;
        private System.Windows.Forms.PictureBox pbxDragonUpgradeFrostBreath;
        private System.Windows.Forms.Panel pnlDragonUpgradeArmor;
        private System.Windows.Forms.Label lblDragonUpgradeArmorDesc;
        private System.Windows.Forms.Label lblDragonUpgradeArmorSPS;
        private System.Windows.Forms.Label lblDragonUpgradeArmorCost;
        private System.Windows.Forms.PictureBox pbxDragonUpgradeArmor;
        private System.Windows.Forms.Panel pnlDeathKnight;
        private System.Windows.Forms.Label lblDeathKnightDesc;
        private System.Windows.Forms.Label lblDeathKnightAmount;
        private System.Windows.Forms.Label lblDeathKnightCost;
        private System.Windows.Forms.PictureBox pbxDeathKnight;
        private System.Windows.Forms.Panel pnlLich;
        private System.Windows.Forms.Label lblLichDesc;
        private System.Windows.Forms.Label lblLichAmount;
        private System.Windows.Forms.Label lblLichCost;
        private System.Windows.Forms.PictureBox pbxLich;
        private System.Windows.Forms.Panel pnlDragon;
        private System.Windows.Forms.Label lblDragonDesc;
        private System.Windows.Forms.Label lblDragonAmount;
        private System.Windows.Forms.Label lblDragonCost;
        private System.Windows.Forms.PictureBox pbxDragon;
        private System.Windows.Forms.Timer timerStats;
        private System.Windows.Forms.Label lblStatsPlayTime;
        private System.Windows.Forms.Label lblStatsDispPlayTime;
        private System.Windows.Forms.Label lblStatsUpgradesPurchased;
        private System.Windows.Forms.Label lblStatsDispUpgradesPurchased;
        private System.Windows.Forms.Label lblStatsUpgradesUnlocked;
        private System.Windows.Forms.Label lblStatsDispUpgradesUnlocked;
        private System.Windows.Forms.Label lblStatsTotalSoulsGained;
        private System.Windows.Forms.Label lblStatsDispSoulsTotal;
        private System.Windows.Forms.Label lblStatsSoulsSpent;
        private System.Windows.Forms.Label lblStatsDispSoulsSpent;
        private System.Windows.Forms.Label lblStatsClickCount;
        private System.Windows.Forms.Label lblStatsDispClickCount;
        private System.Windows.Forms.Label lblStatsSPC;
        private System.Windows.Forms.Label lblStatsSPS;
        private System.Windows.Forms.Label lblStatsSouls;
        private System.Windows.Forms.Label lblStatsDispSPC;
        private System.Windows.Forms.Label lblStatsDispSPS;
        private System.Windows.Forms.Label lblStatsDispSouls;
        private System.Windows.Forms.Label lblStatistics;
        private System.Windows.Forms.Timer timerSave;
        private System.Windows.Forms.Timer timerSPS;
        private System.Windows.Forms.Timer timerCheckAffordability;
        private System.Windows.Forms.Button btnBookUpgrade;
        private System.Windows.Forms.Button btnCouldronupgrade;
        private System.Windows.Forms.Button btnDragonUpgradeArmor;
        private System.Windows.Forms.Button btnDragonUpgradeFrostBreath;
        private System.Windows.Forms.Button btnDragonUpgradeRider;
        private System.Windows.Forms.Button btnDeathKnightUpgradeHorses;
        private System.Windows.Forms.Button btnDeathKnightUpgradeRunedArmor;
        private System.Windows.Forms.Button btnDeathKnightUpgradeSteel;
        private System.Windows.Forms.Button btnLichUpgradeScrolls;
        private System.Windows.Forms.Button btnLichUpgradeSummon;
        private System.Windows.Forms.Button btnLichUpgradeMagic;
        private System.Windows.Forms.Button btnWraithUpgradeWyvern;
        private System.Windows.Forms.Button btnWraithUpgradeInfernalWeapons;
        private System.Windows.Forms.Button btnWraithUpgradeHorse;
        private System.Windows.Forms.Button btnVampireUpgradeEnchantedWeaponry;
        private System.Windows.Forms.Button btnVampireUpgradeBatForm;
        private System.Windows.Forms.Button btnVampireUpgradeHealing;
        private System.Windows.Forms.Button btnSkeletonUpgradeDarksteel;
        private System.Windows.Forms.Button btnSkeletonUpgradeArmor;
        private System.Windows.Forms.Button btnSkeletonUpgradeWeapons;
        private System.Windows.Forms.Button btnGhoulUpgradeArmor;
        private System.Windows.Forms.Button btnGhoulUpgradeParalysis;
        private System.Windows.Forms.Button btnGhoulFangsUpgrade;
        private System.Windows.Forms.Button btnZombieMutantUpgrade;
        private System.Windows.Forms.Button btnZombieDiseasedUpgrade;
        private System.Windows.Forms.Button btnZombieFastUpgrade;
        private System.Windows.Forms.Button btnDemonHelperUpgrade;
        private System.Windows.Forms.Button btnAltarUpgrade;
        private System.Windows.Forms.Button btnImpUpgrade;
        private System.Windows.Forms.Button btnZombie;
        private System.Windows.Forms.Button btnGhoul;
        private System.Windows.Forms.Button btnSkeleton;
        private System.Windows.Forms.Button btnVampire;
        private System.Windows.Forms.Button btnWraith;
        private System.Windows.Forms.Button btnLich;
        private System.Windows.Forms.Button btnDeathKnight;
        private System.Windows.Forms.Button btnDragon;
        private System.Windows.Forms.Timer timerSoulieMan;
        private System.Windows.Forms.PictureBox pbxSoulieMan;
        private System.Windows.Forms.Label lblReportsRefresh;
        private System.Windows.Forms.Button btnSave;
    }
}

