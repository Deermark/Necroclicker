﻿//Marshall Ellison
//ITSE 1392
/*
For my final project I'd like to do a clicker game with a necromancy theme

The first form is going to be a login form, where it will keep track of who is playing, and use
the login information to store specific player's progress. The second form will have to be the game
form where everything happens. the third will be a report form. the fourth will be a high score form.

So, to step through the process of the application: you create an account (which performs an insert
into the database), then you login to use your new account (which grabs account specific information),
then you can frollic around with the game all you want, clicking around on all the things to click.
If you want to see certain statistics you can click on a view statistics tab somewhere an look at
some basic information. or if you want to see some crazy stats like graphs and such, you can click
an advanced statistics button or tab and view the reports. if you want to see high scores, you can
click high scores somewhere on the right cornerish side and see a list of users and their rank with
their profile pictures.

I think that covers everything on the requirements excepting for the delete(hide) functionality.
For this I think it would be interesting to add a reset button like all clickers have, where you
can reset your progress, which database wise will deactivate your old account, then make a new one.
This will keep your old data intact to where you can compare the old statistics with the new ones.

I'd love to have the user be able to upload a profile picture so that they can identify themselves a
mong the other users in a high score table thing. Also I think it would be neat if there was a ranking 
system, where the user could see what rank they are without looking at the high score table. Up in 
the corner of the screen where their profile picture is, I'll have a number for rank.


Cost = BaseCost × 1.15^(#Owned) everytime a monster is bought

clicks
at 0, 1 SPC
at 1,000, +1% of your SPS
at 10,000, +1% of your SPS
at 100,000, +1% of your SPS
at 1,000,000, +1% of your SPS

monsters base
15, .1
100, 1
500, 8
3,000, 47
10,000, 260
40,000, 1,400
200,000, 7,800
1,300,000, 44,000

sps = currentSPS + baseSPS

upgrades
zombie:
at 1 for 100, x2
at 10 for 500 x2
at 25 for 10,000 x2

Ghoul:
at 1 for 1,000 x2
at 5 for 5,000 x2
at 25 for 50,000 x2

Skeleton:
at 1 for 10,000 x2
at 5 for 50,000 x2
at 25 for 500,000 x2

Vampire:
at 1 for 120,000 x2
at 5 for 600,000 x2
at 25 for 6,000,000 x2

Wraith:
at 1 for 1,300,000 x2
at 5 for 6,500,000 x2
at 25 for 65,000,000 x2

Lich:
at 1 for 14,000,000 x2
at 5 for 70,000,000 x2
at 25 for 700,000,000 x2

Death Knight:
at 1 for 200,000,000 x2
at 5 for 1,000,000,000 x2
at 25 for 10,000,000,000 x2

Dragon:
at 1 for 3,300,000,000 x2
at 5 for 16,500,000,000 x2
at 25 for 165,000,000,000 x2

seconds to:

var /= 60
minutes = var % 60

var /= 60
hours = var % 24

var /= 24
days = var

 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EllisonM_Final_ST
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            
            InitializeComponent();
            timerStats.Start();//starts the timer for updating stats
            timerSave.Start();//starts the timer for saving the game
            timerSPS.Start();//starts the timer for adding to souls and total souls
            timerCheckAffordability.Start();//starts the timer for enabling and disabling panels
            //sets the pbx you click on to actually be transaparent so you can see the background.
            pbxBackground.Controls.Add(pbxClickThis);
            pbxClickThis.Location = new Point(17, 150);
            pbxClickThis.BackColor = Color.Transparent;
        }

        //hides the close button on the control box
        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        //variables:

        private static string _report = "";//for report
        public static string report
        {
            get { return _report; }
            set { _report = value; }
        }

        private double zombieMultiplier = 1;
        private double ghoulMultiplier = 1;
        private double skeletonMultiplier = 1;
        private double vampireMultiplier = 1;
        private double wraithMultiplier = 1;
        private double lichMultiplier = 1;
        private double deathKnightMultiplier = 1;
        private double dragonMultiplier = 1;
        private double clickableSPSPercentage = 0;

        private double costMultiplier = 1.15;

        private double zombieBaseCost = 15;
        private double ghoulBaseCost = 100;
        private double skeletonBaseCost = 500;
        private double vampireBaseCost = 3000;
        private double wraithBaseCost = 10000;
        private double lichBaseCost = 40000;
        private double deathKnightBaseCost = 200000;
        private double dragonBaseCost = 2000000;

        private double zombieBaseSPS = .1;
        private double ghoulBaseSPS = 2;
        private double skeletonBaseSPS = 8;
        private double vampireBaseSPS = 32;//was 20
        private double wraithBaseSPS = 128;//was 80
        private double lichBaseSPS = 512;//was 200
        private double deathKnightBaseSPS = 2048;//was 800
        private double dragonBaseSPS = 8192;//was 8000

        private double zombieSPS = 0;
        private double ghoulSPS = 0;
        private double skeletonSPS = 0;
        private double vampireSPS = 0;
        private double wraithSPS = 0;
        private double lichSPS = 0;
        private double deathKnightSPS = 0;
        private double dragonSPS = 0;

        private double zombieCost = 0;
        private double ghoulCost = 0;
        private double skeletonCost = 0;
        private double vampireCost = 0;
        private double wraithCost = 0;
        private double lichCost = 0;
        private double deathKnightCost = 0;
        private double dragonCost = 0;

        private double zombiePopulation = 0;
        private double ghoulPopulation = 0;
        private double skeletonPopulation = 0;
        private double vampirePopulation = 0;
        private double wraithPopulation = 0;
        private double lichPopulation = 0;
        private double deathKnightPopulation = 0;
        private double dragonPopulation = 0;

        private char book = '1';
        private char couldron = '1';
        private char imp = '1';
        private char altar = '1';
        private char demons = '1';
        private char zombie = '1';
        private char zombieFast = '1';
        private char zombieDiseased = '1';
        private char zombieMutant = '1';
        private char ghoul = '1';
        private char ghoulFangs = '1';
        private char ghoulParalysis = '1';
        private char ghoulLeather = '1';
        private char skeleton = '1';
        private char skeletonWeapons = '1';
        private char skeletonArmor = '1';
        private char skeletonDarksteel = '1';
        private char vampire = '1';
        private char vampireHealing = '1';
        private char vampireBat = '1';
        private char vampireWeapons = '1';
        private char wraith = '1';
        private char wraithHorse = '1';
        private char wraithWeapons = '1';
        private char wraithWyvern = '1';
        private char lich = '1';
        private char lichMagic = '1';
        private char lichSummon = '1';
        private char lichScrolls = '1';
        private char deathKnight = '1';
        private char deathKnightSteel = '1';
        private char deathKnightRuned = '1';
        private char deathKnightHorses = '1';
        private char dragon = '1';
        private char dragonRider = '1';
        private char dragonFrost = '1';
        private char dragonArmor = '1';

        private double bookCost = 0;
        private double couldronCost = 1000;
        private double impCost = 10000;
        private double altarCost = 100000;
        private double demonsCost = 1000000;
        private double zombieFastCost = 100;
        private double zombieDiseasedCost = 500;
        private double zombieMutantCost = 5000;
        private double ghoulFangsCost = 1000;
        private double ghoulParalysisCost = 5000;
        private double ghoulLeatherCost = 10000;
        private double skeletonWeaponsCost = 10000;
        private double skeletonArmorCost = 50000;
        private double skeletonDarksteelCost = 100000;
        private double vampireHealingCost = 100000;
        private double vampireBatCost = 500000;
        private double vampireWeaponsCost = 1000000;
        private double wraithHorseCost = 1000000;
        private double wraithWeaponsCost = 5000000;
        private double wraithWyvernCost = 10000000;
        private double lichMagicCost = 10000000;
        private double lichSummonCost = 20000000;
        private double lichScrollsCost = 30000000;
        private double deathKnightSteelCost = 30000000;
        private double deathKnightRunedCost = 40000000;
        private double deathKnightHorsesCost = 50000000;
        private double dragonRiderCost = 50000000;
        private double dragonFrostCost = 75000000;
        private double dragonArmorCost = 100000000;

        private double SPC = 0;
        private double SPS = 0;
        private double soulsAvailable = 0;
        private double clickCount = 0;
        private double soulsSpent = 0;
        private double soulsTotal = 0;
        private double upgradesUnlocked = 0;
        private double upgradesPurchased = 0;
        private string playTime = "";
        private double playTimeSeconds = 0;

        private void frmMain_Load(object sender, EventArgs e)
        {
            //setup invisible panel buttons
            pnlBookUpgrade.Controls.Add(btnBookUpgrade);
            pnlCouldronUpgrade.Controls.Add(btnCouldronupgrade);
            pnlImpUpgrade.Controls.Add(btnImpUpgrade);
            pnlAltarUpgrade.Controls.Add(btnAltarUpgrade);
            pnlDemonHelperUpgrade.Controls.Add(btnDemonHelperUpgrade);
            pnlZombie.Controls.Add(btnZombie);
            pnlZombieFastUpgrade.Controls.Add(btnZombieFastUpgrade);
            pnlZombieDiseasedUpgrade.Controls.Add(btnZombieDiseasedUpgrade);
            pnlZombieMutantUpgrade.Controls.Add(btnZombieMutantUpgrade);
            pnlGhoul.Controls.Add(btnGhoul);
            pnlGhoulFangsUpgrade.Controls.Add(btnGhoulFangsUpgrade);
            pnlGhoulUpgradeParalysis.Controls.Add(btnGhoulUpgradeParalysis);
            pnlGhoulUpgradeArmor.Controls.Add(btnGhoulUpgradeArmor);
            pnlSkeleton.Controls.Add(btnSkeleton);
            pnlSkeletonUpgradeWeapons.Controls.Add(btnSkeletonUpgradeWeapons);
            pnlSkeletonUpgradeArmor.Controls.Add(btnSkeletonUpgradeArmor);
            pnlSkeletonUpgradeDarksteel.Controls.Add(btnSkeletonUpgradeDarksteel);
            pnlVampire.Controls.Add(btnVampire);
            pnlVampireUpgradeHealing.Controls.Add(btnVampireUpgradeHealing);
            pnlVampireUpgradeBatForm.Controls.Add(btnVampireUpgradeBatForm);
            pnlVampireUpgradeEnchantedWeaponry.Controls.Add(btnVampireUpgradeEnchantedWeaponry);
            pnlWraith.Controls.Add(btnWraith);
            pnlWraithUpgradeHorse.Controls.Add(btnWraithUpgradeHorse);
            pnlWraithUpgradeInfernalWeaponry.Controls.Add(btnWraithUpgradeInfernalWeapons);
            pnlWraithUpgradeWyvern.Controls.Add(btnWraithUpgradeWyvern);
            pnlLich.Controls.Add(btnLich);
            pnlLichUpgradeMagic.Controls.Add(btnLichUpgradeMagic);
            pnlLichUpgradeSummon.Controls.Add(btnLichUpgradeSummon);
            pnlLichUpgradeScrolls.Controls.Add(btnLichUpgradeScrolls);
            pnlDeathKnight.Controls.Add(btnDeathKnight);
            pnlDeathKnightUpgradeSteel.Controls.Add(btnDeathKnightUpgradeSteel);
            pnlDeathKnightUpgradeRunedArmor.Controls.Add(btnDeathKnightUpgradeRunedArmor);
            pnlDeathKnightUpgradeHorses.Controls.Add(btnDeathKnightUpgradeHorses);
            pnlDragon.Controls.Add(btnDragon);
            pnlDragonUpgradeRider.Controls.Add(btnDragonUpgradeRider);
            pnlDragonUpgradeFrostBreath.Controls.Add(btnDragonUpgradeFrostBreath);
            pnlDragonUpgradeArmor.Controls.Add(btnDragonUpgradeArmor);

            pbxClickThis.Controls.Add(pbxSoulieMan);

            DataOps.selectEverythingWhereUserID();

            //setup stats and variables

            clickCount = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][51].ToString());
            //do playtime by using a timespan
            playTimeSeconds = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][58].ToString());
            TimeSpan time = TimeSpan.FromSeconds(playTimeSeconds);
            playTime = string.Format("{0:D2}d:{1:D2}h:{2:D2}m:{3:D2}s", time.Days, time.Hours, time.Minutes, time.Seconds);

            soulsAvailable = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][48].ToString());
            soulsSpent = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][52].ToString());
            SPC = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][50].ToString());
            SPS = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][49].ToString());
            soulsTotal = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][53].ToString());
            upgradesPurchased = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][55].ToString());
            upgradesUnlocked = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][54].ToString());

            lblSouls.Text = "Souls: " + String.Format("{0:n0}", Math.Round(soulsAvailable, 2));
            lblSPS.Text = "SPS: " + String.Format("{0:n}", Math.Round(SPS, 2));

            lblStatsClickCount.Text = String.Format("{0:n0}", Math.Round(clickCount, 2).ToString());
            lblStatsPlayTime.Text = playTime;
            lblStatsSouls.Text = String.Format("{0:n0}", Math.Round(soulsAvailable, 2).ToString());
            lblStatsSoulsSpent.Text = String.Format("{0:n0}", Math.Round(soulsSpent, 2).ToString());
            lblStatsSPC.Text = String.Format("{0:n}", Math.Round(SPC, 2).ToString());
            lblStatsSPS.Text = String.Format("{0:n}", Math.Round(SPS, 2).ToString());
            lblStatsTotalSoulsGained.Text = String.Format("{0:n0}", Math.Round(soulsTotal, 2).ToString());
            lblStatsUpgradesPurchased.Text = upgradesPurchased.ToString();
            lblStatsUpgradesUnlocked.Text = upgradesUnlocked.ToString();

            zombiePopulation = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][40].ToString());
            ghoulPopulation = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][41].ToString());
            skeletonPopulation = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][42].ToString());
            vampirePopulation = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][43].ToString());
            wraithPopulation = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][44].ToString());
            lichPopulation = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][45].ToString());
            deathKnightPopulation = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][46].ToString());
            dragonPopulation = double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][47].ToString());

            book = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][3].ToString());
            couldron = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][4].ToString());
            imp = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][5].ToString());
            altar = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][6].ToString());
            demons = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][7].ToString());
            zombie = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][8].ToString());
            zombieFast = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][9].ToString());
            zombieDiseased = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][10].ToString());
            zombieMutant = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][11].ToString());
            ghoul = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][12].ToString());
            ghoulFangs = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][13].ToString());
            ghoulParalysis = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][14].ToString());
            ghoulLeather = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][15].ToString());
            skeleton = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][16].ToString());
            skeletonWeapons = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][17].ToString());
            skeletonArmor = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][18].ToString());
            skeletonDarksteel = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][19].ToString());
            vampire = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][20].ToString());
            vampireHealing = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][21].ToString());
            vampireBat = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][22].ToString());
            vampireWeapons = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][23].ToString());
            wraith = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][24].ToString());
            wraithHorse = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][25].ToString());
            wraithWeapons = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][26].ToString());
            wraithWyvern = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][27].ToString());
            lich = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][28].ToString());
            lichMagic = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][29].ToString());
            lichSummon = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][30].ToString());
            lichScrolls = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][31].ToString());
            deathKnight = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][32].ToString());
            deathKnightSteel = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][33].ToString());
            deathKnightRuned = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][34].ToString());
            deathKnightHorses = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][35].ToString());
            dragon = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][36].ToString());
            dragonRider = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][37].ToString());
            dragonFrost = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][38].ToString());
            dragonArmor = char.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[0][39].ToString());

            pbxProfilePic.Image = DataOps.convertImage(0, 59);

            //setup upgrades

            //all of these check to see if the user purchsed any of the upgrades.
            //if they did: hide the upgrade, set the monster pic to the upgraded pic, set the multiplier for the monster

            //1 means its locked, 2 means its unlocked, 3 means its purchased

            //zombie
            if (zombieFast == '2'){pnlZombieFastUpgrade.Visible = true; pnlZombieFastUpgrade.Enabled = true;}
            else if(zombieFast == '3'){pnlZombieFastUpgrade.Visible = false; pnlZombieFastUpgrade.Enabled = false; pbxZombie.ImageLocation = @"Data/zombie fast.png"; zombieMultiplier = zombieMultiplier + 1; lblZombieDesc.Text = "Fast Zombie"; }
            else{pnlZombieFastUpgrade.Visible = false; pnlZombieFastUpgrade.Enabled = false;}
            if (zombieDiseased == '2') { pnlZombieDiseasedUpgrade.Visible = true; pnlZombieDiseasedUpgrade.Enabled = true; }
            else if (zombieDiseased == '3') { pnlZombieDiseasedUpgrade.Visible = false; pnlZombieDiseasedUpgrade.Enabled = false; pbxZombie.ImageLocation = @"Data/zombie diseased.png"; zombieMultiplier = zombieMultiplier + 4; lblZombieDesc.Text = "Diseased Zombie"; }
            else { pnlZombieDiseasedUpgrade.Visible = false; pnlZombieDiseasedUpgrade.Enabled = false; }
            if (zombieMutant == '2') { pnlZombieMutantUpgrade.Visible = true; pnlZombieMutantUpgrade.Enabled = true;}
            else if (zombieMutant == '3') { pnlZombieMutantUpgrade.Visible = false; pnlZombieMutantUpgrade.Enabled = false; pbxZombie.ImageLocation = @"Data/mutant zombie.png"; zombieMultiplier = zombieMultiplier + 10; lblZombieDesc.Text = "Mutant Zombie"; }
            else { pnlZombieMutantUpgrade.Visible = false; pnlZombieMutantUpgrade.Enabled = false; }

            //ghoul
            if (ghoulFangs == '2') { pnlGhoulFangsUpgrade.Visible = true; pnlGhoulFangsUpgrade.Enabled = true; }
            else if (ghoulFangs == '3') { pnlGhoulFangsUpgrade.Visible = false; pnlGhoulFangsUpgrade.Enabled = false; pbxGhoul.ImageLocation = @"Data/ghoul sharp fangs.png"; ghoulMultiplier = ghoulMultiplier + 1; lblGhoulDesc.Text = "Ghoul with fangs"; }
            else { pnlGhoulFangsUpgrade.Visible = false; pnlGhoulFangsUpgrade.Enabled = false; }
            if (ghoulParalysis == '2') { pnlGhoulUpgradeParalysis.Visible = true; pnlGhoulUpgradeParalysis.Enabled = true; }
            else if (ghoulParalysis == '3') { pnlGhoulUpgradeParalysis.Visible = false; pnlGhoulUpgradeParalysis.Enabled = false; pbxGhoul.ImageLocation = @"Data/ghoul paralysis.png"; ghoulMultiplier = ghoulMultiplier + 4; lblGhoulDesc.Text = "Ghoul with paralysis abilities"; }
            else { pnlGhoulUpgradeParalysis.Visible = false; pnlGhoulUpgradeParalysis.Enabled = false; }
            if (ghoulLeather == '2') { pnlGhoulUpgradeArmor.Visible = true; pnlGhoulUpgradeArmor.Enabled = true; }
            else if (ghoulLeather == '3') { pnlGhoulUpgradeArmor.Visible = false; pnlGhoulUpgradeArmor.Enabled = false; pbxGhoul.ImageLocation = @"Data/ghoul leather armor.png"; ghoulMultiplier = ghoulMultiplier + 10; lblGhoulDesc.Text = "Ghoul with leather armor"; }
            else { pnlGhoulUpgradeArmor.Visible = false; pnlGhoulUpgradeArmor.Enabled = false; }

            //skeleton
            if (skeletonWeapons == '2') { pnlSkeletonUpgradeWeapons.Visible = true; pnlSkeletonUpgradeWeapons.Enabled = true; }
            else if (skeletonWeapons == '3') { pnlSkeletonUpgradeWeapons.Visible = false; pnlSkeletonUpgradeWeapons.Enabled = false; skeletonWeapons = '3'; pbxSkeleton.ImageLocation = @"Data/skeleton iron sword.png"; skeletonMultiplier = skeletonMultiplier + 1; lblSkeletonDesc.Text = "Skeleton with iron weaponry"; }
            else { pnlSkeletonUpgradeWeapons.Visible = false; pnlSkeletonUpgradeWeapons.Enabled = false; }
            if (skeletonArmor == '2') { pnlSkeletonUpgradeArmor.Visible = true; pnlSkeletonUpgradeArmor.Enabled = true; }
            else if (skeletonArmor == '3') { pnlSkeletonUpgradeArmor.Visible = false; pnlSkeletonUpgradeArmor.Enabled = false; pbxSkeleton.ImageLocation = @"Data/skeleton iron armor.png"; skeletonMultiplier = skeletonMultiplier + 4; lblSkeletonDesc.Text = "Skeleton with iron armor"; }
            else { pnlSkeletonUpgradeArmor.Visible = false; pnlSkeletonUpgradeArmor.Enabled = false; }
            if (skeletonDarksteel == '2') { pnlSkeletonUpgradeDarksteel.Visible = true; pnlSkeletonUpgradeDarksteel.Enabled = true; }
            else if (skeletonDarksteel == '3') { pnlSkeletonUpgradeDarksteel.Visible = false; pnlSkeletonUpgradeDarksteel.Enabled = false; pbxSkeleton.ImageLocation = @"Data/skeleton darksteel sword.png"; skeletonMultiplier = skeletonMultiplier + 10; lblSkeletonDesc.Text = "Skeleton with darksteel weaponry"; }
            else { pnlSkeletonUpgradeDarksteel.Visible = false; pnlSkeletonUpgradeDarksteel.Enabled = false; }

            //vampire
            if (vampireHealing == '2') { pnlVampireUpgradeHealing.Visible = true; pnlVampireUpgradeHealing.Enabled = true; }
            else if (vampireHealing == '3') { pnlVampireUpgradeHealing.Visible = false; pnlVampireUpgradeHealing.Enabled = false; pbxVampire.ImageLocation = @"Data/vampire healing.png"; vampireMultiplier = vampireMultiplier + 1; lblVampireDescription.Text = "Vampire with improved healing"; }
            else { pnlVampireUpgradeHealing.Visible = false; pnlVampireUpgradeHealing.Enabled = false; }
            if (vampireBat == '2') { pnlVampireUpgradeBatForm.Visible = true; pnlVampireUpgradeBatForm.Enabled = true; }
            else if (vampireBat == '3') { pnlVampireUpgradeBatForm.Visible = false; pnlVampireUpgradeBatForm.Enabled = false; pbxVampire.ImageLocation = @"Data/vampire bat form.png"; vampireMultiplier = vampireMultiplier + 4; lblVampireDescription.Text = "Vampire with bat like abilities"; }
            else { pnlVampireUpgradeBatForm.Visible = false; pnlVampireUpgradeBatForm.Enabled = false; }
            if (vampireWeapons == '2') { pnlVampireUpgradeEnchantedWeaponry.Visible = true; pnlVampireUpgradeEnchantedWeaponry.Enabled = true; }
            else if (vampireWeapons == '3') { pnlVampireUpgradeEnchantedWeaponry.Visible = false; pnlVampireUpgradeEnchantedWeaponry.Enabled = false; pbxVampire.ImageLocation = @"Data/vampire enchanted weapons.png"; vampireMultiplier = vampireMultiplier + 10; lblVampireDescription.Text = "Vampire with enchanted weaponry"; }
            else { pnlVampireUpgradeEnchantedWeaponry.Visible = false; pnlVampireUpgradeEnchantedWeaponry.Enabled = false; }

            //wraith
            if (wraithHorse == '2') { pnlWraithUpgradeHorse.Visible = true; pnlWraithUpgradeHorse.Enabled = true; }
            else if (wraithHorse == '3') { pnlWraithUpgradeHorse.Visible = false; pnlWraithUpgradeHorse.Enabled = false; pbxWraith.ImageLocation = @"Data/wraith with horse.png"; wraithMultiplier = wraithMultiplier + 1; lblWraithDesc.Text = "Wraith with demonic horse"; }
            else { pnlWraithUpgradeHorse.Visible = false; pnlWraithUpgradeHorse.Enabled = false; }
            if (wraithWeapons == '2') { pnlWraithUpgradeInfernalWeaponry.Visible = true; pnlWraithUpgradeInfernalWeaponry.Enabled = true; }
            else if (wraithWeapons == '3') { pnlWraithUpgradeInfernalWeaponry.Visible = false; pnlWraithUpgradeInfernalWeaponry.Enabled = false; pbxWraith.ImageLocation = @"Data/wraith with horse and inferno blade.png"; wraithMultiplier = wraithMultiplier + 4; lblWraithDesc.Text = "Wraith with inferno weaponry"; }
            else { pnlWraithUpgradeInfernalWeaponry.Visible = false; pnlWraithUpgradeInfernalWeaponry.Enabled = false; }
            if (wraithWyvern == '2') { pnlWraithUpgradeWyvern.Visible = true; pnlWraithUpgradeWyvern.Enabled = true; }
            else if (wraithWyvern == '3') { pnlWraithUpgradeWyvern.Visible = false; pnlWraithUpgradeWyvern.Enabled = false; pbxWraith.ImageLocation = @"Data/wraith with wyvern and inferno blade.png"; wraithMultiplier = wraithMultiplier + 10; lblWraithDesc.Text = "Wraith with wyvern"; }
            else { pnlWraithUpgradeWyvern.Visible = false; pnlWraithUpgradeWyvern.Enabled = false; }

            //lich
            if (lichMagic == '2') { pnlLichUpgradeMagic.Visible = true; pnlLichUpgradeMagic.Enabled = true; }
            else if (lichMagic == '3') { pnlLichUpgradeMagic.Visible = false; pnlLichUpgradeMagic.Enabled = false; pbxLich.ImageLocation = @"Data/Lich blood magic.png"; lichMultiplier = lichMultiplier + 1; lblLichDesc.Text = "Lich with blood magic"; }
            else { pnlLichUpgradeMagic.Visible = false; pnlLichUpgradeMagic.Enabled = false; }
            if (lichSummon == '2') { pnlLichUpgradeSummon.Visible = true; pnlLichUpgradeSummon.Enabled = true; }
            else if (lichSummon == '3') { pnlLichUpgradeSummon.Visible = false; pnlLichUpgradeSummon.Enabled = false; pbxLich.ImageLocation = @"Data/Lich summon.png"; lichMultiplier = lichMultiplier + 4; lblLichDesc.Text = "Lich with the ability to summon lesser undead"; }
            else { pnlLichUpgradeSummon.Visible = false; pnlLichUpgradeSummon.Enabled = false; }
            if (lichScrolls == '2') { pnlLichUpgradeScrolls.Visible = true; pnlLichUpgradeScrolls.Enabled = true; }
            else if (lichScrolls == '3') { pnlLichUpgradeScrolls.Visible = false; pnlLichUpgradeScrolls.Enabled = false; pbxLich.ImageLocation = @"Data/Lich scroll.png"; lichMultiplier = lichMultiplier + 10; lblLichDesc.Text = "Lich with extra knowlege from ancient scrolls"; }
            else { pnlLichUpgradeScrolls.Visible = false; pnlLichUpgradeScrolls.Enabled = false; }

            //death knight
            if (deathKnightSteel == '2') { pnlDeathKnightUpgradeSteel.Visible = true; pnlDeathKnightUpgradeSteel.Enabled = true; }
            else if (deathKnightSteel == '3') { pnlDeathKnightUpgradeSteel.Visible = false; pnlDeathKnightUpgradeSteel.Enabled = false; pbxDeathKnight.ImageLocation = @"Data/death knight bloodforged steel.png"; deathKnightMultiplier = deathKnightMultiplier + 1; lblDeathKnightDesc.Text = "Death knight with bloodforged steel weaponry"; }
            else { pnlDeathKnightUpgradeSteel.Visible = false; pnlDeathKnightUpgradeSteel.Enabled = false; }
            if (deathKnightRuned == '2') { pnlDeathKnightUpgradeRunedArmor.Visible = true; pnlDeathKnightUpgradeRunedArmor.Enabled = true; }
            else if (deathKnightRuned == '3') { pnlDeathKnightUpgradeRunedArmor.Visible = false; pnlDeathKnightUpgradeRunedArmor.Enabled = false; pbxDeathKnight.ImageLocation = @"Data/death knight runed armor.png"; deathKnightMultiplier = deathKnightMultiplier + 4; lblDeathKnightDesc.Text = "Death knight with runed armor"; }
            else { pnlDeathKnightUpgradeRunedArmor.Visible = false; pnlDeathKnightUpgradeRunedArmor.Enabled = false; }
            if (deathKnightHorses == '2') { pnlDeathKnightUpgradeHorses.Visible = true; pnlDeathKnightUpgradeHorses.Enabled = true; }
            else if (deathKnightHorses == '3') { pnlDeathKnightUpgradeHorses.Visible = false; pnlDeathKnightUpgradeHorses.Enabled = false; pbxDeathKnight.ImageLocation = @"Data/death knight shadow horse.png"; deathKnightMultiplier = deathKnightMultiplier + 10; lblDeathKnightDesc.Text = "Death knight with shadow horse"; }
            else { pnlDeathKnightUpgradeHorses.Visible = false; pnlDeathKnightUpgradeHorses.Enabled = false; }

            //skeletal dragon
            if (dragonRider == '2') { pnlDragonUpgradeRider.Visible = true; pnlDragonUpgradeRider.Enabled = true;  }
            else if (dragonRider == '3') { pnlDragonUpgradeRider.Visible = false; pnlDragonUpgradeRider.Enabled = false; pbxDragon.ImageLocation = @"Data/skeletal dragon rider.png"; dragonMultiplier = dragonMultiplier + 1; lblDragonDesc.Text = "Skeletal dragon with rider"; }
            else { pnlDragonUpgradeRider.Visible = false; pnlDragonUpgradeRider.Enabled = false; }
            if (dragonFrost == '2') { pnlDragonUpgradeFrostBreath.Visible = true; pnlDragonUpgradeFrostBreath.Enabled = true; }
            else if (dragonFrost == '3') { pnlDragonUpgradeFrostBreath.Visible = false; pnlDragonUpgradeFrostBreath.Enabled = false; pbxDragon.ImageLocation = @"Data/skeletal dragon frost breath.png"; dragonMultiplier = dragonMultiplier + 4; lblDragonDesc.Text = "Skeletal dragon with frost breath"; }
            else { pnlDragonUpgradeFrostBreath.Visible = false; pnlDragonUpgradeFrostBreath.Enabled = false; }
            if (dragonArmor == '2') { pnlDragonUpgradeArmor.Visible = true; pnlDragonUpgradeArmor.Enabled = true; }
            else if (dragonArmor == '3') { pnlDragonUpgradeArmor.Visible = false; pnlDragonUpgradeArmor.Enabled = false; pbxDragon.ImageLocation = @"Data/skeletal dragon armor.png"; dragonMultiplier = dragonMultiplier + 10; lblDragonDesc.Text = "Skeletal dragon with draconic armor"; }
            else { pnlDragonUpgradeArmor.Visible = false; pnlDragonUpgradeArmor.Enabled = false; }

            //clickables
            if (book == '2') { pnlBookUpgrade.Visible = true; pnlBookUpgrade.Enabled = true; }
            else if (book == '3') { pnlBookUpgrade.Visible = false; pnlBookUpgrade.Enabled = false; pbxClickThis.ImageLocation = @"Data/book.png"; SPC = 1; }
            else { pnlBookUpgrade.Visible = false; pnlBookUpgrade.Enabled = false; }
            if (couldron == '2') { pnlCouldronUpgrade.Visible = true; pnlCouldronUpgrade.Enabled = true; }
            else if (couldron == '3') { pnlCouldronUpgrade.Visible = false; pnlCouldronUpgrade.Enabled = false; pbxClickThis.ImageLocation = @"Data/cauldron and book.png"; clickableSPSPercentage += .01; }
            else { pnlCouldronUpgrade.Visible = false; pnlCouldronUpgrade.Enabled = false; }
            if (imp == '2') { pnlImpUpgrade.Visible = true; pnlImpUpgrade.Enabled = true; }
            else if (imp == '3') { pnlImpUpgrade.Visible = false; pnlImpUpgrade.Enabled = false; pbxClickThis.ImageLocation = @"Data/cauldron and book with imp.png"; clickableSPSPercentage += .01; }
            else { pnlImpUpgrade.Visible = false; pnlImpUpgrade.Enabled = false; }
            if (altar == '2') { pnlAltarUpgrade.Visible = true; pnlAltarUpgrade.Enabled = true; }
            else if (altar == '3') { pnlAltarUpgrade.Visible = false; pnlAltarUpgrade.Enabled = false; pbxClickThis.ImageLocation = @"Data/Demon altar with book.png"; clickableSPSPercentage += .01; }
            else { pnlAltarUpgrade.Visible = false; pnlAltarUpgrade.Enabled = false; }
            if (demons == '2') { pnlDemonHelperUpgrade.Visible = true; pnlDemonHelperUpgrade.Enabled = true; }
            else if (demons == '3') { pnlDemonHelperUpgrade.Visible = false; pnlDemonHelperUpgrade.Enabled = false; pbxClickThis.ImageLocation = @"Data/Demon altar with imps and demon.png"; clickableSPSPercentage += .01; }
            else { pnlDemonHelperUpgrade.Visible = false; pnlDemonHelperUpgrade.Enabled = false; }

            //setup upgrade costs
            lblBookUpgradeCost.Text = String.Format("{0:n0}", bookCost) + " Souls";
            lblCouldronUpgradeCost.Text = String.Format("{0:n0}", couldronCost) + " Souls";
            lblImpUpgradeCost.Text = String.Format("{0:n0}", impCost) + " Souls";
            lblAltarUpgradeCost.Text = String.Format("{0:n0}", altarCost) + " Souls";
            lblDemonHelperUpgradeCost.Text = String.Format("{0:n0}", demonsCost) + " Souls";

            lblZombieFastUpgradeCost.Text = String.Format("{0:n0}", zombieFastCost) + " Souls";
            lblZombieDiseasedUpgradeCost.Text = String.Format("{0:n0}", zombieDiseasedCost) + " Souls";
            lblZombieMutantUpgradeCost.Text = String.Format("{0:n0}", zombieMutantCost) + " Souls";
            
            lblGhoulFangsUpgradeCost.Text = String.Format("{0:n0}", ghoulFangsCost) + " Souls";
            lblGhoulUpgradeParalysisCost.Text = String.Format("{0:n0}", ghoulParalysisCost) + " Souls";
            lblGhoulUpgradeArmorCost.Text = String.Format("{0:n0}", ghoulLeatherCost) + " Souls";
            
            lblSkeletonUpgradeWeaponsCost.Text = String.Format("{0:n0}", skeletonWeaponsCost) + " Souls";
            lblSkeletonUpgradeArmorCost.Text = String.Format("{0:n0}", skeletonArmorCost) + " Souls";
            lblSkeletonUpgradeDarksteelCost.Text = String.Format("{0:n0}", skeletonDarksteelCost) + " Souls";

            lblVampireUpgradeHealingCost.Text = String.Format("{0:n0}", vampireHealingCost) + " Souls";
            lblVampireUpgradeBatFormCost.Text = String.Format("{0:n0}", vampireBatCost) + " Souls";
            lblVampireUpgradeEnchantedWeaponryCost.Text = String.Format("{0:n0}", vampireWeaponsCost) + " Souls";
            
            lblWraithUpgradeHorseCost.Text = String.Format("{0:n0}", wraithHorseCost) + " Souls";
            lblWraithUpgradeInfernalWeaponryCost.Text = String.Format("{0:n0}", wraithWeaponsCost) + " Souls";
            lblWraithUpgradeWyvernCost.Text = String.Format("{0:n0}", wraithWyvernCost) + " Souls";

            lblLichUpgradeMagicCost.Text = String.Format("{0:n0}", lichMagicCost) + " Souls";
            lblLichUpgradeSummonCost.Text = String.Format("{0:n0}", lichSummonCost) + " Souls";
            lblLichUpgradeScrollsCost.Text = String.Format("{0:n0}", lichScrollsCost) + " Souls";

            lblDeathKnightUpgradeSteelCost.Text = String.Format("{0:n0}", deathKnightSteelCost) + " Souls";
            lblDeathKnightUpgradeRunedArmorCost.Text = String.Format("{0:n0}", deathKnightRunedCost) + " Souls";
            lblDeathKnightUpgradeHorsesCost.Text = String.Format("{0:n0}", deathKnightHorsesCost) + " Souls";

            lblDragonUpgradeRiderCost.Text = String.Format("{0:n0}", dragonRiderCost) + " Souls";
            lblDragonUpgradeFrostBreathCost.Text = String.Format("{0:n0}", dragonFrostCost) + " Souls";
            lblDragonUpgradeArmorCost.Text = String.Format("{0:n0}", dragonArmorCost) + " Souls";

            //setup monsters

            if (zombie == '2'){pnlZombie.Visible = true; pnlZombie.Enabled = true;}
            else{pnlZombie.Visible = false; pnlZombie.Enabled = false;}
            if(ghoul == '2') { pnlGhoul.Visible = true; pnlGhoul.Enabled = true; }
            else { pnlGhoul.Visible = false; pnlGhoul.Enabled = false; }
            if (skeleton == '2') { pnlSkeleton.Visible = true; pnlSkeleton.Enabled = true; }
            else { pnlSkeleton.Visible = false; pnlSkeleton.Enabled = false; }
            if (vampire == '2') { pnlVampire.Visible = true; pnlVampire.Enabled = true; }
            else { pnlVampire.Visible = false; pnlVampire.Enabled = false; }
            if (wraith == '2') { pnlWraith.Visible = true; pnlWraith.Enabled = true; }
            else { pnlWraith.Visible = false; pnlWraith.Enabled = false; }
            if (lich == '2') { pnlLich.Visible = true; pnlLich.Enabled = true; }
            else { pnlLich.Visible = false; pnlLich.Enabled = false; }
            if (deathKnight == '2') { pnlDeathKnight.Visible = true; pnlDeathKnight.Enabled = true; }
            else { pnlDeathKnight.Visible = false; pnlDeathKnight.Enabled = false; }
            if (dragon == '2') { pnlDragon.Visible = true; pnlDragon.Enabled = true; }
            else { pnlDragon.Visible = false; pnlDragon.Enabled = false; }

            //setup misc

            if (DataOps.dsData.Tables[DataOps.dtData].Rows[0][57].ToString() == "True")//checks if the user is an admin, and enables the super button
            {
                btnAdminButton.Visible = true;
                btnAdminButton.Enabled = true;
            }
            else
            {
                btnAdminButton.Visible = false;
                btnAdminButton.Enabled = false;
            }

            //calculate sps for monsters
            //currentSPS + (population * (baseCost * multiplier))
            if(zombieMutant == '3')
                zombieSPS = (zombieSPS / (zombieBaseSPS * zombiePopulation)) + (zombiePopulation * (zombieBaseSPS * zombieMultiplier));
            else
                zombieSPS = (zombiePopulation * (zombieBaseSPS * zombieMultiplier)); 
            if(ghoulLeather == '3')
                ghoulSPS = (ghoulSPS / (ghoulBaseSPS * ghoulPopulation)) + (ghoulPopulation * (ghoulBaseSPS * ghoulMultiplier));
            else
                ghoulSPS = (ghoulPopulation * (ghoulBaseSPS * ghoulMultiplier));
            if(skeletonDarksteel == '3')
                skeletonSPS = (skeletonSPS / (skeletonBaseSPS * skeletonPopulation)) + (skeletonPopulation * (skeletonBaseSPS * skeletonMultiplier));
            else
                skeletonSPS = (skeletonPopulation * (skeletonBaseSPS * skeletonMultiplier));
            if(vampireWeapons == '3')
                vampireSPS = (vampireSPS / (vampireBaseSPS * vampirePopulation)) + (vampirePopulation * (vampireBaseSPS * vampireMultiplier));
            else
                vampireSPS = (vampirePopulation * (vampireBaseSPS * vampireMultiplier));
            if(wraithWyvern == '3')
                wraithSPS = (wraithSPS / (wraithBaseSPS * wraithPopulation)) + (wraithPopulation * (wraithBaseSPS * wraithMultiplier));
            else
                wraithSPS = (wraithPopulation * (wraithBaseSPS * wraithMultiplier));
            if(lichScrolls == '3')
                lichSPS = (lichSPS / (lichBaseSPS * lichPopulation)) + (lichPopulation * (lichBaseSPS * lichMultiplier));
            else
                lichSPS = (lichPopulation * (lichBaseSPS * lichMultiplier));
            if(deathKnightHorses == '3')
                deathKnightSPS = (deathKnightSPS / (deathKnightBaseSPS * deathKnightPopulation)) + (deathKnightPopulation * (deathKnightBaseSPS * deathKnightMultiplier));
            else
                deathKnightSPS = (deathKnightPopulation * (deathKnightBaseSPS * deathKnightMultiplier));
            if(dragonArmor == '3')
                dragonSPS = (dragonSPS / (dragonBaseSPS * dragonPopulation)) + (dragonPopulation * (dragonBaseSPS * dragonMultiplier));
            else
                dragonSPS = (dragonPopulation * (dragonBaseSPS * dragonMultiplier));

            //storage for if something doesn't work with the other formula
            //for (int i = 0; i < zombiePopulation; i++)
            //    zombieSPS += (zombieBaseSPS * zombieMultiplier);
            //for (int i = 0; i < ghoulPopulation; i++)
            //    ghoulSPS += (ghoulBaseSPS * ghoulMultiplier);
            //for (int i = 0; i < skeletonPopulation; i++)
            //    skeletonSPS += (skeletonBaseSPS * skeletonMultiplier);
            //for (int i = 0; i < vampirePopulation; i++)
            //    vampireSPS += (vampireBaseSPS * vampireMultiplier);
            //for (int i = 0; i < wraithPopulation; i++)
            //    wraithSPS += (wraithBaseSPS * wraithMultiplier);
            //for (int i = 0; i < lichPopulation; i++)
            //    lichSPS += (lichBaseSPS * lichMultiplier);
            //for (int i = 0; i < deathKnightPopulation; i++)
            //    deathKnightSPS += (deathKnightBaseSPS * deathKnightMultiplier);
            //for (int i = 0; i < dragonPopulation; i++)
            //    dragonSPS += (dragonBaseSPS * dragonMultiplier);

            //calculate Cost for monsters

            //Cost = BaseCost × 1.15 ^ (#Owned)
            zombieCost = zombieBaseCost * Math.Pow(costMultiplier, zombiePopulation); 
            ghoulCost = ghoulBaseCost * Math.Pow(costMultiplier, ghoulPopulation);
            skeletonCost = skeletonBaseCost * Math.Pow(costMultiplier, skeletonPopulation);
            vampireCost = vampireBaseCost * Math.Pow(costMultiplier, vampirePopulation); 
            wraithCost = wraithBaseCost * Math.Pow(costMultiplier, wraithPopulation);
            lichCost = lichBaseCost * Math.Pow(costMultiplier, lichPopulation);
            deathKnightCost = deathKnightBaseCost * Math.Pow(costMultiplier, deathKnightPopulation);
            dragonCost = dragonBaseCost * Math.Pow(costMultiplier, dragonPopulation);

            lblZombieCost.Text = String.Format("{0:n0}", Math.Round(zombieCost, 2)) + " Souls";
            lblZombieAmount.Text = "Population: " + zombiePopulation + " SPS: " + String.Format("{0:n}", Math.Round(zombieSPS, 2));
            lblGhoulCost.Text = String.Format("{0:n0}", Math.Round(ghoulCost, 2)) + " Souls";
            lblGhoulAmount.Text = "Population: " + ghoulPopulation + " SPS: " + String.Format("{0:n}", Math.Round(ghoulSPS, 2));
            lblSkeletonCost.Text = String.Format("{0:n0}", Math.Round(skeletonCost, 2)) + " Souls";
            lblSkeletonAmount.Text = "Population: " + skeletonPopulation + " SPS: " +String.Format("{0:n}", Math.Round(skeletonSPS, 2));
            lblVampireCost.Text = String.Format("{0:n0}", Math.Round(vampireCost, 2)) + " Souls";
            lblVampireAmount.Text = "Population: " + vampirePopulation + " SPS: " + String.Format("{0:n}", Math.Round(vampireSPS, 2));
            lblWraithCost.Text = String.Format("{0:n0}", Math.Round(wraithCost, 2)) + " Souls";
            lblWraithAmount.Text = "Population: " + wraithPopulation + " SPS: " + String.Format("{0:n}", Math.Round(wraithSPS, 2));
            lblLichCost.Text = String.Format("{0:n0}", Math.Round(lichCost, 2)) + " Souls";
            lblLichAmount.Text = "Population: " + lichPopulation + " SPS: " + String.Format("{0:n}", Math.Round(lichSPS, 2));
            lblDeathKnightCost.Text = String.Format("{0:n0}", Math.Round(deathKnightCost, 2)) + " Souls";
            lblDeathKnightAmount.Text = "Population: " + deathKnightPopulation + " SPS: " + String.Format("{0:n}", Math.Round(deathKnightSPS, 2));
            lblDragonCost.Text = String.Format("{0:n0}", Math.Round(dragonCost, 2)) + " Souls";
            lblDragonAmount.Text = "Population: " + dragonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(dragonSPS, 2));

        }

        private void calculateSPSAndSPC()
        {
            SPS = zombieSPS + ghoulSPS + skeletonSPS + vampireSPS + wraithSPS + lichSPS + deathKnightSPS + dragonSPS;

            if(clickableSPSPercentage != 0)
                SPC = (SPS * clickableSPSPercentage) + 1; 

            lblSPS.Text = "SPS: " + String.Format("{0:n}", SPS);
        }

        private void pbxClickThis_MouseClick(object sender, MouseEventArgs e)
        {
            //add the SPC to the amount of souls and total souls, also add one to click count
            soulsAvailable += SPC;
            soulsTotal += SPC;
            clickCount += 1;

            //changes the pbx to a lighter version of the current upgrade for 50ms
            if (pbxClickThis.ImageLocation == @"Data/book.png")
            {
                timerSoulieMan.Start();//start the timer to clean up the pbx
                pbxClickThis.ImageLocation = @"Data/book click.png";
            }
            else if (pbxClickThis.ImageLocation == @"Data/cauldron and book.png")
            {
                timerSoulieMan.Start();//start the timer to clean up the pbx
                pbxClickThis.ImageLocation = @"Data/cauldron and book click.png";
            }
            else if (pbxClickThis.ImageLocation == @"Data/cauldron and book with imp.png")
            {
                timerSoulieMan.Start();//start the timer to clean up the pbx
                pbxClickThis.ImageLocation = @"Data/cauldron and book with imp click.png";
            }
            else if (pbxClickThis.ImageLocation == @"Data/Demon altar with book.png")
            {
                timerSoulieMan.Start();//start the timer to clean up the pbx
                pbxClickThis.ImageLocation = @"Data/Demon altar with book click.png";
            }
            else if (pbxClickThis.ImageLocation == @"Data/Demon altar with imps and demon.png")
            {
                timerSoulieMan.Start();//start the timer to clean up the pbx
                pbxClickThis.ImageLocation = @"Data/Demon altar with imps and demon click.png";
            }

            ////checks if the timer is running. if it isn't then the program can do a soullllllieieie man run.
            //if (!timerSoulieMan.Enabled)
            //{
            //    //make two random coordinates
            //    Random randomX = new Random();
            //    int xPos = randomX.Next(138, 319);
            //    Random randomY = new Random();
            //    int yPos = randomY.Next(181, 268);

            //    pbxSoulieMan.Visible = true;
            //    pbxSoulieMan.Location = new Point(xPos, yPos);//set location using randoms
            //    pbxSoulieMan.ImageLocation = @"Data/soullie man.gif";//give it the gif b0ss
            //    timerSoulieMan.Start();//start the timer to clean up the pbx when the gif is done
            //}
        }

        private void timerSoulieMan_Tick(object sender, EventArgs e)
        {
            //resets the pbx back to normal after a 50ms
            timerSoulieMan.Stop();
            if (pbxClickThis.ImageLocation == @"Data/book click.png")
            {
                pbxClickThis.ImageLocation = @"Data/book.png";
            }
            else if (pbxClickThis.ImageLocation == @"Data/cauldron and book click.png")
            {
                pbxClickThis.ImageLocation = @"Data/cauldron and book.png";
            }
            else if (pbxClickThis.ImageLocation == @"Data/cauldron and book with imp click.png")
            {
                pbxClickThis.ImageLocation = @"Data/cauldron and book with imp.png";
            }
            else if (pbxClickThis.ImageLocation == @"Data/Demon altar with book click.png")
            {
                pbxClickThis.ImageLocation = @"Data/Demon altar with book.png";
            }
            else if (pbxClickThis.ImageLocation == @"Data/Demon altar with imps and demon click.png")
            {
                pbxClickThis.ImageLocation = @"Data/Demon altar with imps and demon.png";
            }
            //cleans up the picture box after the soulie man gif is finished 4240ms
            //pbxSoulieMan.Visible = false;
        }

        private void timerSPS_Tick(object sender, EventArgs e)
        {
            //every second adds the SPS to the amount of souls and total souls. also adds to the playtime
            playTimeSeconds += 1;
            soulsAvailable += SPS;
            soulsTotal += SPS;

            lblSouls.Text = "Souls: " + String.Format("{0:n0}", Math.Round(soulsAvailable, 2));
        }

        private void timerStats_Tick(object sender, EventArgs e)
        {
            //Updates stats every 5 seconds
            lblStatsClickCount.Text = String.Format("{0:n0}", clickCount);
            //use a timespan to make the playtime
            TimeSpan time = TimeSpan.FromSeconds(playTimeSeconds);
            playTime = string.Format("{0:D2}d:{1:D2}h:{2:D2}m:{3:D2}s", time.Days, time.Hours, time.Minutes, time.Seconds);
            lblStatsPlayTime.Text = playTime;

            lblStatsSouls.Text = String.Format("{0:n0}", Math.Round(soulsAvailable, 2));
            lblStatsSoulsSpent.Text = String.Format("{0:n0}", Math.Round(soulsSpent, 2));
            lblStatsSPC.Text = String.Format("{0:n}", Math.Round(SPC, 2));
            lblStatsSPS.Text = String.Format("{0:n}", Math.Round(SPS, 2));
            this.Text = "Necroclicker " + "(" + String.Format("{0:n0}", Math.Round(soulsAvailable, 2)) + " Souls)";
            lblStatsTotalSoulsGained.Text = String.Format("{0:n0}", Math.Round(soulsTotal, 2));
            lblStatsUpgradesPurchased.Text = upgradesPurchased.ToString();
            lblStatsUpgradesUnlocked.Text = upgradesUnlocked.ToString();
            //configure monster information
            lblZombieCost.Text = String.Format("{0:n0}", Math.Round(zombieCost, 2)) + " Souls";
            lblZombieAmount.Text = "Population: " + zombiePopulation + " SPS: " + String.Format("{0:n}", Math.Round(zombieSPS, 2));
            lblGhoulCost.Text = String.Format("{0:n0}", Math.Round(ghoulCost, 2)) + " Souls";
            lblGhoulAmount.Text = "Population: " + ghoulPopulation + " SPS: " + String.Format("{0:n}", Math.Round(ghoulSPS, 2));
            lblSkeletonCost.Text = String.Format("{0:n0}", Math.Round(skeletonCost, 2)) + " Souls";
            lblSkeletonAmount.Text = "Population: " + skeletonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(skeletonSPS, 2));
            lblVampireCost.Text = String.Format("{0:n0}", Math.Round(vampireCost, 2)) + " Souls";
            lblVampireAmount.Text = "Population: " + vampirePopulation + " SPS: " + String.Format("{0:n}", Math.Round(vampireSPS, 2));
            lblWraithCost.Text = String.Format("{0:n0}", Math.Round(wraithCost, 2)) + " Souls";
            lblWraithAmount.Text = "Population: " + wraithPopulation + " SPS: " + String.Format("{0:n}", Math.Round(wraithSPS, 2));
            lblLichCost.Text = String.Format("{0:n0}", Math.Round(lichCost, 2)) + " Souls";
            lblLichAmount.Text = "Population: " + lichPopulation + " SPS: " + String.Format("{0:n}", Math.Round(lichSPS, 2));
            lblDeathKnightCost.Text = String.Format("{0:n0}", Math.Round(deathKnightCost, 2)) + " Souls";
            lblDeathKnightAmount.Text = "Population: " + deathKnightPopulation + " SPS: " + String.Format("{0:n}", Math.Round(deathKnightSPS, 2));
            lblDragonCost.Text = String.Format("{0:n0}", Math.Round(dragonCost, 2)) + " Souls";
            lblDragonAmount.Text = "Population: " + dragonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(dragonSPS, 2));
        }

        private void timerSave_Tick(object sender, EventArgs e)
        {
            //saves every minute
            byte[] image = null;
            using (MemoryStream ms = new MemoryStream())
            {
                pbxProfilePic.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                image = ms.ToArray();
            }
            DataOps.updateEverything(book.ToString(), couldron.ToString(), imp.ToString(), altar.ToString(), demons.ToString(), zombie.ToString(), zombieFast.ToString(), zombieDiseased.ToString(), zombieMutant.ToString(), ghoul.ToString(), ghoulFangs.ToString(), ghoulParalysis.ToString(), ghoulLeather.ToString(), skeleton.ToString(), skeletonWeapons.ToString(), skeletonArmor.ToString(), skeletonDarksteel.ToString(), vampire.ToString(), vampireHealing.ToString(), vampireBat.ToString(), vampireWeapons.ToString(), wraith.ToString(), wraithHorse.ToString(), wraithWeapons.ToString(), wraithWyvern.ToString(), lich.ToString(), lichMagic.ToString(), lichSummon.ToString(), lichScrolls.ToString(), deathKnight.ToString(), deathKnightSteel.ToString(), deathKnightRuned.ToString(), deathKnightHorses.ToString(), dragon.ToString(), dragonRider.ToString(), dragonFrost.ToString(), dragonArmor.ToString(), zombiePopulation.ToString(), ghoulPopulation.ToString(), skeletonPopulation.ToString(), vampirePopulation.ToString(), wraithPopulation.ToString(), lichPopulation.ToString(), deathKnightPopulation.ToString(), dragonPopulation.ToString(), soulsAvailable.ToString(), SPS.ToString(), SPC.ToString(), clickCount.ToString(), soulsSpent.ToString(), soulsTotal.ToString(), upgradesUnlocked.ToString(), upgradesPurchased.ToString(), playTimeSeconds.ToString(), image);
        }

        private void timerCheckAffordability_Tick(object sender, EventArgs e)
        {
            //checks to see if the user can afford upgrades and monsters every 100ms and enables/disables the panels accordingly. also sets the background  

            //upgrades

            //activate upgrade if soulsAvailable is equal to the Cost
            ////once these are unlocked, they are permanently unlocked
            //zombie
            if (zombieFast == '1')
            {
                if (zombiePopulation >= 1) { pnlZombieFastUpgrade.Visible = true; pnlZombieFastUpgrade.Enabled = true; zombieFast = '2'; upgradesUnlocked += 1;}
                else { pnlZombieFastUpgrade.Visible = false; pnlZombieFastUpgrade.Enabled = false; }
            }
            if (zombieDiseased == '1')
            {
                if (zombiePopulation >= 5) { pnlZombieDiseasedUpgrade.Visible = true; pnlZombieDiseasedUpgrade.Enabled = true; zombieDiseased = '2'; upgradesUnlocked += 1;}
                else { pnlZombieDiseasedUpgrade.Visible = false; pnlZombieDiseasedUpgrade.Enabled = false; }
            }
            if (zombieMutant == '1')
            {
                if (zombiePopulation >= 15) { pnlZombieMutantUpgrade.Visible = true; pnlZombieMutantUpgrade.Enabled = true; zombieMutant = '2'; upgradesUnlocked += 1;}
                else { pnlZombieMutantUpgrade.Visible = false; pnlZombieMutantUpgrade.Enabled = false; }
            }
            //ghoul
            if (ghoulFangs == '1')
            {
                if (ghoulPopulation >= 1) { pnlGhoulFangsUpgrade.Visible = true; pnlGhoulFangsUpgrade.Enabled = true; ghoulFangs = '2'; upgradesUnlocked += 1;}
                else { pnlGhoulFangsUpgrade.Visible = false; pnlGhoulFangsUpgrade.Enabled = false; }
            }
            if (ghoulParalysis == '1')
            {
                if (ghoulPopulation >= 5) { pnlGhoulUpgradeParalysis.Visible = true; pnlGhoulUpgradeParalysis.Enabled = true; ghoulParalysis = '2'; upgradesUnlocked += 1;}
                else { pnlGhoulUpgradeParalysis.Visible = false; pnlGhoulUpgradeParalysis.Enabled = false; }
            }
            if (ghoulLeather == '1')
            {
                if (ghoulPopulation >= 15) { pnlGhoulUpgradeArmor.Visible = true; pnlGhoulUpgradeArmor.Enabled = true; ghoulLeather = '2'; upgradesUnlocked += 1; }
                else { pnlGhoulUpgradeArmor.Visible = false; pnlGhoulUpgradeArmor.Enabled = false; }
            }
            //skeleton
            if (skeletonWeapons == '1')
            {
                if (skeletonPopulation >= 1) { pnlSkeletonUpgradeWeapons.Visible = true; pnlSkeletonUpgradeWeapons.Enabled = true; skeletonWeapons = '2'; upgradesUnlocked += 1;}
                else { pnlSkeletonUpgradeWeapons.Visible = false; pnlSkeletonUpgradeWeapons.Enabled = false; }
            }
            if (skeletonArmor == '1')
            {
                if (skeletonPopulation >= 5) { pnlSkeletonUpgradeArmor.Visible = true; pnlSkeletonUpgradeArmor.Enabled = true; skeletonArmor = '2'; upgradesUnlocked += 1;}
                else { pnlSkeletonUpgradeArmor.Visible = false; pnlSkeletonUpgradeArmor.Enabled = false; }
            }
            if (skeletonDarksteel == '1')
            {
                if (skeletonPopulation >= 15) { pnlSkeletonUpgradeDarksteel.Visible = true; pnlSkeletonUpgradeDarksteel.Enabled = true; skeletonDarksteel = '2'; upgradesUnlocked += 1; }
                else { pnlSkeletonUpgradeDarksteel.Visible = false; pnlSkeletonUpgradeDarksteel.Enabled = false; }
            }
            //vampire
            if (vampireHealing == '1')
            {
                if (vampirePopulation >= 1) { pnlVampireUpgradeHealing.Visible = true; pnlVampireUpgradeHealing.Enabled = true; vampireHealing = '2'; upgradesUnlocked += 1;}
                else { pnlVampireUpgradeHealing.Visible = false; pnlVampireUpgradeHealing.Enabled = false; }
            }
            if (vampireBat == '1')
            {
                if (vampirePopulation >= 5) { pnlVampireUpgradeBatForm.Visible = true; pnlVampireUpgradeBatForm.Enabled = true; vampireBat = '2'; upgradesUnlocked += 1;}
                else { pnlVampireUpgradeBatForm.Visible = false; pnlVampireUpgradeBatForm.Enabled = false; }
            }
            if (vampireWeapons == '1')
            {
                if (vampirePopulation >= 15) { pnlVampireUpgradeEnchantedWeaponry.Visible = true; pnlVampireUpgradeEnchantedWeaponry.Enabled = true; vampireWeapons = '2'; upgradesUnlocked += 1;}
                else { pnlVampireUpgradeEnchantedWeaponry.Visible = false; pnlVampireUpgradeEnchantedWeaponry.Enabled = false; }
            }
            //wraith
            if (wraithHorse == '1')
            {
                if (wraithPopulation >= 1) { pnlWraithUpgradeHorse.Visible = true; pnlWraithUpgradeHorse.Enabled = true; wraithHorse = '2'; upgradesUnlocked += 1;}
                else { pnlWraithUpgradeHorse.Visible = false; pnlWraithUpgradeHorse.Enabled = false; }
            }
            if (wraithWeapons == '1')
            {
                if (wraithPopulation >= 5) { pnlWraithUpgradeInfernalWeaponry.Visible = true; pnlWraithUpgradeInfernalWeaponry.Enabled = true; wraithWeapons = '2'; upgradesUnlocked += 1;  }
                else { pnlWraithUpgradeInfernalWeaponry.Visible = false; pnlWraithUpgradeInfernalWeaponry.Enabled = false; }
            }
            if (wraithWyvern == '1')
            {
                if (wraithPopulation >= 15) { pnlWraithUpgradeWyvern.Visible = true; pnlWraithUpgradeWyvern.Enabled = true; wraithWyvern = '2'; upgradesUnlocked += 1; }
                else { pnlWraithUpgradeWyvern.Visible = false; pnlWraithUpgradeWyvern.Enabled = false; }
            }
            //lich
            if (lichMagic == '1')
            {
                if (lichPopulation >= 1) { pnlLichUpgradeMagic.Visible = true; pnlLichUpgradeMagic.Enabled = true; lichMagic = '2'; upgradesUnlocked += 1;}
                else { pnlLichUpgradeMagic.Visible = false; pnlLichUpgradeMagic.Enabled = false; }
            }
            if (lichSummon == '1')
            {
                if (lichPopulation >= 5) { pnlLichUpgradeSummon.Visible = true; pnlLichUpgradeSummon.Enabled = true; lichSummon = '2'; upgradesUnlocked += 1; }
                else { pnlLichUpgradeSummon.Visible = false; pnlLichUpgradeSummon.Enabled = false; }
            }
            if (lichScrolls == '1')
            {
                if (lichPopulation >= 15) { pnlLichUpgradeScrolls.Visible = true; pnlLichUpgradeScrolls.Enabled = true; lichScrolls = '2'; upgradesUnlocked += 1; }
                else { pnlLichUpgradeScrolls.Visible = false; pnlLichUpgradeScrolls.Enabled = false; }
            }
            //death knight
            if (deathKnightSteel == '1')
            {
                if (deathKnightPopulation >= 1) { pnlDeathKnightUpgradeSteel.Visible = true; pnlDeathKnightUpgradeSteel.Enabled = true; deathKnightSteel = '2'; upgradesUnlocked += 1; }
                else { pnlDeathKnightUpgradeSteel.Visible = false; pnlDeathKnightUpgradeSteel.Enabled = false; }
            }
            if (deathKnightRuned == '1')
            {
                if (deathKnightPopulation >= 5) { pnlDeathKnightUpgradeRunedArmor.Visible = true; pnlDeathKnightUpgradeRunedArmor.Enabled = true; deathKnightRuned = '2'; upgradesUnlocked += 1;}
                else { pnlDeathKnightUpgradeRunedArmor.Visible = false; pnlDeathKnightUpgradeRunedArmor.Enabled = false; }
            }
            if (deathKnightHorses == '1')
            {
                if (deathKnightPopulation >= 15) { pnlDeathKnightUpgradeHorses.Visible = true; pnlDeathKnightUpgradeHorses.Enabled = true; deathKnightHorses = '2'; upgradesUnlocked += 1;}
                else { pnlDeathKnightUpgradeHorses.Visible = false; pnlDeathKnightUpgradeHorses.Enabled = false; }
            }
            //dragon
            if (dragonRider == '1')
            {
                if (dragonPopulation >= 1) { pnlDragonUpgradeRider.Visible = true; pnlDragonUpgradeRider.Enabled = true; dragonRider = '2'; upgradesUnlocked += 1; }
                else { pnlDragonUpgradeRider.Visible = false; pnlDragonUpgradeRider.Enabled = false; }
            }
            if (dragonFrost == '1')
            {
                if (dragonPopulation >= 5) { pnlDragonUpgradeFrostBreath.Visible = true; pnlDragonUpgradeFrostBreath.Enabled = true; dragonFrost = '2'; upgradesUnlocked += 1; }
                else { pnlDragonUpgradeFrostBreath.Visible = false; pnlDragonUpgradeFrostBreath.Enabled = false; }
            }
            if (dragonArmor == '1')
            {
                if (dragonPopulation >= 15) { pnlDragonUpgradeArmor.Visible = true; pnlDragonUpgradeArmor.Enabled = true; dragonArmor = '2'; upgradesUnlocked += 1; }
                else { pnlDragonUpgradeArmor.Visible = false; pnlDragonUpgradeArmor.Enabled = false; }
            }
            //clickables
            if (book == '1')
            {
                if (soulsAvailable >= bookCost) { pnlBookUpgrade.Visible = true; pnlBookUpgrade.Enabled = true; book = '2'; upgradesUnlocked += 1; }
                else { pnlBookUpgrade.Visible = false; pnlBookUpgrade.Enabled = false; }
            }
            if (couldron == '1')
            {
                if (soulsAvailable >= couldronCost) { pnlCouldronUpgrade.Visible = true; pnlCouldronUpgrade.Enabled = true; couldron = '2'; upgradesUnlocked += 1; }
                else { pnlCouldronUpgrade.Visible = false; pnlCouldronUpgrade.Enabled = false; }
            }
            if (imp == '1')
            {
                if (soulsAvailable >= impCost) { pnlImpUpgrade.Visible = true; pnlImpUpgrade.Enabled = true; imp = '2'; upgradesUnlocked += 1; }
                else { pnlImpUpgrade.Visible = false; pnlImpUpgrade.Enabled = false; }
            }
            if (altar == '1')
            {
                if (soulsAvailable >= altarCost) { pnlAltarUpgrade.Visible = true; pnlAltarUpgrade.Enabled = true; altar = '2'; upgradesUnlocked += 1; }
                else { pnlAltarUpgrade.Visible = false; pnlAltarUpgrade.Enabled = false; }
            }
            if (demons == '1')
            {
                if (soulsAvailable >= demonsCost) { pnlDemonHelperUpgrade.Visible = true; pnlDemonHelperUpgrade.Enabled = true; demons = '2'; upgradesUnlocked += 1; }
                else { pnlDemonHelperUpgrade.Visible = false; pnlDemonHelperUpgrade.Enabled = false; }
            }

            //check upgrade availability
            //zombie
            if (zombieFast == '2')
            {
                if (soulsAvailable >= zombieFastCost) { pnlZombieFastUpgrade.Enabled = true; pnlZombieFastUpgrade.Font = new Font(pnlZombieFastUpgrade.Font, FontStyle.Bold); }
                else { pnlZombieFastUpgrade.Enabled = false; pnlZombieFastUpgrade.Font = new Font(pnlZombieFastUpgrade.Font, FontStyle.Regular); }
            }
            if (zombieDiseased == '2')
            {
                if (soulsAvailable >= zombieDiseasedCost) { pnlZombieDiseasedUpgrade.Enabled = true; pnlZombieDiseasedUpgrade.Font = new Font(pnlZombieDiseasedUpgrade.Font, FontStyle.Bold); }
                else { pnlZombieDiseasedUpgrade.Enabled = false; pnlZombieDiseasedUpgrade.Font = new Font(pnlZombieDiseasedUpgrade.Font, FontStyle.Regular); }
            }
            if (zombieMutant == '2')
            {
                if (soulsAvailable >= zombieMutantCost) { pnlZombieMutantUpgrade.Enabled = true; pnlZombieMutantUpgrade.Font = new Font(pnlZombieMutantUpgrade.Font, FontStyle.Bold); }
                else { pnlZombieMutantUpgrade.Enabled = false; pnlZombieMutantUpgrade.Font = new Font(pnlZombieMutantUpgrade.Font, FontStyle.Regular); }
            }
            //ghoul
            if (ghoulFangs == '2')
            {
                if (soulsAvailable >= ghoulFangsCost) { pnlGhoulFangsUpgrade.Enabled = true; pnlGhoulFangsUpgrade.Font = new Font(pnlGhoulFangsUpgrade.Font, FontStyle.Bold); }
                else { pnlGhoulFangsUpgrade.Enabled = false; pnlGhoulFangsUpgrade.Font = new Font(pnlGhoulFangsUpgrade.Font, FontStyle.Regular); }
            }
            if (ghoulParalysis == '2')
            {
                if (soulsAvailable >= ghoulParalysisCost) { pnlGhoulUpgradeParalysis.Enabled = true; pnlGhoulUpgradeParalysis.Font = new Font(pnlGhoulUpgradeParalysis.Font, FontStyle.Bold); }
                else { pnlGhoulUpgradeParalysis.Enabled = false; pnlGhoulUpgradeParalysis.Font = new Font(pnlGhoulUpgradeParalysis.Font, FontStyle.Regular); }
            }
            if (ghoulLeather == '2')
            {
                if (soulsAvailable >= ghoulLeatherCost) { pnlGhoulUpgradeArmor.Enabled = true; pnlGhoulUpgradeArmor.Font = new Font(pnlGhoulUpgradeArmor.Font, FontStyle.Bold); }
                else { pnlGhoulUpgradeArmor.Enabled = false; pnlGhoulUpgradeArmor.Font = new Font(pnlGhoulUpgradeArmor.Font, FontStyle.Regular); }
            }
            //skeleton
            if (skeletonWeapons == '2')
            {
                if (soulsAvailable >= skeletonWeaponsCost) { pnlSkeletonUpgradeWeapons.Enabled = true; pnlSkeletonUpgradeWeapons.Font = new Font(pnlSkeletonUpgradeWeapons.Font, FontStyle.Bold); }
                else { pnlSkeletonUpgradeWeapons.Enabled = false; pnlSkeletonUpgradeWeapons.Font = new Font(pnlSkeletonUpgradeWeapons.Font, FontStyle.Regular); }
            }
            if (skeletonArmor == '2')
            {
                if (soulsAvailable >= skeletonArmorCost) { pnlSkeletonUpgradeArmor.Enabled = true; pnlSkeletonUpgradeArmor.Font = new Font(pnlSkeletonUpgradeArmor.Font, FontStyle.Bold); }
                else { pnlSkeletonUpgradeArmor.Enabled = false; pnlSkeletonUpgradeArmor.Font = new Font(pnlSkeletonUpgradeArmor.Font, FontStyle.Regular); }
            }
            if (skeletonDarksteel == '2')
            {
                if (soulsAvailable >= skeletonDarksteelCost) { pnlSkeletonUpgradeDarksteel.Enabled = true; pnlSkeletonUpgradeDarksteel.Font = new Font(pnlSkeletonUpgradeDarksteel.Font, FontStyle.Bold); }
                else { pnlSkeletonUpgradeDarksteel.Enabled = false; pnlSkeletonUpgradeDarksteel.Font = new Font(pnlSkeletonUpgradeDarksteel.Font, FontStyle.Regular); }
            }
            //vampire
            if (vampireHealing == '2')
            {
                if (soulsAvailable >= vampireHealingCost) { pnlVampireUpgradeHealing.Enabled = true; pnlVampireUpgradeHealing.Font = new Font(pnlVampireUpgradeHealing.Font, FontStyle.Bold); }
                else { pnlVampireUpgradeHealing.Enabled = false; pnlVampireUpgradeHealing.Font = new Font(pnlVampireUpgradeHealing.Font, FontStyle.Regular); }
            }
            if (vampireBat == '2')
            {
                if (soulsAvailable >= vampireBatCost) { pnlVampireUpgradeBatForm.Enabled = true; pnlVampireUpgradeBatForm.Font = new Font(pnlVampireUpgradeBatForm.Font, FontStyle.Bold); }
                else { pnlVampireUpgradeBatForm.Enabled = false; pnlVampireUpgradeBatForm.Font = new Font(pnlVampireUpgradeBatForm.Font, FontStyle.Regular); }
            }
            if (vampireWeapons == '2')
            {
                if (soulsAvailable >= vampireWeaponsCost) { pnlVampireUpgradeEnchantedWeaponry.Enabled = true; pnlVampireUpgradeEnchantedWeaponry.Font = new Font(pnlVampireUpgradeEnchantedWeaponry.Font, FontStyle.Bold); }
                else { pnlVampireUpgradeEnchantedWeaponry.Enabled = false; pnlVampireUpgradeEnchantedWeaponry.Font = new Font(pnlVampireUpgradeEnchantedWeaponry.Font, FontStyle.Regular); }
            }
            //wraith
            if (wraithHorse == '2')
            {
                if (soulsAvailable >= wraithHorseCost) { pnlWraithUpgradeHorse.Enabled = true; pnlWraithUpgradeHorse.Font = new Font(pnlWraithUpgradeHorse.Font, FontStyle.Bold); }
                else { pnlWraithUpgradeHorse.Enabled = false; pnlWraithUpgradeHorse.Font = new Font(pnlWraithUpgradeHorse.Font, FontStyle.Regular); }
            }
            if (wraithWeapons == '2')
            {
                if (soulsAvailable >= wraithWeaponsCost) { pnlWraithUpgradeInfernalWeaponry.Enabled = true; pnlWraithUpgradeInfernalWeaponry.Font = new Font(pnlWraithUpgradeInfernalWeaponry.Font, FontStyle.Bold); }
                else { pnlWraithUpgradeInfernalWeaponry.Enabled = false; pnlWraithUpgradeInfernalWeaponry.Font = new Font(pnlWraithUpgradeInfernalWeaponry.Font, FontStyle.Regular); }
            }
            if (wraithWyvern == '2')
            {
                if (soulsAvailable >= wraithWyvernCost) { pnlWraithUpgradeWyvern.Enabled = true; pnlWraithUpgradeWyvern.Font = new Font(pnlWraithUpgradeWyvern.Font, FontStyle.Bold); }
                else { pnlWraithUpgradeWyvern.Enabled = false; pnlWraithUpgradeWyvern.Font = new Font(pnlWraithUpgradeWyvern.Font, FontStyle.Regular); }
            }
            //lich
            if (lichMagic == '2')
            {
                if (soulsAvailable >= lichMagicCost) { pnlLichUpgradeMagic.Enabled = true; pnlLichUpgradeMagic.Font = new Font(pnlLichUpgradeMagic.Font, FontStyle.Bold); }
                else { pnlLichUpgradeMagic.Enabled = false; pnlLichUpgradeMagic.Font = new Font(pnlLichUpgradeMagic.Font, FontStyle.Regular); }
            }
            if (lichSummon == '2')
            {
                if (soulsAvailable >= lichSummonCost) { pnlLichUpgradeSummon.Enabled = true; pnlLichUpgradeSummon.Font = new Font(pnlLichUpgradeSummon.Font, FontStyle.Bold); }
                else { pnlLichUpgradeSummon.Enabled = false; pnlLichUpgradeSummon.Font = new Font(pnlLichUpgradeSummon.Font, FontStyle.Regular); }
            }
            if (lichScrolls == '2')
            {
                if (soulsAvailable >= lichScrollsCost) { pnlLichUpgradeScrolls.Enabled = true; pnlLichUpgradeScrolls.Font = new Font(pnlLichUpgradeScrolls.Font, FontStyle.Bold); }
                else { pnlLichUpgradeScrolls.Enabled = false; pnlLichUpgradeScrolls.Font = new Font(pnlLichUpgradeScrolls.Font, FontStyle.Regular); }
            }
            //death knight
            if (deathKnightSteel == '2')
            {
                if (soulsAvailable >= deathKnightSteelCost) { pnlDeathKnightUpgradeSteel.Enabled = true; pnlDeathKnightUpgradeSteel.Font = new Font(pnlDeathKnightUpgradeSteel.Font, FontStyle.Bold); }
                else { pnlDeathKnightUpgradeSteel.Enabled = false; pnlDeathKnightUpgradeSteel.Font = new Font(pnlDeathKnightUpgradeSteel.Font, FontStyle.Regular); }
            }
            if (deathKnightRuned == '2')
            {
                if (soulsAvailable >= deathKnightRunedCost) { pnlDeathKnightUpgradeRunedArmor.Enabled = true; pnlDeathKnightUpgradeRunedArmor.Font = new Font(pnlDeathKnightUpgradeRunedArmor.Font, FontStyle.Bold); }
                else { pnlDeathKnightUpgradeRunedArmor.Enabled = false; pnlDeathKnightUpgradeRunedArmor.Font = new Font(pnlDeathKnightUpgradeRunedArmor.Font, FontStyle.Regular); }
            }
            if (deathKnightHorses == '2')
            {
                if (soulsAvailable >= deathKnightHorsesCost) { pnlDeathKnightUpgradeHorses.Enabled = true; pnlDeathKnightUpgradeHorses.Font = new Font(pnlDeathKnightUpgradeHorses.Font, FontStyle.Bold); }
                else { pnlDeathKnightUpgradeHorses.Enabled = false; pnlDeathKnightUpgradeHorses.Font = new Font(pnlDeathKnightUpgradeHorses.Font, FontStyle.Regular); }
            }
            //dragon
            if (dragonRider == '2')
            {
                if (soulsAvailable >= dragonRiderCost) { pnlDragonUpgradeRider.Enabled = true; pnlDragonUpgradeRider.Font = new Font(pnlDragonUpgradeRider.Font, FontStyle.Bold); }
                else { pnlDragonUpgradeRider.Enabled = false; pnlDragonUpgradeRider.Font = new Font(pnlDragonUpgradeRider.Font, FontStyle.Regular); }
            }
            if (dragonFrost == '2')
            {
                if (soulsAvailable >= dragonFrostCost) { pnlDragonUpgradeFrostBreath.Enabled = true; pnlDragonUpgradeFrostBreath.Font = new Font(pnlDragonUpgradeFrostBreath.Font, FontStyle.Bold); }
                else { pnlDragonUpgradeFrostBreath.Enabled = false; pnlDragonUpgradeFrostBreath.Font = new Font(pnlDragonUpgradeFrostBreath.Font, FontStyle.Regular); }
            }
            if (dragonArmor == '2')
            {
                if (soulsAvailable >= dragonArmorCost) { pnlDragonUpgradeArmor.Enabled = true; pnlDragonUpgradeArmor.Font = new Font(pnlDragonUpgradeArmor.Font, FontStyle.Bold); }
                else { pnlDragonUpgradeArmor.Enabled = false; pnlDragonUpgradeArmor.Font = new Font(pnlDragonUpgradeArmor.Font, FontStyle.Regular); }
            }
            //clickables
            if (book == '2')
            {
                if (soulsAvailable >= bookCost) { pnlBookUpgrade.Enabled = true; pnlBookUpgrade.Font = new Font(pnlBookUpgrade.Font, FontStyle.Bold); }
                else { pnlBookUpgrade.Enabled = false; pnlBookUpgrade.Font = new Font(pnlBookUpgrade.Font, FontStyle.Regular); }
            }
            if (couldron == '2')
            {
                if (soulsAvailable >= couldronCost) { pnlCouldronUpgrade.Enabled = true; pnlCouldronUpgrade.Font = new Font(pnlCouldronUpgrade.Font, FontStyle.Bold); }
                else { pnlCouldronUpgrade.Enabled = false; pnlCouldronUpgrade.Font = new Font(pnlCouldronUpgrade.Font, FontStyle.Regular); }
            }
            if (imp == '2')
            {
                if (soulsAvailable >= impCost) { pnlImpUpgrade.Enabled = true; pnlImpUpgrade.Font = new Font(pnlImpUpgrade.Font, FontStyle.Bold); }
                else { pnlImpUpgrade.Enabled = false; pnlImpUpgrade.Font = new Font(pnlImpUpgrade.Font, FontStyle.Regular); }
            }
            if (altar == '2')
            {
                if (soulsAvailable >= altarCost) { pnlAltarUpgrade.Enabled = true; pnlAltarUpgrade.Font = new Font(pnlAltarUpgrade.Font, FontStyle.Bold); }
                else { pnlAltarUpgrade.Enabled = false; pnlAltarUpgrade.Font = new Font(pnlAltarUpgrade.Font, FontStyle.Regular); }
            }
            if (demons == '2')
            {
                if (soulsAvailable >= demonsCost) { pnlDemonHelperUpgrade.Enabled = true; pnlDemonHelperUpgrade.Font = new Font(pnlDemonHelperUpgrade.Font, FontStyle.Bold); }
                else { pnlDemonHelperUpgrade.Enabled = false; pnlDemonHelperUpgrade.Font = new Font(pnlDemonHelperUpgrade.Font, FontStyle.Regular); }
            }

            //monsters 

            //activate monster if soulsAvailable is equal to the base cost
            //once these are unlocked, they are permanently unlocked
            if (zombie == '1')
            {
                if (soulsAvailable >= zombieBaseCost) { pnlZombie.Visible = true; pnlZombie.Enabled = true; zombie = '2'; }
                else { pnlZombie.Visible = false; pnlZombie.Enabled = false; }
            }
            if (ghoul == '1')
            {
                if (zombiePopulation >= 1) { pnlGhoul.Visible = true; pnlGhoul.Enabled = true; ghoul = '2'; }
                else { pnlGhoul.Visible = false; pnlGhoul.Enabled = false; }
            }
            if (skeleton == '1')
            {
                if (ghoulPopulation >= 1) { pnlSkeleton.Visible = true; pnlSkeleton.Enabled = true; skeleton = '2'; }
                else { pnlSkeleton.Visible = false; pnlSkeleton.Enabled = false; }
            }
            if (vampire == '1')
            {
                if (skeletonPopulation >= 1) { pnlVampire.Visible = true; pnlVampire.Enabled = true; vampire = '2'; }
                else { pnlVampire.Visible = false; pnlVampire.Enabled = false; }
            }
            if (wraith == '1')
            {
                if (vampirePopulation >= 1) { pnlWraith.Visible = true; pnlWraith.Enabled = true; wraith = '2'; }
                else { pnlWraith.Visible = false; pnlWraith.Enabled = false; }
            }
            if (lich == '1')
            {
                if (wraithPopulation >= 1) { pnlLich.Visible = true; pnlLich.Enabled = true; lich = '2'; }
                else { pnlLich.Visible = false; pnlLich.Enabled = false; }
            }
            if (deathKnight == '1')
            {
                if (lichPopulation >= 1) { pnlDeathKnight.Visible = true; pnlDeathKnight.Enabled = true; deathKnight = '2'; }
                else { pnlDeathKnight.Visible = false; pnlDeathKnight.Enabled = false; }
            }
            if (dragon == '1')
            {
                if (deathKnightPopulation >= 1) { pnlDragon.Visible = true; pnlDragon.Enabled = true; dragon = '2'; }
                else { pnlDragon.Visible = false; pnlDragon.Enabled = false; }
            }

            //check monster availability
            if (soulsAvailable >= zombieCost){ pnlZombie.Enabled = true; pnlZombie.Font = new Font(pnlZombie.Font, FontStyle.Bold); }
            else{ pnlZombie.Enabled = false; pnlZombie.Font = new Font(pnlZombie.Font, FontStyle.Regular); }

            if (soulsAvailable >= ghoulCost){ pnlGhoul.Enabled = true; pnlGhoul.Font = new Font(pnlGhoul.Font, FontStyle.Bold); }
            else{ pnlGhoul.Enabled = false; pnlGhoul.Font = new Font(pnlGhoul.Font, FontStyle.Regular); }

            if (soulsAvailable >= skeletonCost){ pnlSkeleton.Enabled = true; pnlSkeleton.Font = new Font(pnlSkeleton.Font, FontStyle.Bold); }
            else{ pnlSkeleton.Enabled = false; pnlSkeleton.Font = new Font(pnlSkeleton.Font, FontStyle.Regular); }

            if (soulsAvailable >= vampireCost){ pnlVampire.Enabled = true; pnlVampire.Font = new Font(pnlVampire.Font, FontStyle.Bold); }
            else{ pnlVampire.Enabled = false; pnlVampire.Font = new Font(pnlVampire.Font, FontStyle.Regular); }

            if (soulsAvailable >= wraithCost){ pnlWraith.Enabled = true; pnlWraith.Font = new Font(pnlWraith.Font, FontStyle.Bold); }
            else{ pnlWraith.Enabled = false; pnlWraith.Font = new Font(pnlWraith.Font, FontStyle.Regular); }

            if (soulsAvailable >= lichCost){ pnlLich.Enabled = true; pnlLich.Font = new Font(pnlLich.Font, FontStyle.Bold); }
            else{ pnlLich.Enabled = false; pnlLich.Font = new Font(pnlLich.Font, FontStyle.Regular); }

            if (soulsAvailable >= deathKnightCost){ pnlDeathKnight.Enabled = true; pnlDeathKnight.Font = new Font(pnlDeathKnight.Font, FontStyle.Bold); }
            else{ pnlDeathKnight.Enabled = false; pnlDeathKnight.Font = new Font(pnlDeathKnight.Font, FontStyle.Regular); }

            if (soulsAvailable >= dragonCost){ pnlDragon.Enabled = true; pnlDragon.Font = new Font(pnlDragon.Font, FontStyle.Bold); }
            else{ pnlDragon.Enabled = false; pnlDragon.Font = new Font(pnlDragon.Font, FontStyle.Regular); }


            //set background
            if (soulsTotal <= 50000)
            {
                pbxBackground.ImageLocation = @"Data/cabin.png";
            }
            else if(soulsTotal > 50000 && soulsTotal <= 600000)
            {
                pbxBackground.ImageLocation = @"Data/dead village.png";
            }
            else if(soulsTotal > 600000 && soulsTotal <= 4000000)
            {
                pbxBackground.ImageLocation = @"Data/fortressconstruction.png";
            }
            else if(soulsTotal > 4000000 && soulsTotal <= 70000000)
            {
                pbxBackground.ImageLocation = @"Data/fortress complete.png";
            }
            else if(soulsTotal > 70000000)
            {
                pbxBackground.ImageLocation = @"Data/completefortresszoomout.png";
            }
        }

        private void btnAdminButton_Click(object sender, EventArgs e)
        {
            soulsAvailable += 1000000;//adds 1mil to souls available
            soulsTotal += 1000000;//adds 1mil to souls total

            lblSouls.Text = "Souls: " + String.Format("{0:n0}", Math.Round(soulsAvailable, 2));
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            frmHelp help = new frmHelp();
            help.ShowDialog();
        }

        private void btnHighScores_Click(object sender, EventArgs e)
        {
            frmHighScores highScores = new frmHighScores();
            highScores.ShowDialog();
        }

        private void pbxProfilePic_Click(object sender, EventArgs e)
        {
            //makes a new filedialog, which allows the user to grab an image from their computer and put it inside the picture box
            string imageLocation = "";
            OpenFileDialog upload = new OpenFileDialog();
            if (upload.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    imageLocation = upload.FileName.ToString();
                    pbxProfilePic.ImageLocation = imageLocation;
                    byte[] image = null;
                    using (MemoryStream ms = new MemoryStream())
                    {
                        pbxProfilePic.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        image = ms.ToArray();
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Error: Unable to upload picture.");
                    pbxProfilePic.ImageLocation = @"Data/default profile picture.png";
                    return;
                }
            }
        }

        private void btnStatistics_Click(object sender, EventArgs e)
        {
            try
            {
                report = "stats";
                frmReport statsReport = new frmReport();
                statsReport.ShowDialog();
            }
            catch (Exception)
            {
                MessageBox.Show("Crystal Reports must be installed and patched to the correct version to access reports.");
                return;
            }
        }

        private void btnClicksOverTimeGraph_Click(object sender, EventArgs e)
        {
            try {
            report = "COT";
            frmReport COTReport = new frmReport();
            COTReport.ShowDialog();
            }
            catch (Exception)
            {
                MessageBox.Show("Crystal Reports must be installed and patched to the correct version to access reports.");
                return;
            }
        }

        private void btnSPSOverTimeGraph_Click(object sender, EventArgs e)
        {
            try
            {
            report = "TSOT";
            frmReport TSOTReport = new frmReport();
            TSOTReport.ShowDialog();
            }
            catch (Exception)
            {
                MessageBox.Show("Crystal Reports must be installed and patched to the correct version to access reports.");
                return;
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            //save on close
            byte[] image = null;
            using (MemoryStream ms = new MemoryStream())
            {
                pbxProfilePic.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                image = ms.ToArray();
            }
            DataOps.updateEverything(book.ToString(), couldron.ToString(), imp.ToString(), altar.ToString(), demons.ToString(), zombie.ToString(), zombieFast.ToString(), zombieDiseased.ToString(), zombieMutant.ToString(), ghoul.ToString(), ghoulFangs.ToString(), ghoulParalysis.ToString(), ghoulLeather.ToString(), skeleton.ToString(), skeletonWeapons.ToString(), skeletonArmor.ToString(), skeletonDarksteel.ToString(), vampire.ToString(), vampireHealing.ToString(), vampireBat.ToString(), vampireWeapons.ToString(), wraith.ToString(), wraithHorse.ToString(), wraithWeapons.ToString(), wraithWyvern.ToString(), lich.ToString(), lichMagic.ToString(), lichSummon.ToString(), lichScrolls.ToString(), deathKnight.ToString(), deathKnightSteel.ToString(), deathKnightRuned.ToString(), deathKnightHorses.ToString(), dragon.ToString(), dragonRider.ToString(), dragonFrost.ToString(), dragonArmor.ToString(), zombiePopulation.ToString(), ghoulPopulation.ToString(), skeletonPopulation.ToString(), vampirePopulation.ToString(), wraithPopulation.ToString(), lichPopulation.ToString(), deathKnightPopulation.ToString(), dragonPopulation.ToString(), soulsAvailable.ToString(), SPS.ToString(), SPC.ToString(), clickCount.ToString(), soulsSpent.ToString(), soulsTotal.ToString(), upgradesUnlocked.ToString(), upgradesPurchased.ToString(), playTimeSeconds.ToString(), image);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //saves the game when clicked
            byte[] image = null;
            using (MemoryStream ms = new MemoryStream())
            {
                pbxProfilePic.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                image = ms.ToArray();
            }
            DataOps.updateEverything(book.ToString(), couldron.ToString(), imp.ToString(), altar.ToString(), demons.ToString(), zombie.ToString(), zombieFast.ToString(), zombieDiseased.ToString(), zombieMutant.ToString(), ghoul.ToString(), ghoulFangs.ToString(), ghoulParalysis.ToString(), ghoulLeather.ToString(), skeleton.ToString(), skeletonWeapons.ToString(), skeletonArmor.ToString(), skeletonDarksteel.ToString(), vampire.ToString(), vampireHealing.ToString(), vampireBat.ToString(), vampireWeapons.ToString(), wraith.ToString(), wraithHorse.ToString(), wraithWeapons.ToString(), wraithWyvern.ToString(), lich.ToString(), lichMagic.ToString(), lichSummon.ToString(), lichScrolls.ToString(), deathKnight.ToString(), deathKnightSteel.ToString(), deathKnightRuned.ToString(), deathKnightHorses.ToString(), dragon.ToString(), dragonRider.ToString(), dragonFrost.ToString(), dragonArmor.ToString(), zombiePopulation.ToString(), ghoulPopulation.ToString(), skeletonPopulation.ToString(), vampirePopulation.ToString(), wraithPopulation.ToString(), lichPopulation.ToString(), deathKnightPopulation.ToString(), dragonPopulation.ToString(), soulsAvailable.ToString(), SPS.ToString(), SPC.ToString(), clickCount.ToString(), soulsSpent.ToString(), soulsTotal.ToString(), upgradesUnlocked.ToString(), upgradesPurchased.ToString(), playTimeSeconds.ToString(), image);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //purchasing section
        #region purchasing


        //********* Upgrades *********

        private void btnDragonUpgradeArmor_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - dragonArmorCost < 0))
            {
                soulsAvailable = soulsAvailable - dragonArmorCost;
                soulsSpent += dragonArmorCost;
                pbxDragon.ImageLocation = @"Data/skeletal dragon armor.png";
                lblDragonDesc.Text = "Skeletal dragon with draconic armor";
                pnlDragonUpgradeArmor.Visible = false;
                pnlDragonUpgradeArmor.Enabled = false;
                dragonMultiplier = dragonMultiplier + 10;
                dragonSPS = (dragonPopulation * (dragonBaseSPS * dragonMultiplier));
                lblDragonAmount.Text = "Population: " + dragonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(dragonSPS, 2));
                dragonArmor = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnDragonUpgradeFrostBreath_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - dragonFrostCost < 0))
            {
                soulsAvailable = soulsAvailable - dragonFrostCost;
                soulsSpent += dragonFrostCost;
                if (dragonArmor != '3')
                {            
                    pbxDragon.ImageLocation = @"Data/skeletal dragon frost breath.png";
                    lblDragonDesc.Text = "Skeletal dragon with frost breath";
                }
                pnlDragonUpgradeFrostBreath.Visible = false;
                pnlDragonUpgradeFrostBreath.Enabled = false;
                dragonMultiplier = dragonMultiplier + 4;
                dragonSPS = (dragonPopulation * (dragonBaseSPS * dragonMultiplier));
                lblDragonAmount.Text = "Population: " + dragonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(dragonSPS, 2));
                dragonFrost = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnDragonUpgradeRider_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - dragonRiderCost < 0))
            {
                soulsAvailable = soulsAvailable - dragonRiderCost;
                soulsSpent += dragonRiderCost;
                if (dragonFrost != '3' && dragonArmor != '3')
                {
                    pbxDragon.ImageLocation = @"Data/skeletal dragon rider.png";
                    lblDragonDesc.Text = "Skeletal dragon with rider";
                }
                    pnlDragonUpgradeRider.Visible = false;
                pnlDragonUpgradeRider.Enabled = false;
                dragonMultiplier = dragonMultiplier + 1;
                dragonSPS = (dragonPopulation * (dragonBaseSPS * dragonMultiplier));
                lblDragonAmount.Text = "Population: " + dragonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(dragonSPS, 2));
                dragonRider = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnDeathKnightUpgradeHorses_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - deathKnightHorsesCost < 0))
            {
                soulsAvailable = soulsAvailable - deathKnightHorsesCost;
                soulsSpent += deathKnightHorsesCost;
                pbxDeathKnight.ImageLocation = @"Data/death knight shadow horse.png";
                lblDeathKnightDesc.Text = "Death knight with shadow horse";
                pnlDeathKnightUpgradeHorses.Visible = false;
                pnlDeathKnightUpgradeHorses.Enabled = false;
                deathKnightMultiplier = deathKnightMultiplier + 10;
                deathKnightSPS = (deathKnightPopulation * (deathKnightBaseSPS * deathKnightMultiplier));
                lblDeathKnightAmount.Text = "Population: " + deathKnightPopulation + " SPS: " + String.Format("{0:n}", Math.Round(deathKnightSPS, 2));
                deathKnightHorses = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnDeathKnightUpgradeRunedArmor_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - deathKnightRunedCost < 0))
            {
                soulsAvailable = soulsAvailable - deathKnightRunedCost;
                soulsSpent += deathKnightRunedCost;
                if (deathKnightHorses != '3')
                {
                    pbxDeathKnight.ImageLocation = @"Data/death knight runed armor.png";
                    lblDeathKnightDesc.Text = "Death knight with runed armor";
                }
                pnlDeathKnightUpgradeRunedArmor.Visible = false;
                pnlDeathKnightUpgradeRunedArmor.Enabled = false;
                deathKnightMultiplier = deathKnightMultiplier + 4;
                deathKnightSPS = (deathKnightPopulation * (deathKnightBaseSPS * deathKnightMultiplier));
                lblDeathKnightAmount.Text = "Population: " + deathKnightPopulation + " SPS: " + String.Format("{0:n}", Math.Round(deathKnightSPS, 2));
                deathKnightRuned = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnDeathKnightUpgradeSteel_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - deathKnightSteelCost < 0))
            {
                soulsAvailable = soulsAvailable - deathKnightSteelCost;
                soulsSpent += deathKnightSteelCost;
                if (deathKnightRuned != '3' && deathKnightHorses != '3')
                {
                    pbxDeathKnight.ImageLocation = @"Data/death knight bloodforged steel.png";
                    lblDeathKnightDesc.Text = "Death knight with bloodforged steel weaponry";
                }
                pnlDeathKnightUpgradeSteel.Visible = false;
                pnlDeathKnightUpgradeSteel.Enabled = false;
                deathKnightMultiplier = deathKnightMultiplier + 1;
                deathKnightSPS = (deathKnightPopulation * (deathKnightBaseSPS * deathKnightMultiplier));
                lblDeathKnightAmount.Text = "Population: " + deathKnightPopulation + " SPS: " + String.Format("{0:n}", Math.Round(deathKnightSPS, 2));
                deathKnightSteel = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnLichUpgradeScrolls_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - lichScrollsCost < 0))
            {
                soulsAvailable = soulsAvailable - lichScrollsCost;
                soulsSpent += lichScrollsCost;
                pbxLich.ImageLocation = @"Data/lich scroll.png";
                lblLichDesc.Text = "Lich with extra knowlege from ancient scrolls";
                pnlLichUpgradeScrolls.Visible = false;
                pnlLichUpgradeScrolls.Enabled = false;
                lichMultiplier = lichMultiplier + 10;
                lichSPS = (lichPopulation * (lichBaseSPS * lichMultiplier));
                lblLichAmount.Text = "Population: " + lichPopulation + " SPS: " + String.Format("{0:n}", Math.Round(lichSPS, 2));
                lichScrolls = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnLichUpgradeSummon_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - lichSummonCost < 0))
            {
                soulsAvailable = soulsAvailable - lichSummonCost;
                soulsSpent += lichSummonCost;
                if (lichScrolls != '3')
                {
                    pbxLich.ImageLocation = @"Data/lich summon.png";
                    lblLichDesc.Text = "Lich with the ability to summon lesser undead";
                }
                pnlLichUpgradeSummon.Visible = false;
                pnlLichUpgradeSummon.Enabled = false;
                lichMultiplier = lichMultiplier + 4;
                lichSPS = (lichPopulation * (lichBaseSPS * lichMultiplier));
                lblLichAmount.Text = "Population: " + lichPopulation + " SPS: " + String.Format("{0:n}", Math.Round(lichSPS, 2));
                lichSummon = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnLichUpgradeMagic_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - lichMagicCost < 0))
            {
                soulsAvailable = soulsAvailable - lichMagicCost;
                soulsSpent += lichMagicCost;
                if (lichSummon != '3' && lichScrolls != '3')
                {
                    pbxLich.ImageLocation = @"Data/lich blood magic.png";
                    lblLichDesc.Text = "Lich with blood magic";
                }
                pnlLichUpgradeMagic.Visible = false;
                pnlLichUpgradeMagic.Enabled = false;
                lichMultiplier = lichMultiplier + 1;
                lichSPS = (lichPopulation * (lichBaseSPS * lichMultiplier));
                lblLichAmount.Text = "Population: " + lichPopulation + " SPS: " + String.Format("{0:n}", Math.Round(lichSPS, 2));
                lichMagic = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnWraithUpgradeWyvern_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - wraithWyvernCost < 0))
            {
                soulsAvailable = soulsAvailable - wraithWyvernCost;
                soulsSpent += wraithWyvernCost;
                pbxWraith.ImageLocation = @"Data/wraith with wyvern and inferno blade.png";
                lblWraithDesc.Text = "Wraith with wyvern";
                pnlWraithUpgradeWyvern.Visible = false;
                pnlWraithUpgradeWyvern.Enabled = false;
                wraithMultiplier = wraithMultiplier + 10;
                wraithSPS = (wraithPopulation * (wraithBaseSPS * wraithMultiplier));
                lblWraithAmount.Text = "Population: " + wraithPopulation + " SPS: " + String.Format("{0:n}", Math.Round(wraithSPS, 2));
                wraithWyvern = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnWraithUpgradeInfernalWeapons_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - wraithWeaponsCost < 0))
            {
                soulsAvailable = soulsAvailable - wraithWeaponsCost;
                soulsSpent += wraithWeaponsCost;
                if (wraithWyvern != '3')
                {
                    pbxWraith.ImageLocation = @"Data/wraith with horse and inferno blade.png";
                    lblWraithDesc.Text = "Wraith with inferno weaponry";
                }
                pnlWraithUpgradeInfernalWeaponry.Visible = false;
                pnlWraithUpgradeInfernalWeaponry.Enabled = false;
                wraithMultiplier = wraithMultiplier + 4;
                wraithSPS = (wraithPopulation * (wraithBaseSPS * wraithMultiplier));
                lblWraithAmount.Text = "Population: " + wraithPopulation + " SPS: " + String.Format("{0:n}", Math.Round(wraithSPS, 2));
                wraithWeapons = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnWraithUpgradeHorse_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - wraithHorseCost < 0))
            {
                soulsAvailable = soulsAvailable - wraithHorseCost;
                soulsSpent += wraithHorseCost;
                if (wraithWeapons != '3' && wraithWyvern != '3')
                {
                    pbxWraith.ImageLocation = @"Data/wraith with horse.png";
                    lblWraithDesc.Text = "Wraith with demon horse";
                }
                pnlWraithUpgradeHorse.Visible = false;
                pnlWraithUpgradeHorse.Enabled = false;
                wraithMultiplier = wraithMultiplier + 1;
                wraithSPS = (wraithPopulation * (wraithBaseSPS * wraithMultiplier));
                lblWraithAmount.Text = "Population: " + wraithPopulation + " SPS: " + String.Format("{0:n}", Math.Round(wraithSPS, 2));
                wraithHorse = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnVampireUpgradeEnchantedWeaponry_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - vampireWeaponsCost < 0))
            {
                soulsAvailable = soulsAvailable - vampireWeaponsCost;
                soulsSpent += vampireWeaponsCost;
                pbxVampire.ImageLocation = @"Data/vampire enchanted weapons.png";
                lblVampireDescription.Text = "Vampire with enchanted weaponry";
                pnlVampireUpgradeEnchantedWeaponry.Visible = false;
                pnlVampireUpgradeEnchantedWeaponry.Enabled = false;
                vampireMultiplier = vampireMultiplier + 10;
                vampireSPS = (vampirePopulation * (vampireBaseSPS * vampireMultiplier));
                lblVampireAmount.Text = "Population: " + vampirePopulation + " SPS: " + String.Format("{0:n}", Math.Round(vampireSPS, 2));
                vampireWeapons = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnVampireUpgradeBatForm_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - vampireBatCost < 0))
            {
                soulsAvailable = soulsAvailable - vampireBatCost;
                soulsSpent += vampireBatCost;
                if (vampireWeapons != '3')
                {
                    pbxVampire.ImageLocation = @"Data/vampire bat form.png";
                    lblVampireDescription.Text = "Vampire with bat like abilities";
                }
                pnlVampireUpgradeBatForm.Visible = false;
                pnlVampireUpgradeBatForm.Enabled = false;
                vampireMultiplier = vampireMultiplier + 4;
                vampireSPS = (vampirePopulation * (vampireBaseSPS * vampireMultiplier));
                lblVampireAmount.Text = "Population: " + vampirePopulation + " SPS: " + String.Format("{0:n}", Math.Round(vampireSPS, 2));
                vampireBat = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnVampireUpgradeHealing_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - vampireHealingCost < 0))
            {
                soulsAvailable = soulsAvailable - vampireHealingCost;
                soulsSpent += vampireHealingCost;
                if (vampireBat != '3' && vampireWeapons != '3')
                {
                    pbxVampire.ImageLocation = @"Data/vampire healing.png";
                    lblVampireDescription.Text = "Vampire with improved healing";
                }
                pnlVampireUpgradeHealing.Visible = false;
                pnlVampireUpgradeHealing.Enabled = false;
                vampireMultiplier = vampireMultiplier + 1;
                vampireSPS = (vampirePopulation * (vampireBaseSPS * vampireMultiplier));
                lblVampireAmount.Text = "Population: " + vampirePopulation + " SPS: " + String.Format("{0:n}", Math.Round(vampireSPS, 2));
                vampireHealing = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnSkeletonUpgradeDarksteel_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - skeletonDarksteelCost < 0))
            {
                soulsAvailable = soulsAvailable - skeletonDarksteelCost;
                soulsSpent += skeletonDarksteelCost;
                pbxSkeleton.ImageLocation = @"Data/skeleton darksteel sword.png";
                lblSkeletonDesc.Text = "Skeleton with darksteel weaponry";
                pnlSkeletonUpgradeDarksteel.Visible = false;
                pnlSkeletonUpgradeDarksteel.Enabled = false;
                skeletonMultiplier = skeletonMultiplier + 10;
                skeletonSPS = (skeletonPopulation * (skeletonBaseSPS * skeletonMultiplier));
                lblSkeletonAmount.Text = "Population: " + skeletonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(skeletonSPS, 2));
                skeletonDarksteel = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnSkeletonUpgradeArmor_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - skeletonArmorCost < 0))
            {
                soulsAvailable = soulsAvailable - skeletonArmorCost;
                soulsSpent += skeletonArmorCost;
                if (skeletonDarksteel != '3')
                {
                    pbxSkeleton.ImageLocation = @"Data/skeleton iron armor.png";
                    lblSkeletonDesc.Text = "Skeleton with iron armor";
                }
                pnlSkeletonUpgradeArmor.Visible = false;
                pnlSkeletonUpgradeArmor.Enabled = false;
                skeletonMultiplier = skeletonMultiplier + 4;
                skeletonSPS = (skeletonPopulation * (skeletonBaseSPS * skeletonMultiplier));
                lblSkeletonAmount.Text = "Population: " + skeletonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(skeletonSPS, 2));
                skeletonArmor = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnSkeletonUpgradeWeapons_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - skeletonWeaponsCost < 0))
            {
                soulsAvailable = soulsAvailable - skeletonWeaponsCost;
                soulsSpent += skeletonWeaponsCost;
                if (skeletonArmor != '3' && skeletonDarksteel != '3')
                {
                    pbxSkeleton.ImageLocation = @"Data/skeleton iron sword.png";
                    lblSkeletonDesc.Text = "Skeleton with iron weaponry";
                }
                pnlSkeletonUpgradeWeapons.Visible = false;
                pnlSkeletonUpgradeWeapons.Enabled = false;
                skeletonMultiplier = skeletonMultiplier + 1;
                skeletonSPS = (skeletonPopulation * (skeletonBaseSPS * skeletonMultiplier));
                lblSkeletonAmount.Text = "Population: " + skeletonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(skeletonSPS, 2));
                skeletonWeapons = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnGhoulUpgradeArmor_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - ghoulLeatherCost < 0))
            {
                soulsAvailable = soulsAvailable - ghoulLeatherCost;
                soulsSpent += ghoulLeatherCost;
                pbxGhoul.ImageLocation = @"Data/ghoul leather armor.png";
                lblGhoulDesc.Text = "Ghoul with leather armor";
                pnlGhoulUpgradeArmor.Visible = false;
                pnlGhoulUpgradeArmor.Enabled = false;
                ghoulMultiplier = ghoulMultiplier + 10;
                ghoulSPS = (ghoulPopulation * (ghoulBaseSPS * ghoulMultiplier));
                lblGhoulAmount.Text = "Population: " + ghoulPopulation + " SPS: " + String.Format("{0:n}", Math.Round(ghoulSPS, 2));
                ghoulLeather = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnGhoulUpgradeParalysis_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - ghoulParalysisCost < 0))
            {
                soulsAvailable = soulsAvailable - ghoulParalysisCost;
                soulsSpent += ghoulParalysisCost;
                if (ghoulLeather != '3')
                {
                    pbxGhoul.ImageLocation = @"Data/ghoul paralysis.png";
                    lblGhoulDesc.Text = "Ghoul with paralysis abilities";
                }
                pnlGhoulUpgradeParalysis.Visible = false;
                pnlGhoulUpgradeParalysis.Enabled = false;
                ghoulMultiplier = ghoulMultiplier + 4;
                ghoulSPS = (ghoulPopulation * (ghoulBaseSPS * ghoulMultiplier));
                lblGhoulAmount.Text = "Population: " + ghoulPopulation + " SPS: " + String.Format("{0:n}", Math.Round(ghoulSPS, 2));
                ghoulParalysis = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnGhoulFangsUpgrade_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - ghoulFangsCost < 0))
            {
                soulsAvailable = soulsAvailable - ghoulFangsCost;
                soulsSpent += ghoulFangsCost;
                if (ghoulParalysis != '3' && ghoulLeather != '3')
                {
                    pbxGhoul.ImageLocation = @"Data/ghoul sharp fangs.png";
                    lblGhoulDesc.Text = "Ghoul with fangs";
                }
                pnlGhoulFangsUpgrade.Visible = false;
                pnlGhoulFangsUpgrade.Enabled = false;
                ghoulMultiplier = ghoulMultiplier + 1;
                ghoulSPS = (ghoulPopulation * (ghoulBaseSPS * ghoulMultiplier));
                lblGhoulAmount.Text = "Population: " + ghoulPopulation + " SPS: " + String.Format("{0:n}", Math.Round(ghoulSPS, 2));
                ghoulFangs = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnZombieMutantUpgrade_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - zombieMutantCost < 0))
            {
                soulsAvailable = soulsAvailable - zombieMutantCost;
                soulsSpent += zombieMutantCost;
                pbxZombie.ImageLocation = @"Data/mutant zombie.png";
                lblZombieDesc.Text = "Mutant Zombie";
                pnlZombieMutantUpgrade.Visible = false;
                pnlZombieMutantUpgrade.Enabled = false;
                zombieMultiplier = zombieMultiplier + 10;
                zombieSPS = (zombiePopulation * (zombieBaseSPS * zombieMultiplier));
                lblZombieAmount.Text = "Population: " + zombiePopulation + " SPS: " + String.Format("{0:n}", Math.Round(zombieSPS, 2));
                zombieMutant = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnZombieDiseasedUpgrade_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - zombieDiseasedCost < 0))
            {
                soulsAvailable = soulsAvailable - zombieDiseasedCost;
                soulsSpent += zombieDiseasedCost;
                if (zombieMutant != '3')
                {
                    pbxZombie.ImageLocation = @"Data/zombie diseased.png";
                    lblZombieDesc.Text = "Diseased Zombie";
                }
                pnlZombieDiseasedUpgrade.Visible = false;
                pnlZombieDiseasedUpgrade.Enabled = false;
                zombieMultiplier = zombieMultiplier + 4;
                zombieSPS = (zombiePopulation * (zombieBaseSPS * zombieMultiplier));
                lblZombieAmount.Text = "Population: " + zombiePopulation + " SPS: " + String.Format("{0:n}", Math.Round(zombieSPS, 2));
                zombieDiseased = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnZombieFastUpgrade_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - zombieFastCost < 0))
            {
                soulsAvailable = soulsAvailable - zombieFastCost;
                soulsSpent += zombieFastCost;
                if (zombieDiseased != '3' && zombieMutant != '3')
                {
                    pbxZombie.ImageLocation = @"Data/zombie fast.png";
                    lblZombieDesc.Text = "Fast Zombie";
                }
                pnlZombieFastUpgrade.Visible = false;
                pnlZombieFastUpgrade.Enabled = false;
                zombieMultiplier = zombieMultiplier + 1;
                zombieSPS = (zombiePopulation * (zombieBaseSPS * zombieMultiplier));
                lblZombieAmount.Text = "Population: " + zombiePopulation + " SPS: " + String.Format("{0:n}", Math.Round(zombieSPS, 2));
                zombieFast = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnDemonHelperUpgrade_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - demonsCost < 0))
            {
                soulsAvailable = soulsAvailable - demonsCost;
                soulsSpent += demonsCost;
                pbxClickThis.ImageLocation = @"Data/Demon altar with imps and demon.png";
                pnlDemonHelperUpgrade.Visible = false;
                pnlDemonHelperUpgrade.Enabled = false;
                clickableSPSPercentage += .01;
                demons = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnAltarUpgrade_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - altarCost < 0))
            {
                soulsAvailable = soulsAvailable - altarCost;
                soulsSpent += altarCost;
                if(demons != '3')
                    pbxClickThis.ImageLocation = @"Data/Demon altar with book.png";
                pnlAltarUpgrade.Visible = false;
                pnlAltarUpgrade.Enabled = false;
                clickableSPSPercentage += .01;
                altar = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnImpUpgrade_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - impCost < 0))
            {
                soulsAvailable = soulsAvailable - impCost;
                soulsSpent += impCost;
                if(altar != '3' && demons != '3')
                    pbxClickThis.ImageLocation = @"Data/cauldron and book with imp.png";
                pnlImpUpgrade.Visible = false;
                pnlImpUpgrade.Enabled = false;
                clickableSPSPercentage += .01;
                imp = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnCouldronupgrade_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - couldronCost < 0))
            {
                soulsAvailable = soulsAvailable - couldronCost;
                soulsSpent += couldronCost;
                if(imp != '3' && altar != '3' && demons != '3')
                    pbxClickThis.ImageLocation = @"Data/cauldron and book.png";
                pnlCouldronUpgrade.Visible = false;
                pnlCouldronUpgrade.Enabled = false;
                clickableSPSPercentage += .01;
                couldron = '3';
                upgradesPurchased += 1;
                calculateSPSAndSPC();
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnBookUpgrade_Click(object sender, EventArgs e)
        {
            pbxClickThis.ImageLocation = @"Data/book.png";
            pnlBookUpgrade.Visible = false;
            pnlBookUpgrade.Enabled = false;
            book = '3';
            upgradesPurchased += 1;
            SPC += 1;
        }

        // ********* Monsters ********* 

        //currentSPS + (population * (baseCost * multiplier))
        private void btnZombie_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - zombieCost < 0))
            {
                soulsAvailable = soulsAvailable - zombieCost;
                soulsSpent += zombieCost;
                zombiePopulation += 1;
                zombieCost = zombieBaseCost * Math.Pow(costMultiplier, zombiePopulation);
                lblZombieCost.Text = String.Format("{0:n0}", Math.Round(zombieCost, 2)) + " Souls";
                if(zombieMutant == '3')
                    zombieSPS = (zombieSPS / (zombieBaseSPS * zombiePopulation)) + (zombiePopulation * (zombieBaseSPS * zombieMultiplier));
                else
                    zombieSPS = (zombiePopulation * (zombieBaseSPS * zombieMultiplier));
                calculateSPSAndSPC();
                lblZombieAmount.Text = "Population: " + zombiePopulation + " SPS: " + String.Format("{0:n}", Math.Round(zombieSPS, 2));
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnGhoul_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - ghoulCost < 0))
            {
                soulsAvailable = soulsAvailable - ghoulCost;
                soulsSpent += ghoulCost;
                ghoulPopulation += 1;
                ghoulCost = ghoulBaseCost * Math.Pow(costMultiplier, ghoulPopulation);
                lblGhoulCost.Text = String.Format("{0:n0}", Math.Round(ghoulCost, 2)) + " Souls";
                if(ghoulLeather == '3')
                    ghoulSPS = (ghoulSPS / (ghoulBaseSPS * ghoulPopulation)) + (ghoulPopulation * (ghoulBaseSPS * ghoulMultiplier));
                else
                    ghoulSPS = (ghoulPopulation * (ghoulBaseSPS * ghoulMultiplier));
                calculateSPSAndSPC();
                lblGhoulAmount.Text = "Population: " + ghoulPopulation + " SPS: " + String.Format("{0:n}", Math.Round(ghoulSPS, 2));
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnSkeleton_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - skeletonCost < 0))
            {
                soulsAvailable = soulsAvailable - skeletonCost;
                soulsSpent += skeletonCost;
                skeletonPopulation += 1;
                skeletonCost = skeletonBaseCost * Math.Pow(costMultiplier, skeletonPopulation);
                lblSkeletonCost.Text = String.Format("{0:n0}", Math.Round(skeletonCost, 2)) + " Souls";
                if (skeletonDarksteel == '3')
                    skeletonSPS = (skeletonSPS / (skeletonBaseSPS * skeletonPopulation)) + (skeletonPopulation * (skeletonBaseSPS * skeletonMultiplier));
                else
                    skeletonSPS = (skeletonPopulation * (skeletonBaseSPS * skeletonMultiplier));
                calculateSPSAndSPC();
                lblSkeletonAmount.Text = "Population: " + skeletonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(skeletonSPS, 2));
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnVampire_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - vampireCost < 0))
            {
                soulsAvailable = soulsAvailable - vampireCost;
                soulsSpent += vampireCost;
                vampirePopulation += 1;
                vampireCost = vampireBaseCost * Math.Pow(costMultiplier, vampirePopulation);
                lblVampireCost.Text = String.Format("{0:n0}", Math.Round(vampireCost, 2)) + " Souls";
                if(vampireWeapons == '3')
                    vampireSPS = (vampireSPS / (vampireBaseSPS * vampirePopulation)) + (vampirePopulation * (vampireBaseSPS * vampireMultiplier));
                else
                    vampireSPS = (vampirePopulation * (vampireBaseSPS * vampireMultiplier));
                calculateSPSAndSPC();
                lblVampireAmount.Text = "Population: " + vampirePopulation + " SPS: " + String.Format("{0:n}", Math.Round(vampireSPS, 2));
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnWraith_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - wraithCost < 0))
            {
                soulsAvailable = soulsAvailable - wraithCost;
                soulsSpent += wraithCost;
                wraithPopulation += 1;
                wraithCost = wraithBaseCost * Math.Pow(costMultiplier, wraithPopulation);
                lblWraithCost.Text = String.Format("{0:n0}", Math.Round(wraithCost, 2)) + " Souls";
                if(wraithWyvern == '3')
                    wraithSPS = (wraithSPS / (wraithBaseSPS * wraithPopulation)) + (wraithPopulation * (wraithBaseSPS * wraithMultiplier));
                else
                    wraithSPS = (wraithPopulation * (wraithBaseSPS * wraithMultiplier));
                calculateSPSAndSPC();
                lblWraithAmount.Text = "Population: " + wraithPopulation + " SPS: " + String.Format("{0:n}", Math.Round(wraithSPS, 2));
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnLich_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - lichCost < 0))
            {
                soulsAvailable = soulsAvailable - lichCost;
                soulsSpent += lichCost;
                lichPopulation += 1;
                lichCost = lichBaseCost * Math.Pow(costMultiplier, lichPopulation);
                lblLichCost.Text = String.Format("{0:n0}", Math.Round(lichCost, 2)) + " Souls";
                if(lichScrolls == '3')
                    lichSPS = (lichSPS / (lichBaseSPS * lichPopulation)) + (lichPopulation * (lichBaseSPS * lichMultiplier));
                else
                    lichSPS = (lichPopulation * (lichBaseSPS * lichMultiplier));
                calculateSPSAndSPC();
                lblLichAmount.Text = "Population: " + lichPopulation + " SPS: " + String.Format("{0:n}", Math.Round(lichSPS));
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnDeathKnight_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - deathKnightCost < 0))
            {
                soulsAvailable = soulsAvailable - deathKnightCost;
                soulsSpent += deathKnightCost;
                deathKnightPopulation += 1;
                deathKnightCost = deathKnightBaseCost * Math.Pow(costMultiplier, deathKnightPopulation);
                lblDeathKnightCost.Text = String.Format("{0:n0}", Math.Round(deathKnightCost, 2)) + " Souls";
                if(deathKnightHorses == '3')
                    deathKnightSPS = (deathKnightSPS / (deathKnightBaseSPS * deathKnightPopulation)) + (deathKnightPopulation * (deathKnightBaseSPS * deathKnightMultiplier));
                else
                    deathKnightSPS = (deathKnightPopulation * (deathKnightBaseSPS * deathKnightMultiplier));
                calculateSPSAndSPC();
                lblDeathKnightAmount.Text = "Population: " + deathKnightPopulation + " SPS: " + String.Format("{0:n}", Math.Round(deathKnightSPS, 2));
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }

        private void btnDragon_Click(object sender, EventArgs e)
        {
            if (!(soulsAvailable - dragonCost < 0))
            {
                soulsAvailable = soulsAvailable - dragonCost;
                soulsSpent += dragonCost;
                dragonPopulation += 1;
                dragonCost = dragonBaseCost * Math.Pow(costMultiplier, dragonPopulation);
                lblDragonCost.Text = String.Format("{0:n0}", Math.Round(dragonCost, 2)) + " Souls";
                if(dragonArmor == '3')
                    dragonSPS = (dragonSPS / (dragonBaseSPS * dragonPopulation)) + (dragonPopulation * (dragonBaseSPS * dragonMultiplier));
                else
                    dragonSPS = (dragonPopulation * (dragonBaseSPS * dragonMultiplier));
                calculateSPSAndSPC();
                lblDragonAmount.Text = "Population: " + dragonPopulation + " SPS: " + String.Format("{0:n}", Math.Round(dragonSPS, 2));
            }
            else
                MessageBox.Show("Insufficient souls to make purchase.");
        }


        #endregion

    }
}
 