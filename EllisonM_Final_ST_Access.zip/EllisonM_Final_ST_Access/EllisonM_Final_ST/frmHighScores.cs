﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EllisonM_Final_ST
{
    public partial class frmHighScores : Form
    {
        public frmHighScores()
        {
            InitializeComponent();
        }

        private List<double> scores = new List<double> { };//list of doubles to hold scores

        private void frmHighScores_Load(object sender, EventArgs e)
        {
            DataOps.selectUsernameTotalSoulsProfilePictureWhereUserID();//grab current user's data and shove all that stuff into the controls at the top
            lblUserName.Text = DataOps.dsData.Tables[DataOps.dtData].Rows[0][0].ToString();
            lblUserScore.Text = "High Score: " + String.Format("{0:n0}", DataOps.dsData.Tables[DataOps.dtData].Rows[0][1]);
            pbxUser.Image = DataOps.convertImage(0, 2);

            DataOps.selectUsernameTotalSoulsProfilePicture();
            for (int i = 0; i < DataOps.dsData.Tables[DataOps.dtData].Rows.Count; i++)//add all the scores to scores list
                scores.Add(double.Parse(DataOps.dsData.Tables[DataOps.dtData].Rows[i][1].ToString()));

            for(int i = 0; i < scores.Count; i++)
            {
                if (scores[i] == double.Parse(lblUserScore.Text.Replace("High Score: ", "")))//set the rank of the current user when the score has matched with another score
                    lblUserRank.Text = "Rank: " + (i + 1);

                Panel pnlHighScores = new Panel();//make a panel to hold the labels and picture box
                pnlHighScores.Size = new Size(615, 114);
                pnlHighScores.BackColor = Color.FromArgb(77, 67, 97);

                PictureBox pbxHighScores = new PictureBox();//make a picture box for all the user's profile pictures
                pbxHighScores.Size = new Size(122, 107);
                pbxHighScores.Image = DataOps.convertImage(i, 2);
                pbxHighScores.SizeMode = PictureBoxSizeMode.StretchImage;
                pnlHighScores.Controls.Add(pbxHighScores);

                Label lblHighScoreName = new Label();//make a label to store the name of the users
                lblHighScoreName.Size = new Size(470, 26);
                lblHighScoreName.Location = new Point(122, 0);
                lblHighScoreName.Font = new Font(lblHighScoreName.Font.FontFamily, 16);
                lblHighScoreName.ForeColor = Color.White;
                lblHighScoreName.Text = DataOps.dsData.Tables[DataOps.dtData].Rows[i][0].ToString();
                pnlHighScores.Controls.Add(lblHighScoreName);

                Label lblHighScoreScore = new Label();//make a label to store the users scores
                lblHighScoreScore.Size = new Size(470, 26);
                lblHighScoreScore.Location = new Point(122, 35);
                lblHighScoreScore.Font = new Font(lblHighScoreScore.Font.FontFamily, 16);
                lblHighScoreScore.ForeColor = Color.White;
                lblHighScoreScore.Text = "High Score: " + String.Format("{0:n0}", DataOps.dsData.Tables[DataOps.dtData].Rows[i][1]);
                pnlHighScores.Controls.Add(lblHighScoreScore);

                Label lblHighScoreRank = new Label();//make a label to store the rank of the user
                lblHighScoreRank.Size = new Size(470, 26);
                lblHighScoreRank.Location = new Point(122, 70);
                lblHighScoreRank.Font = new Font(lblHighScoreRank.Font.FontFamily, 16);
                lblHighScoreRank.ForeColor = Color.White;
                lblHighScoreRank.Text = "Rank: " + (i + 1);
                pnlHighScores.Controls.Add(lblHighScoreRank);

                fpnlHighScores.Controls.Add(pnlHighScores);//shove the panel we just made into the big flow panel
            }

        }
    }
}
