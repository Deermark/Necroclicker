﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EllisonM_Final_ST
{
    public partial class frmReport : Form
    {
        public frmReport()
        {
            InitializeComponent();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {
            DataOps.selectEverythingWhereUserID();
            if (frmMain.report == "stats")
            {
                crStats stats = new crStats();
                stats.SetDatabaseLogon("MEllison", "1598365");
                stats.SetDataSource(DataOps.dsData.Tables[DataOps.dtData]);
                crvReport.ReportSource = stats;
            }
            else if(frmMain.report == "COT")
            {
                crCOT COT = new crCOT();
                COT.SetDatabaseLogon("MEllison", "1598365");
                COT.SetDataSource(DataOps.dsData.Tables[DataOps.dtData]);
                crvReport.ReportSource = COT;
            }
            else if(frmMain.report == "TSOT")
            {
                crTSOT SPSOT = new crTSOT();
                SPSOT.SetDatabaseLogon("MEllison", "1598365");
                SPSOT.SetDataSource(DataOps.dsData.Tables[DataOps.dtData]);
                crvReport.ReportSource = SPSOT;
            }
        }
    }
}
