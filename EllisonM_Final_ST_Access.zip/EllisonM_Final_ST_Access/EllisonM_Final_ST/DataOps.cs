﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Drawing;

namespace EllisonM_Final_ST
{
    class DataOps
    {
        //makes sql objects
        private static string query = "";
        private static string connection_string = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=..\..\Data\EllisonM_FinalAccessDB.mdb;Mode=Share Deny None";
        private static OleDbConnection con = new OleDbConnection(connection_string);
        private static OleDbDataAdapter daData = new OleDbDataAdapter();
        private static DataSet _dsData = new DataSet();
        private static string _dtData = "Data";

        private static string newUserID = "";
        private static string currentUserID = "";

        public static DataSet dsData
        {
            get { return _dsData; }
            set { _dsData = value; }
        }

        public static string dtData
        {
            get { return _dtData; }
            set { _dtData = value; }
        }

        //************* Login and account creation *************
        #region login and account creation
        public static string checkLogin(string username, string password)
        {
            //makes a couple of boolean for use to determine when and what to return
            bool usernamegood = false;
            bool passwordgood = false;

            try
            {
                //queries the username from users and stoeres it inside of a dataset
                query = "SELECT Username FROM Data";
                con.Open();
                using (OleDbCommand cmdCheckUsername = new OleDbCommand(query, con))
                {
                    dsData.Clear();
                    dsData.Tables.Clear();
                    daData.SelectCommand = cmdCheckUsername;
                    daData.Fill(dsData, dtData);
                    cmdCheckUsername.ExecuteNonQuery();
                }
                //loops through however many rows were queried to determine whether there exitst a username the user entered
                for (int i = 0; i < dsData.Tables[dtData].Rows.Count; i++)
                {
                    string thinggy = dsData.Tables[dtData].Rows[i][0].ToString();
                    if (thinggy == username)
                    {
                        usernamegood = true;//holds on to the fact that a username matched
                        break;
                    }
                }

                //checks if the username was good, if it wasn't then return an invalid username
                if (usernamegood == false)
                {
                    return "Invalid Username";
                }

                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                return "Invalid Username";
            }

            try
            {
                //queries the database for a password that matches the username then stores the result into a variable
                string pass = "";
                query = "SELECT Password FROM Data WHERE Username = ?";
                con.Open();
                using (OleDbCommand cmdCheckPassword = new OleDbCommand(query, con))
                {
                    cmdCheckPassword.Parameters.AddWithValue("?", username);
                    pass = cmdCheckPassword.ExecuteScalar().ToString();
                }

                //compares that stored variable to what the user entered and if it matches then the password is good
                if (pass == password)
                {
                    passwordgood = true;
                }

                con.Close();
                //final return for if the password is bad then the function will return invalid password. 
                //if everything up til this point has gone swimmingly, then reuturn that all is well and the username and password match
                if (passwordgood == false)
                    return "Invalid Password";
                else
                {
                    try
                    {
                        query = "SELECT UserID FROM Data WHERE Username = ? AND Password = ?";
                        con.Open();
                        using (OleDbCommand cmdSelectCurrentUserID = new OleDbCommand(query, con))
                        {
                            cmdSelectCurrentUserID.Parameters.AddWithValue("?", username);
                            cmdSelectCurrentUserID.Parameters.AddWithValue("?", password);
                            currentUserID = cmdSelectCurrentUserID.ExecuteScalar().ToString();
                        }
                        con.Close();
                        return "Username and Password are All Good";
                    }
                    catch (OleDbException ex)
                    {
                        con.Close();
                        MessageBox.Show("Error: " + ex);
                        return "sqlexplosion";
                    }
                }

            }
            catch (Exception)
            {
                con.Close();
                return "Invalid Password";
            }
        }

        public static void incrementUserIDByOne()
        {
            try
            {
                query = "SELECT MAX(UserID) FROM Data";
                con.Open();
                using (OleDbCommand cmdIncrementUserIDByOne = new OleDbCommand(query, con))
                    newUserID = (int.Parse(cmdIncrementUserIDByOne.ExecuteScalar().ToString()) + 1).ToString();
                con.Close();
            }
            catch (Exception)
            {
                con.Close();
                newUserID = "1";
                return;
            }
        }

        public static void makeNewAccount(string username, string password, bool admin, byte[] image)
        {
            incrementUserIDByOne();
            try
            {
                query = "INSERT INTO Data([UserID], [Username], [Password], [Book], [Couldron], [Imp], [Altar], [Demons], [Zombie], [ZombieFast], [ZombieDiseased], [ZombieMutant], [Ghoul], [GhoulFangs], [GhoulParalysis], [GhoulLeather], [Skeleton], [SkeletonWeapons], [SkeletonArmor], [SkeletonDarksteel], [Vampire], [VampireHealing], [VampireBat], [VampireWeapons], [Wraith], [WraithHorse], [WraithWeapons], [WraithWyvern], [Lich], [LichMagic], [LichSummon], [LichScrolls], [DeathKnight], [DeathKnightSteel], [DeathKnightRuned], [DeathKnightHorses], [Dragon], [DragonRider], [DragonFrost], [DragonArmor], [ZombieAmount], [GhoulAmount], [SkeletonAmount], [VampireAmount], [WraithAmount], [LichAmount], [DeathKnightAmount], [DragonAmount], [SoulsAvailable], [SPS], [SPC], [ClickCount], [SoulsSpent], [SoulsTotal], [UpgradesUnlocked], [UpgradesPurchased], [Admin], [PlayTime], [ProfilePic]) Values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                con.Open();
                using (OleDbCommand cmdMakeNewAccount = new OleDbCommand(query, con))
                {
                    cmdMakeNewAccount.Parameters.AddWithValue("?", newUserID);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", username);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", password);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '2');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", '1');
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", admin);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", 0);
                    cmdMakeNewAccount.Parameters.AddWithValue("?", image);
                    cmdMakeNewAccount.ExecuteNonQuery();
                }
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        #endregion

        //************* Data Retrieval *************
        #region data retrieval

        public static void selectEverythingWhereUserID()
        {
            try
            {
                query = "SELECT * FROM Data WHERE UserID = ?";
                con.Open();
                using (OleDbCommand cmdSelectEverythingWhereUserID = new OleDbCommand(query, con))
                {
                    cmdSelectEverythingWhereUserID.Parameters.AddWithValue("?", currentUserID);
                    dsData.Clear();
                    dsData.Tables.Clear();
                    daData.SelectCommand = cmdSelectEverythingWhereUserID;
                    daData.Fill(dsData, dtData);
                    cmdSelectEverythingWhereUserID.ExecuteNonQuery();
                }
                con.Close();
            }
            catch(Exception ex)
            {
                con.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void selectUsernameTotalSoulsProfilePictureWhereUserID()
        {
            try
            {
                query = "SELECT Username, SoulsTotal, ProfilePic FROM Data Where UserID = ?";
                con.Open();
                using (OleDbCommand cmdSelectUsernameTotalSoulsProfilePictureWhereUserID = new OleDbCommand(query, con))
                {
                    cmdSelectUsernameTotalSoulsProfilePictureWhereUserID.Parameters.AddWithValue("?", currentUserID);
                    dsData.Clear();
                    dsData.Tables.Clear();
                    daData.SelectCommand = cmdSelectUsernameTotalSoulsProfilePictureWhereUserID;
                    daData.Fill(dsData, dtData);
                    cmdSelectUsernameTotalSoulsProfilePictureWhereUserID.ExecuteNonQuery();
                }
                con.Close();
            }
            catch(Exception ex)
            {
                con.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void selectUsernameTotalSoulsProfilePicture()
        {
            {
                try
                {
                    query = "SELECT Username, SoulsTotal, ProfilePic FROM Data ORDER BY SoulsTotal DESC";
                    con.Open();
                    using (OleDbCommand cmdSelectUsernameTotalSoulsProfilePicture = new OleDbCommand(query, con))
                    {
                        dsData.Clear();
                        dsData.Tables.Clear();
                        daData.SelectCommand = cmdSelectUsernameTotalSoulsProfilePicture;
                        daData.Fill(dsData, dtData);
                        cmdSelectUsernameTotalSoulsProfilePicture.ExecuteNonQuery();
                    }
                    con.Close();
                }
                catch (Exception ex)
                {
                    con.Close();
                    MessageBox.Show("Error: " + ex);
                    return;
                }
            }
        }


        #endregion

        //************* updates *************
        #region updates

        public static void updateEverything(string book, string couldron, string imp, string altar, string demons, string zombie, string zombieFast, string zombieDiseased, string zombieMutant, string ghoul, string ghoulFangs, string ghoulParalysis, string ghoulLeather, string skeleton, string skeletonWeapons, string skeletonArmor, string skeletonDarksteel, string vampire, string vampireHealing, string vampireBat, string vampireWeapons, string wraith, string wraithHorse, string wraithWeapons, string wraithWyvern, string lich, string lichMagic, string lichSummon, string lichScrolls, string deathKnight, string deathKnightSteel, string deathKnightRuned, string deathKnightHorses, string dragon, string dragonRider, string dragonFrost, string dragonArmor, string zombieAmount, string ghoulAmount, string skeletonAmount, string vampireAmount, string wraithAmount, string lichAmount, string deathKnightAmount, string dragonAmount, string soulsAvailable, string SPS, string SPC, string clickCount, string soulsSpent, string soulsTotal, string upgradesUnlocked, string upgradesPurchased, string playTime, byte[] image)
        {
            try
            {
                query = "UPDATE Data Set [Book] = ?, [Couldron] = ?, [Imp] = ?, [Altar] = ?, [Demons] = ?, [Zombie] = ?, [ZombieFast] = ?, [ZombieDiseased] = ?, [ZombieMutant] = ?, [Ghoul] = ?, [GhoulFangs] = ?, [GhoulParalysis] = ?, [GhoulLeather] = ?, [Skeleton] = ?, [SkeletonWeapons] = ?, [SkeletonArmor] = ?, [SkeletonDarksteel] = ?, [Vampire] = ?, [VampireHealing] = ?, [VampireBat] = ?, [VampireWeapons] = ?, [Wraith] = ?, [WraithHorse] = ?, [WraithWeapons] = ?, [WraithWyvern] = ?, [Lich] = ?, [LichMagic] = ?, [LichSummon] = ?, [LichScrolls] = ?, [DeathKnight] = ?, [DeathKnightSteel] = ?, [DeathKnightRuned] = ?, [DeathKnightHorses] = ?, [Dragon] = ?, [DragonRider] = ?, [DragonFrost] = ?, [DragonArmor] = ?, [ZombieAmount] = ?, [GhoulAmount] = ?, [SkeletonAmount] = ?, [VampireAmount] = ?, [WraithAmount] = ?, [LichAmount] = ?, [DeathKnightAmount] = ?, [DragonAmount] = ?, [SoulsAvailable] = ?, [SPS] = ?, [SPC] = ?, [ClickCount] = ?, [SoulsSpent] = ?, [SoulsTotal] = ?, [UpgradesUnlocked] = ?, [UpgradesPurchased] = ?, [PlayTime] = ?, [ProfilePic] = ?WHERE UserID = ?";
                con.Open();
                using (OleDbCommand cmdUpdateEverything = new OleDbCommand(query, con))
                {
                    cmdUpdateEverything.Parameters.AddWithValue("?", book);
                    cmdUpdateEverything.Parameters.AddWithValue("?", couldron);
                    cmdUpdateEverything.Parameters.AddWithValue("?", imp);
                    cmdUpdateEverything.Parameters.AddWithValue("?", altar);
                    cmdUpdateEverything.Parameters.AddWithValue("?", demons);
                    cmdUpdateEverything.Parameters.AddWithValue("?", zombie);
                    cmdUpdateEverything.Parameters.AddWithValue("?", zombieFast);
                    cmdUpdateEverything.Parameters.AddWithValue("?", zombieDiseased);
                    cmdUpdateEverything.Parameters.AddWithValue("?", zombieMutant);
                    cmdUpdateEverything.Parameters.AddWithValue("?", ghoul);
                    cmdUpdateEverything.Parameters.AddWithValue("?", ghoulFangs);
                    cmdUpdateEverything.Parameters.AddWithValue("?", ghoulParalysis);
                    cmdUpdateEverything.Parameters.AddWithValue("?", ghoulLeather);
                    cmdUpdateEverything.Parameters.AddWithValue("?", skeleton);
                    cmdUpdateEverything.Parameters.AddWithValue("?", skeletonWeapons);
                    cmdUpdateEverything.Parameters.AddWithValue("?", skeletonArmor);
                    cmdUpdateEverything.Parameters.AddWithValue("?", skeletonDarksteel);
                    cmdUpdateEverything.Parameters.AddWithValue("?", vampire);
                    cmdUpdateEverything.Parameters.AddWithValue("?", vampireHealing);
                    cmdUpdateEverything.Parameters.AddWithValue("?", vampireBat);
                    cmdUpdateEverything.Parameters.AddWithValue("?", vampireWeapons);
                    cmdUpdateEverything.Parameters.AddWithValue("?", wraith);
                    cmdUpdateEverything.Parameters.AddWithValue("?", wraithHorse);
                    cmdUpdateEverything.Parameters.AddWithValue("?", wraithWeapons);
                    cmdUpdateEverything.Parameters.AddWithValue("?", wraithWyvern);
                    cmdUpdateEverything.Parameters.AddWithValue("?", lich);
                    cmdUpdateEverything.Parameters.AddWithValue("?", lichMagic);
                    cmdUpdateEverything.Parameters.AddWithValue("?", lichSummon);
                    cmdUpdateEverything.Parameters.AddWithValue("?", lichScrolls);
                    cmdUpdateEverything.Parameters.AddWithValue("?", deathKnight);
                    cmdUpdateEverything.Parameters.AddWithValue("?", deathKnightSteel);
                    cmdUpdateEverything.Parameters.AddWithValue("?", deathKnightRuned);
                    cmdUpdateEverything.Parameters.AddWithValue("?", deathKnightHorses);
                    cmdUpdateEverything.Parameters.AddWithValue("?", dragon);
                    cmdUpdateEverything.Parameters.AddWithValue("?", dragonRider);
                    cmdUpdateEverything.Parameters.AddWithValue("?", dragonFrost);
                    cmdUpdateEverything.Parameters.AddWithValue("?", dragonArmor);
                    cmdUpdateEverything.Parameters.AddWithValue("?", zombieAmount);
                    cmdUpdateEverything.Parameters.AddWithValue("?", ghoulAmount);
                    cmdUpdateEverything.Parameters.AddWithValue("?", skeletonAmount);
                    cmdUpdateEverything.Parameters.AddWithValue("?", vampireAmount);
                    cmdUpdateEverything.Parameters.AddWithValue("?", wraithAmount);
                    cmdUpdateEverything.Parameters.AddWithValue("?", lichAmount);
                    cmdUpdateEverything.Parameters.AddWithValue("?", deathKnightAmount);
                    cmdUpdateEverything.Parameters.AddWithValue("?", dragonAmount);
                    cmdUpdateEverything.Parameters.AddWithValue("?", soulsAvailable);
                    cmdUpdateEverything.Parameters.AddWithValue("?", SPS);
                    cmdUpdateEverything.Parameters.AddWithValue("?", SPC);
                    cmdUpdateEverything.Parameters.AddWithValue("?", clickCount);
                    cmdUpdateEverything.Parameters.AddWithValue("?", soulsSpent);
                    cmdUpdateEverything.Parameters.AddWithValue("?", soulsTotal);
                    cmdUpdateEverything.Parameters.AddWithValue("?", upgradesUnlocked);
                    cmdUpdateEverything.Parameters.AddWithValue("?", upgradesPurchased);
                    cmdUpdateEverything.Parameters.AddWithValue("?", playTime);
                    cmdUpdateEverything.Parameters.AddWithValue("?", image);
                    cmdUpdateEverything.Parameters.AddWithValue("?", currentUserID);
                    cmdUpdateEverything.ExecuteNonQuery();
                }
                con.Close();
            }
            catch (Exception ex)
            {
                con.Close();
                MessageBox.Show("Error:" + ex);
                return;
            }
        }

        #endregion

        //misc
        public static Image convertImage(int index1, int index2)
        {
            //converts the queried image located in the dataset from a byte array to a usable image
            byte[] thing = (byte[])dsData.Tables[dtData].Rows[index1][index2];
            Image image = (Bitmap)((new ImageConverter().ConvertFrom(thing)));
            return image;
        }
    }
}
