﻿namespace EllisonM_Final_ST
{
    partial class frmHighScores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHighScores));
            this.pnlUser = new System.Windows.Forms.Panel();
            this.lblUserRank = new System.Windows.Forms.Label();
            this.lblUserScore = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.pbxUser = new System.Windows.Forms.PictureBox();
            this.fpnlHighScores = new System.Windows.Forms.FlowLayoutPanel();
            this.lblHighScores = new System.Windows.Forms.Label();
            this.pnlUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxUser)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlUser
            // 
            this.pnlUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pnlUser.Controls.Add(this.lblUserRank);
            this.pnlUser.Controls.Add(this.lblUserScore);
            this.pnlUser.Controls.Add(this.lblUserName);
            this.pnlUser.Controls.Add(this.pbxUser);
            this.pnlUser.Location = new System.Drawing.Point(12, 65);
            this.pnlUser.Name = "pnlUser";
            this.pnlUser.Size = new System.Drawing.Size(646, 114);
            this.pnlUser.TabIndex = 0;
            // 
            // lblUserRank
            // 
            this.lblUserRank.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblUserRank.ForeColor = System.Drawing.Color.White;
            this.lblUserRank.Location = new System.Drawing.Point(131, 42);
            this.lblUserRank.Name = "lblUserRank";
            this.lblUserRank.Size = new System.Drawing.Size(512, 23);
            this.lblUserRank.TabIndex = 3;
            this.lblUserRank.Text = "Rank: 0";
            // 
            // lblUserScore
            // 
            this.lblUserScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblUserScore.ForeColor = System.Drawing.Color.White;
            this.lblUserScore.Location = new System.Drawing.Point(131, 81);
            this.lblUserScore.Name = "lblUserScore";
            this.lblUserScore.Size = new System.Drawing.Size(512, 29);
            this.lblUserScore.TabIndex = 2;
            this.lblUserScore.Text = "High Score: 0 Souls";
            // 
            // lblUserName
            // 
            this.lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lblUserName.ForeColor = System.Drawing.Color.White;
            this.lblUserName.Location = new System.Drawing.Point(131, 3);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(512, 23);
            this.lblUserName.TabIndex = 1;
            this.lblUserName.Text = "User\'s name";
            // 
            // pbxUser
            // 
            this.pbxUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.pbxUser.Image = ((System.Drawing.Image)(resources.GetObject("pbxUser.Image")));
            this.pbxUser.Location = new System.Drawing.Point(3, 3);
            this.pbxUser.Name = "pbxUser";
            this.pbxUser.Size = new System.Drawing.Size(122, 107);
            this.pbxUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxUser.TabIndex = 0;
            this.pbxUser.TabStop = false;
            // 
            // fpnlHighScores
            // 
            this.fpnlHighScores.AutoScroll = true;
            this.fpnlHighScores.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.fpnlHighScores.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.fpnlHighScores.Location = new System.Drawing.Point(12, 185);
            this.fpnlHighScores.Name = "fpnlHighScores";
            this.fpnlHighScores.Size = new System.Drawing.Size(646, 320);
            this.fpnlHighScores.TabIndex = 1;
            this.fpnlHighScores.WrapContents = false;
            // 
            // lblHighScores
            // 
            this.lblHighScores.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(77)))), ((int)(((byte)(67)))), ((int)(((byte)(97)))));
            this.lblHighScores.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.lblHighScores.ForeColor = System.Drawing.Color.White;
            this.lblHighScores.Location = new System.Drawing.Point(12, 9);
            this.lblHighScores.Name = "lblHighScores";
            this.lblHighScores.Size = new System.Drawing.Size(646, 43);
            this.lblHighScores.TabIndex = 4;
            this.lblHighScores.Text = "High Scores";
            this.lblHighScores.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmHighScores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(153)))), ((int)(((byte)(200)))));
            this.ClientSize = new System.Drawing.Size(670, 517);
            this.Controls.Add(this.lblHighScores);
            this.Controls.Add(this.fpnlHighScores);
            this.Controls.Add(this.pnlUser);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmHighScores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "High Scores";
            this.Load += new System.EventHandler(this.frmHighScores_Load);
            this.pnlUser.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxUser)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlUser;
        private System.Windows.Forms.PictureBox pbxUser;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblUserRank;
        private System.Windows.Forms.Label lblUserScore;
        private System.Windows.Forms.FlowLayoutPanel fpnlHighScores;
        private System.Windows.Forms.Label lblHighScores;
    }
}