﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EllisonM_Final_ST
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtUsername.Focus();
            btnCreateAccount.Visible = false;
            btnCreateAccount.Enabled = false;
            lblInstructions.Visible = false;
            btnLogin.Text = "Create";
            lblCreateAccount.Visible = true;
            btnBack.Visible = true;
            btnBack.Enabled = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //safely exits the application
            Application.Exit();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (btnLogin.Text == "Login")
            {
                //checks to see if the username or password is wrong/right and acts accordingly by displaying an error 
                //message or going on to the rest of the program
                if (DataOps.checkLogin(txtUsername.Text, txtPassword.Text) == "Invalid Username")
                {
                    MessageBox.Show("Invalid Username. Please try again.");
                    txtUsername.Clear();
                    txtUsername.Focus();
                }
                else if (DataOps.checkLogin(txtUsername.Text, txtPassword.Text) == "Invalid Password")
                {
                    MessageBox.Show("Invalid Pasword. Please try again.");
                    txtPassword.Clear();
                    txtPassword.Focus();
                }
                else
                {
                    frmMain main = new frmMain();
                    this.Hide();
                    main.ShowDialog();
                }
            }
            else
            {
                byte[] image = null;
                using (MemoryStream ms = new MemoryStream())
                {
                    pbxMeBeingLazy.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    image = ms.ToArray();
                }
                bool admin = false;
                DataOps.makeNewAccount(txtUsername.Text, txtPassword.Text, admin, image);
                txtUsername.Clear();
                txtPassword.Clear();
                txtUsername.Focus();
                MessageBox.Show("Account successfully created!");
                btnCreateAccount.Visible = true;
                btnCreateAccount.Enabled = true;
                lblInstructions.Visible = true;
                btnLogin.Text = "Login";
                lblCreateAccount.Visible = false;
                btnBack.Visible = false;
                btnBack.Enabled = false;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtUsername.Focus();
            btnCreateAccount.Visible = true;
            btnCreateAccount.Enabled = true;
            lblInstructions.Visible = true;
            btnLogin.Text = "Login";
            lblCreateAccount.Visible = false;
            btnBack.Visible = false;
            btnBack.Enabled = false;
        }
    }
}
